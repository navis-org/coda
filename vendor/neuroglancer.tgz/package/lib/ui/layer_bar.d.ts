/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/noselect.css";
import "#src/ui/layer_bar.css";
import type { ManagedUserLayer } from "#src/layer/index.js";
import type { LayerGroupViewer } from "#src/layer_group_viewer.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { DropLayers } from "#src/ui/layer_drag_and_drop.js";
import { RefCounted } from "#src/util/disposable.js";
declare class LayerWidget extends RefCounted {
    layer: ManagedUserLayer;
    panel: LayerBar;
    element: HTMLDivElement;
    layerNumberElement: HTMLDivElement;
    labelElement: HTMLDivElement;
    labelColorElement: HTMLDivElement;
    visibleProgress: HTMLDivElement;
    prefetchProgress: HTMLDivElement;
    labelElementText: Text;
    valueElement: HTMLDivElement;
    maxLength: number;
    prevValueText: string;
    private colorChangeDisposer;
    constructor(layer: ManagedUserLayer, panel: LayerBar);
    setColor(): void;
    update(): void;
    disposed(): void;
}
export declare class LayerBar extends RefCounted {
    layerGroupViewer: LayerGroupViewer;
    getLayoutSpecForDrag: () => any;
    showLayerHoverValues: WatchableValueInterface<boolean>;
    showAllPlotBounds?: WatchableValueInterface<boolean> | undefined;
    layerWidgets: Map<ManagedUserLayer, LayerWidget>;
    element: HTMLDivElement;
    private layerUpdateNeeded;
    private valueUpdateNeeded;
    dropZone: HTMLDivElement;
    private layerWidgetInsertionPoint;
    private positionWidget;
    /**
     * For use within this module only.
     */
    dropLayers: DropLayers | undefined;
    dragEnterCount: number;
    get layerManager(): import("#src/layer/index.js").LayerManager;
    get manager(): import("#src/layer/index.js").LayerListSpecification;
    get display(): import("../display_context").DisplayContext;
    get selectedLayer(): import("#src/layer/index.js").SelectedLayerState;
    get viewerNavigationState(): import("#src/layer_group_viewer.js").LinkedViewerNavigationState;
    constructor(layerGroupViewer: LayerGroupViewer, getLayoutSpecForDrag: () => any, showLayerHoverValues: WatchableValueInterface<boolean>, showAllPlotBounds?: WatchableValueInterface<boolean> | undefined);
    disposed(): void;
    handleLayersChanged(): void;
    handleLayerValuesChanged(): void;
    handleLayerItemValueChanged(): void;
    private scheduleUpdate;
    private update;
    private updateChunkStatistics;
    updateLayers(): void;
    addLayerMenu(): void;
}
export {};
