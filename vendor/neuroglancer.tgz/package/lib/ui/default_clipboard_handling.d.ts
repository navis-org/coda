/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Viewer } from "#src/viewer.js";
export declare function bindDefaultCopyHandler(viewer: Viewer): void;
/**
 * Checks if `s` consists of `rank` numbers separated by whitespace or commas, with optional parentheses or
 * brackets before and after.
 *
 * @param s The string to parse.
 * @param rank Specifies how many numbers are expected.
 * @return The parsed vector, or undefined if parsing failed.
 */
export declare function parsePositionString(s: string, rank: number): Float32Array | undefined;
export declare function bindDefaultPasteHandler(viewer: Viewer): void;
