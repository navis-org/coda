/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { LayerManager, SelectedLayerState } from "#src/layer/index.js";
import type { Command } from "#src/ui/command.js";
import type { CommandRegistry } from "#src/ui/command_registry.js";
import { type GlobalToolBinder, type LocalToolBinder } from "#src/ui/tool.js";
import type { MultiToolPaletteState } from "#src/ui/tool_palette.js";
import { RefCounted } from "#src/util/disposable.js";
import type { ActionIdentifier, EventAction } from "#src/util/event_action_map.js";
import { Signal } from "#src/util/signal.js";
import type { InputEventBindings } from "#src/viewer.js";
export interface CommandCatalogContext {
    readonly globalToolBinder: GlobalToolBinder;
    /**
     * Tool context for tools that are not scoped to a layer. Tool factories are
     * registered against a class prototype, so the binder's own context has to be
     * a real instance of such a class rather than an arbitrary object.
     */
    readonly toolBinder: LocalToolBinder;
    readonly layerManager: LayerManager;
    readonly selectedLayer: SelectedLayerState;
    readonly toolPalettes: MultiToolPaletteState;
    readonly inputEventBindings: InputEventBindings;
    /**
     * Primary source of the flat command set. Registered commands are enumerated
     * directly and take precedence; any keyboard-bound action that is *not*
     * registered is still listed afterwards, so actions an embedder or the Python
     * integration only ever bound to a key do not disappear from the palette.
     */
    readonly commandRegistry: CommandRegistry;
}
export interface ActionBinding {
    readonly actionId: ActionIdentifier;
    readonly eventAction: EventAction;
    readonly pressedEventIdentifier: string;
}
export type CommandSource = "registered" | "derived";
export interface CommandGroup {
    readonly label: string;
    readonly shortcut: string;
}
export interface CommandEntry {
    readonly shortcut: string;
    readonly label: string;
    readonly command: Command;
    readonly source: CommandSource;
    readonly group?: CommandGroup;
}
/**
 * Walk the event action maps available on the viewer and produce a list of
 * every action with any keyboard binding. The first binding found for each
 * action is kept; subsequent bindings for the same action are ignored.
 */
export declare function collectActionBindings(inputEventBindings: InputEventBindings): readonly ActionBinding[];
export declare class CommandCatalog extends RefCounted {
    private readonly context;
    commands: readonly CommandEntry[];
    groups: readonly CommandGroup[];
    readonly changed: Signal<() => void>;
    private readonly debouncedRebuild;
    private paletteNameDisposers;
    constructor(context: CommandCatalogContext);
    private disposePaletteNameListeners;
    rebuild(): void;
    filter(searchString?: string, groupLabel?: string): readonly CommandEntry[];
}
