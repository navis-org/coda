/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Registry of the {@link Command}s a viewer knows about.
 *
 * The registry owns *what commands exist*: their id, how they present, and how
 * they run. Bindings, ordering and grouping live with the consumers; a consumer
 * that wants to show a shortcut looks the live binding up itself.
 *
 * The registry is owned by the viewer, so commands can be registered before any
 * UI chrome exists, or without any at all. It lists the commands it was told
 * about, and there is no way to make that list complete: a viewer embedded in
 * another application, or driven from Python, can bind an action without ever
 * registering a command for it. See `docs/concepts/commands.rst`.
 */
import type { Command, CommandId } from "#src/ui/command.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal } from "#src/util/signal.js";
/**
 * Per-viewer registry of {@link Command}s. Registration returns a disposer that
 * unregisters the command, so feature code can add commands for the lifetime of
 * a layer / control and clean up automatically.
 */
export declare class CommandRegistry extends RefCounted {
    private readonly commands;
    private readonly commandChangedDisposers;
    /**
     * Dispatched when a command is registered or unregistered, or when a
     * registered command reports a change of its own.
     */
    readonly changed: NullarySignal;
    /** Registers `command`. Throws on duplicate id. Returns a disposer. */
    register(command: Command): () => void;
    unregister(id: CommandId): void;
    get(id: CommandId): Command | undefined;
    has(id: CommandId): boolean;
    /** Iterates every registered command, enabled or not, in registration order. */
    values(): IterableIterator<Command>;
    disposed(): void;
}
