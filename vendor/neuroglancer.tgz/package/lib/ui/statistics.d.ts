/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/statistics.css";
import type { ChunkQueueManager, ChunkSource, ChunkStatistics } from "#src/chunk_manager/frontend.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { SidePanelManager } from "#src/ui/side_panel.js";
import { SidePanel } from "#src/ui/side_panel.js";
import { TrackableSidePanelLocation } from "#src/ui/side_panel_location.js";
import type { Borrowed } from "#src/util/disposable.js";
import type { Trackable } from "#src/util/trackable.js";
export declare class StatisticsDisplayState implements Trackable {
    get changed(): import("../util/signal").Signal<() => void>;
    location: TrackableSidePanelLocation;
    sortBy?: WatchableValueInterface<string>;
    restoreState(obj: any): void;
    reset(): void;
    toJSON(): any;
}
export declare function getChunkSourceIdentifier(source: ChunkSource): any;
export declare function getFormattedNames(objects: any[]): string[];
export interface ChunkStatisticsColumn {
    label: string;
    key: string;
    getter: (statistics: Float64Array) => number;
}
export declare const columnSpecifications: ChunkStatisticsColumn[];
export declare class StatisticsPanel extends SidePanel {
    chunkQueueManager: Borrowed<ChunkQueueManager>;
    displayState: StatisticsDisplayState;
    data: ChunkStatistics | undefined;
    private requestDataTimerId;
    private dataRequested;
    body: HTMLDivElement;
    constructor(sidePanelManager: SidePanelManager, chunkQueueManager: Borrowed<ChunkQueueManager>, displayState: StatisticsDisplayState);
    disposed(): void;
    private requestData;
    private debouncedUpdateView;
    private updateView;
}
