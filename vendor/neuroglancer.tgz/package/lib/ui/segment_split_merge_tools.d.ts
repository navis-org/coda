/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/segment_split_merge_tools.css";
import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import { WatchableValue } from "#src/trackable_value.js";
import type { ToolActivation } from "#src/ui/tool.js";
import { LayerTool } from "#src/ui/tool.js";
export declare const ANNOTATE_MERGE_SEGMENTS_TOOL_ID = "mergeSegments";
export declare const ANNOTATE_SPLIT_SEGMENTS_TOOL_ID = "splitSegments";
export declare class MergeSegmentsTool extends LayerTool<SegmentationUserLayer> {
    lastAnchorBaseSegment: WatchableValue<bigint | undefined>;
    constructor(layer: SegmentationUserLayer);
    toJSON(): string;
    activate(activation: ToolActivation<this>): void;
    get description(): string;
}
export declare class SplitSegmentsTool extends LayerTool<SegmentationUserLayer> {
    toJSON(): string;
    activate(activation: ToolActivation<this>): void;
    get description(): string;
}
export declare function registerSegmentSplitMergeTools(contextType: typeof SegmentationUserLayer): void;
