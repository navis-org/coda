/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal } from "#src/util/signal.js";
import "#src/ui/context_menu.css";
export declare function positionContextMenu(menu: HTMLElement, event: MouseEvent): void;
export declare class ContextMenu extends RefCounted {
    element: HTMLDivElement;
    private menuDisposer;
    private parentDisposers;
    private disabledValue;
    opened: NullarySignal;
    closed: NullarySignal;
    get disabled(): boolean;
    set disabled(value: boolean);
    constructor(parent?: HTMLElement);
    get open(): boolean;
    registerParent(parent: HTMLElement): void;
    show(originalEvent: MouseEvent): void;
    unregisterParent(parent: HTMLElement): void;
    disposed(): void;
    hide(): void;
}
