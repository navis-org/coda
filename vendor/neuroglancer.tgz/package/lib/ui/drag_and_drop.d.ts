/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/drag_and_drop.css";
export type DragStatusRenderer = string | (() => Node);
export type DragStatusType = "drag" | "drop";
export declare function pushDragStatus(event: MouseEvent, target: EventTarget, operation: DragStatusType, status: DragStatusRenderer, leaveHandler?: () => void): void;
export declare function popDragStatus(event: MouseEvent, target: EventTarget, operation: DragStatusType): void;
