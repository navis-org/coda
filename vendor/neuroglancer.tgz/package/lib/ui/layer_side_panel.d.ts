/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Side panel for displaying/editing layer details.
 */
import "#src/ui/layer_side_panel.css";
import type { ManagedUserLayer, SelectedLayerState, UserLayer } from "#src/layer/index.js";
import type { UserLayerSidePanelState } from "#src/ui/layer_side_panel_state.js";
import type { SidePanelManager } from "#src/ui/side_panel.js";
import { RefCounted } from "#src/util/disposable.js";
export declare class LayerNameWidget extends RefCounted {
    layer: ManagedUserLayer;
    element: HTMLInputElement;
    constructor(layer: ManagedUserLayer);
    private updateView;
    private updateModel;
}
export declare class LayerTypeWidget extends RefCounted {
    layer: UserLayer;
    element: HTMLSelectElement;
    private measureElement;
    constructor(layer: UserLayer);
    private updateView;
    disposed(): void;
}
export declare class LayerSidePanelManager extends RefCounted {
    sidePanelManager: SidePanelManager;
    selectedLayerState: SelectedLayerState;
    placeholderSelectedLayerPanel: (() => void) | undefined;
    layerSidePanels: Map<UserLayerSidePanelState, {
        generation: number;
        unregister: () => void;
    }>;
    private generation;
    private layersNeedUpdate;
    constructor(sidePanelManager: SidePanelManager, selectedLayerState: SelectedLayerState);
    private getSelectedUserLayer;
    private update;
    disposed(): void;
}
