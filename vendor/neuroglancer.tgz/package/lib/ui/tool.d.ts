/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Support for defining user-selectable tools.
 */
import "#src/ui/tool.css";
import type { MouseSelectionState, UserLayer } from "#src/layer/index.js";
import { StatusMessage } from "#src/status.js";
import type { TrackableValueInterface } from "#src/trackable_value.js";
import type { ToolDragSource } from "#src/ui/tool_drag_and_drop.js";
import type { MultiToolPaletteState, ToolPalettePanel } from "#src/ui/tool_palette.js";
import type { Query } from "#src/ui/tool_query.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { ActionEvent, EventActionMap } from "#src/util/event_action_map.js";
import type { AnyConstructor } from "#src/util/mixin.js";
import { Signal } from "#src/util/signal.js";
export type InputEventMapBinder = (eventActionMap: EventActionMap, context: RefCounted) => void;
export declare class ToolActivation<ToolType extends Tool = Tool> extends RefCounted {
    tool: ToolType;
    inputEventMapBinder: InputEventMapBinder;
    constructor(tool: ToolType, inputEventMapBinder: InputEventMapBinder);
    bindAction<Info>(action: string, listener: (event: ActionEvent<Info>) => void): void;
    bindInputEventMap(inputEventMap: EventActionMap): void;
    cancel(): void;
}
export declare abstract class Tool<Context extends object = object> extends RefCounted {
    readonly localBinder: LocalToolBinder<Context>;
    toggle: boolean;
    changed: Signal<() => void>;
    unbound: Signal<() => void>;
    keyBinding: string | undefined;
    savedJsonString: string | undefined;
    get context(): Context;
    get globalBinder(): GlobalToolBinder;
    constructor(localBinder: LocalToolBinder<Context>, toggle?: boolean);
    abstract activate(activation: ToolActivation<this>): void;
    renderInPalette(context: RefCounted): HTMLElement | undefined;
    abstract toJSON(): any;
    abstract description: string;
    unbind(): void;
}
export declare abstract class LayerTool<LayerType extends UserLayer = UserLayer> extends Tool<LayerType> {
    layer: LayerType;
    constructor(layer: LayerType, toggle?: boolean);
    get mouseState(): MouseSelectionState;
}
export declare abstract class LegacyTool<LayerType extends UserLayer = UserLayer> extends RefCounted {
    layer: LayerType;
    changed: Signal<() => void>;
    constructor(layer: LayerType);
    get context(): LayerType;
    get mouseState(): MouseSelectionState;
    abstract trigger(mouseState: MouseSelectionState): void;
    abstract toJSON(): any;
    deactivate(): void;
    abstract description: string;
    unbind(): void;
}
export declare function restoreTool<Context extends object>(context: Context, obj: unknown): Tool<object> | undefined;
export declare function restoreLegacyTool(layer: UserLayer, obj: any): LegacyTool<UserLayer> | undefined;
export type ToolGetter<Context extends object = object> = (context: Context, options: any) => Owned<Tool> | undefined;
export type ToolLister<Context extends object = object> = (context: Context, onChange?: () => void) => any[];
export type LegacyToolGetter<LayerType extends UserLayer = UserLayer> = (layer: LayerType, options: any) => Owned<LegacyTool> | undefined;
export declare function registerLegacyTool(type: string, getter: LegacyToolGetter): void;
export declare function registerTool<Context extends object>(contextType: AnyConstructor<Context>, type: string, getter: ToolGetter<Context>, lister?: ToolLister<Context>): void;
export declare function unregisterTool<Context extends object>(contextType: AnyConstructor<Context>, type: string): void;
export declare class SelectedLegacyTool extends RefCounted implements TrackableValueInterface<LegacyTool | undefined> {
    layer: UserLayer;
    changed: Signal<() => void>;
    private value_;
    get value(): Owned<LegacyTool> | undefined;
    set value(newValue: Owned<LegacyTool> | undefined);
    private unregister;
    disposed(): void;
    restoreState(obj: unknown): void;
    reset(): void;
    toJSON(): any;
    constructor(layer: UserLayer);
}
export declare class GlobalToolBinder extends RefCounted {
    private inputEventMapBinder;
    toolPaletteState: MultiToolPaletteState;
    bindings: Map<string, Tool<object>>;
    changed: Signal<() => void>;
    activeTool_: Owned<ToolActivation> | undefined;
    private queuedTool;
    private debounceDeactivate;
    localBinders: Set<LocalToolBinder<object>>;
    localBindersChanged: Signal<() => void>;
    constructor(inputEventMapBinder: InputEventMapBinder, toolPaletteState: MultiToolPaletteState);
    get(key: string): Borrowed<Tool> | undefined;
    isActive(tool: Tool | undefined): boolean;
    private deleteBinding;
    private toolJsonMaybeChanged;
    set(key: string, tool: Owned<Tool> | undefined): void;
    activate(key: string, tool?: Tool<object>): Borrowed<Tool> | undefined;
    private reactivateQueuedTool;
    destroyTool(tool: Owned<Tool>): void;
    disposed(): void;
    deactivate_(): void;
    deactivateAndReactivateQueued_(): void;
    deactivate(): void;
    activateDirect(tool: Owned<Tool>): void;
}
export declare class LocalToolBinder<Context extends object = object> extends RefCounted {
    context: Context;
    globalBinder: GlobalToolBinder;
    bindings: Map<string, Tool<object>>;
    jsonToKey: Map<string, string>;
    changed: Signal<() => void>;
    constructor(context: Context, globalBinder: GlobalToolBinder);
    getSortOrder(): number;
    disposed(): void;
    get(key: string): Borrowed<Tool> | undefined;
    set(key: string, tool: Owned<Tool> | undefined): void;
    setJson(key: string, toolJson: any): void;
    removeJsonString(toolJsonString: string): void;
    toJSON(): any;
    getCommonToolProperties(): any;
    convertLocalJSONToPaletteJSON(toolJson: any): any;
    clear(): void;
    reset(): void;
    restoreState(obj: any): void;
}
export declare class LayerToolBinder<LayerType extends UserLayer> extends LocalToolBinder<LayerType> {
    getCommonToolProperties(): {
        layer: string;
        layerType: string | undefined;
    };
    convertLocalJSONToPaletteJSON(toolJson: any): any;
    getSortOrder(): number;
}
export declare function updateToolDragDropEffect(dragSource: ToolDragSource, dropEffect?: string, dropSamePalette?: boolean): void;
export declare class ToolBindingWidget<Context extends object> extends RefCounted {
    localBinder: LocalToolBinder<Context>;
    toolJson: any;
    dragElement: HTMLElement | undefined;
    paletteState: {
        tool: Tool<Context>;
        palette: ToolPalettePanel;
    } | undefined;
    element: HTMLDivElement;
    private toolJsonString;
    constructor(localBinder: LocalToolBinder<Context>, toolJson: any, dragElement: HTMLElement | undefined, paletteState?: {
        tool: Tool<Context>;
        palette: ToolPalettePanel;
    } | undefined);
    private updateView;
}
export declare function addToolKeyBindHandlers(context: RefCounted, element: HTMLElement, bindKey: (key: string) => void): void;
export declare function makeToolButton(context: RefCounted, localBinder: LocalToolBinder, options: {
    toolJson: any;
    label?: string;
    title?: string;
    dragElement?: HTMLElement;
}): HTMLDivElement;
export declare function makeToolActivationStatusMessage(activation: ToolActivation, options?: {
    showBindings?: boolean;
}): {
    message: StatusMessage;
    content: HTMLDivElement;
};
export declare function makeToolActivationStatusMessageWithHeader(activation: ToolActivation, options?: {
    showBindings?: boolean;
}): {
    message: StatusMessage;
    body: HTMLDivElement;
    header: HTMLDivElement;
};
export declare function getMatchingTools(globalBinder: GlobalToolBinder, query: Query, onChange?: () => void): Map<string, any>;
