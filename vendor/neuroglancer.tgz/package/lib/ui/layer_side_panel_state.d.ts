/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { UserLayer } from "#src/layer/index.js";
import { WatchableValue } from "#src/trackable_value.js";
import type { SidePanelLocation } from "#src/ui/side_panel_location.js";
import { TrackableSidePanelLocation } from "#src/ui/side_panel_location.js";
import { RefCounted } from "#src/util/disposable.js";
import { Signal } from "#src/util/signal.js";
export declare const SELECTED_LAYER_SIDE_PANEL_DEFAULT_LOCATION: {
    row: number;
    side: import("#src/ui/side_panel_location.js").Side;
    col: number;
    flex: number;
    size: number;
    minSize: number;
    visible: boolean;
};
export declare const LAYER_SIDE_PANEL_DEFAULT_LOCATION: {
    visible: boolean;
    row: number;
    side: import("#src/ui/side_panel_location.js").Side;
    col: number;
    flex: number;
    size: number;
    minSize: number;
};
export declare class UserLayerSidePanelState extends RefCounted {
    panels: UserLayerSidePanelsState;
    layer: UserLayer;
    location: TrackableSidePanelLocation;
    constructor(panels: UserLayerSidePanelsState);
    initialize(): void;
    tabsChanged: Signal<() => void>;
    selectedTab: WatchableValue<string | undefined>;
    explicitTabs: Set<string> | undefined;
    tabs: string[];
    normalizeTabs(): void;
    pin(): void;
    unpin(): void;
    splitOffTab(tab: string, location: SidePanelLocation): void;
    moveTabTo(tab: string, target: UserLayerSidePanelState): void;
    mergeInto(target: UserLayerSidePanelState): void;
}
export declare class UserLayerSidePanelsState {
    layer: UserLayer;
    panels: UserLayerSidePanelState[];
    specificationChanged: Signal<() => void>;
    updating: boolean;
    constructor(layer: UserLayer);
    restoreState(obj: unknown): void;
    removePanel(panel: UserLayerSidePanelState): void;
    updateTabs(): void;
    toJSON(): any;
}
