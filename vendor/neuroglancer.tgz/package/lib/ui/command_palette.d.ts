/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/command_palette.css";
import { Overlay } from "#src/overlay.js";
import type { CommandCatalog } from "#src/ui/command_catalog.js";
import type { Viewer } from "#src/viewer.js";
export declare class CommandPalette extends Overlay {
    private readonly catalog;
    private readonly actionDispatchTarget;
    private readonly searchInput;
    private readonly resultsList;
    private readonly rowElementByKey;
    private readonly emptyElement;
    private readonly pickerHeaderElement;
    private filteredRows;
    private filteredRowElements;
    private activeIndex;
    private currentGroup;
    private readonly keyHandlers;
    constructor(catalog: CommandCatalog, actionDispatchTarget: HTMLElement);
    private buildRows;
    private createRowElement;
    private computeDisplayRows;
    private computeCatalogRows;
    private rowElementFor;
    private render;
    private setActive;
    private updateHeader;
    private goBack;
    private closeAndRestoreFocus;
    private run;
}
/**
 * Binds the command palette to a viewer by handling the "open-command-palette"
 * action at the viewer element level, the same way every other global action
 * (e.g. "help") is bound. This intentionally
 * does not install any document-level key listener, so the palette opens from
 * the main viewer UI but does not intercept keystrokes globally.
 */
export declare function bindCommandPalette(viewer: Viewer): void;
