/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export type PropertyPredicate = {
    equals: string;
} | {
    regexp: RegExp;
};
export interface QueryRange {
    begin: number;
    end: number;
}
export interface QueryTerm {
    range: QueryRange;
    property: string;
    predicate: PropertyPredicate;
}
export interface QueryClause {
    include: boolean;
    range: QueryRange;
    terms: QueryTerm[];
}
export interface Query {
    clauses: QueryClause[];
}
export interface ParseError {
    range: QueryRange;
    message: string;
}
export interface PartialQuery {
    raw: string;
    query: Query;
    errors: ParseError[];
    endOffset: number;
}
export declare function parsePartialToolQuery(query: string): PartialQuery;
export declare function parseToolQuery(query: string): {
    query: Query;
} | {
    errors: ParseError[];
};
export declare function matchPredicate(predicate: PropertyPredicate, value: string): boolean;
export declare function matchesTerms(toolJson: any, terms: QueryTerm[]): boolean;
export interface QueryCompletion {
    offset: number;
    prefix: string;
    property?: string;
    include: boolean;
    completionQuery: Query;
}
export declare function getCompletionOffset(query: PartialQuery): number;
export declare function getQueryTermToComplete(query: PartialQuery): QueryCompletion;
export declare function getPropertyNameCompletions(completionQuery: Query, matches: Map<string, any>, prefix: string): [string, number][];
export declare function getPropertyValueCompletions(matches: Map<string, any>, property: string): [string, number][];
export declare const INCLUDE_EVERYTHING_QUERY: Query;
