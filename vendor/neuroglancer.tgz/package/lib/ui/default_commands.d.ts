/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Declarations of the built-in viewer commands.
 *
 * Each entry names an existing DOM action (`id` === the `action:` id dispatched
 * by the default input-event bindings) and gives it an explicit, human-readable
 * label and help description, so that consumers no longer have to prettify an
 * action id and can show commands that happen to have no binding at all.
 *
 * Commands whose behaviour is per-entity or otherwise dynamic (layer toggles,
 * tool activation) are contributed by the catalog at enumeration time and are
 * intentionally *not* declared here.
 *
 * This is the built-in *seed* set. It exists only because these commands
 * correspond to DOM actions that predate the registry. Feature code should NOT
 * add entries here; instead register commands colocated with the feature, for
 * its own lifetime, e.g.
 *
 *     this.registerDisposer(
 *       viewer.commandRegistry.register(
 *         new CallbackCommand("add-clip-plane", "Add Clip Plane", () =>
 *           this.addPlane(),
 *         ),
 *       ),
 *     );
 *
 * `register` returns a disposer, so commands may come and go with the feature
 * (e.g. per-layer).
 */
import { type CommandId } from "#src/ui/command.js";
import type { CommandRegistry } from "#src/ui/command_registry.js";
interface BuiltinCommand {
    readonly id: CommandId;
    readonly label: string;
    readonly description: string;
}
/** The built-in commands, in the order they are registered. */
export declare function getDefaultCommands(): readonly BuiltinCommand[];
/**
 * Registers the built-in commands into `registry`. Called once during default
 * viewer setup. The registry is owned (and disposed) by the viewer, so no
 * disposers are returned here, and the commands live for the viewer's lifetime.
 */
export declare function registerDefaultCommands(registry: CommandRegistry): void;
export {};
