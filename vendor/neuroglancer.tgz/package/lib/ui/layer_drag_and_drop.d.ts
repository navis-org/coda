/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { LayerListSpecification } from "#src/layer/index.js";
import { ManagedUserLayer } from "#src/layer/index.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import type { DragInfo } from "#src/util/drag_and_drop.js";
export interface LayerDragSourceInfo {
    manager: Owned<LayerListSpecification>;
    layers: Owned<ManagedUserLayer>[];
    layoutSpec: any;
    isLayerListPanel?: boolean;
}
export declare function startLayerDrag(event: DragEvent, sourceInfo: LayerDragSourceInfo): void;
export declare function endLayerDrag(dropEffect?: string): void;
export declare function getLayerDragInfo(event: DragEvent): DragInfo | undefined;
export declare class DropLayers {
    dragType: string | undefined;
    targetIsLayerListPanel: boolean;
    sourceManager: Borrowed<LayerListSpecification> | undefined;
    sourceIsLayerListPanel: boolean;
    moveSupported: boolean;
    forceCopy: boolean;
    manager: Borrowed<LayerListSpecification>;
    layers: Map<Owned<ManagedUserLayer>, number>;
    numSourceLayers: number;
    layoutSpec: any;
    /**
     * Called in the 'drop' event handler to actually initialize the layers if they are external.
     * Returns false if any layers failed to initialized.
     */
    initializeExternalLayers(event: DragEvent): boolean;
    updateArchiveStates(event: DragEvent): void;
    get method(): "link" | "copy" | "move";
    compatibleWithMethod(otherMethod: string): boolean;
}
type LayerDropEffect = "none" | "move" | "copy" | "link";
export declare function getLayerDropEffect(event: DragEvent, manager: Borrowed<LayerListSpecification>, targetIsLayerListPanel: boolean, newTarget: boolean): {
    dropEffect: LayerDropEffect;
    dropEffectMessage: string;
};
export declare function updateLayerDropEffect(event: DragEvent, manager: Borrowed<LayerListSpecification>, targetIsLayerListPanel: boolean, newTarget: boolean): {
    dropEffect: LayerDropEffect;
    dropEffectMessage: string;
};
export interface GetDropLayersOptions {
    forceCopy: boolean;
    newTarget: boolean;
    isLayerListPanel?: boolean;
}
export declare function getDropLayers(event: DragEvent, manager: Borrowed<LayerListSpecification>, options: GetDropLayersOptions): DropLayers | undefined;
export interface LayerBarDropInterface {
    element: HTMLElement;
    manager: LayerListSpecification;
    dropLayers: DropLayers | undefined;
    dragEnterCount: number;
}
export declare function registerLayerBarDropHandlers(panel: LayerBarDropInterface, target: EventTarget, targetLayer: ManagedUserLayer | undefined, isLayerListPanel?: boolean): void;
export declare function registerLayerDragHandlers(panel: LayerBarDropInterface, element: HTMLElement, layer: ManagedUserLayer, options: {
    getLayoutSpec: () => any;
    isLayerListPanel?: boolean;
}): void;
export declare function registerLayerBarDragLeaveHandler(panel: LayerBarDropInterface): void;
export {};
