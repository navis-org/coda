/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/selection_details.css";
import type { SelectedLayerState, TopLevelLayerListSpecification, TrackableDataSelectionState } from "#src/layer/index.js";
import type { SidePanelManager } from "#src/ui/side_panel.js";
import { SidePanel } from "#src/ui/side_panel.js";
import type { Borrowed } from "#src/util/disposable.js";
export declare function isWithinSelectionPanel(element: HTMLElement): Element | null;
export declare class SelectionDetailsPanel extends SidePanel {
    sidePanelManager: SidePanelManager;
    state: Borrowed<TrackableDataSelectionState>;
    manager: Borrowed<TopLevelLayerListSpecification>;
    selectedLayer: Borrowed<SelectedLayerState>;
    body: HTMLDivElement;
    constructor(sidePanelManager: SidePanelManager, state: Borrowed<TrackableDataSelectionState>, manager: Borrowed<TopLevelLayerListSpecification>, selectedLayer: Borrowed<SelectedLayerState>);
    close(): void;
}
export declare function copySelectionPositionToClipboard(state: TrackableDataSelectionState): void;
