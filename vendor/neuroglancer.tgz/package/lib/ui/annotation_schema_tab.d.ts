/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/annotation_schema_tab.css";
import type { AnnotationDisplayState } from "#src/annotation/annotation_layer_state.js";
import type { AnnotationNumericPropertySpec, AnnotationPropertySpec } from "#src/annotation/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { AnnotationPropertyType } from "#src/ui/annotation_properties.js";
import type { UserLayerWithAnnotations } from "#src/ui/annotations.js";
import { RefCounted, type Borrowed } from "#src/util/disposable.js";
import { Tab } from "#src/widget/tab_view.js";
export declare function sanitizeAnnotationPropertyIdentifier(rawValue: string): string;
export declare function ensureUniquePropertyIdentifier(suggestedIdentifier: string, identifiers: Iterable<string>): string;
declare class AnnotationUIProperty extends RefCounted {
    spec: AnnotationPropertySpec;
    private parentView;
    element: HTMLDivElement;
    private defaultValueCell;
    private defaultValueElements;
    private typeChangeDropdown;
    private typeChanged;
    isTypeDropdownExpanded: boolean;
    constructor(spec: AnnotationPropertySpec, parentView: AnnotationSchemaView);
    get readonly(): boolean;
    updateTableRowSize(hasEnums: boolean): void;
    private removeProperty;
    private renameProperty;
    private getPropertyByIdentifier;
    updateProperty(oldProperty: AnnotationPropertySpec, newProperty: Partial<AnnotationPropertySpec>): void;
    private createTableCell;
    private ensureUniquePropertyIdentifier;
    private getDisplayNameForType;
    updateDefaultValue(defaultValue: number): void;
    updateEnumLabels(enumProperty: AnnotationNumericPropertySpec, selectElement?: HTMLSelectElement): void;
    makeUI(): void;
    private createNameCell;
    private createTypeCell;
    private suggestEnumValue;
    private createDefaultValueCell;
    private createInputsForType;
    private createColorInputs;
    private createColorChangeFunction;
    private createBooleanInputs;
    private createEnumInputs;
    private createEnumDefaultSelector;
    private createNumericInputs;
    private createAddEnumButton;
    private createEnumEntry;
    private createEnumNameInput;
    private createEnumValueInput;
    private createEnumDeleteIcon;
    private addEnumValueChangeListener;
    private createFinalCell;
    private createInputElement;
    private createNumberInput;
    private setCommonInputAttributes;
    private createTypeTextElement;
    private showTypeChangeDropdown;
    private closeTypeDropdown;
    private clickOutsideDropdownHandler;
    private createDropdownElement;
    private handleTypeChange;
}
export declare class AnnotationSchemaView extends Tab {
    layer: Borrowed<UserLayerWithAnnotations>;
    displayState: AnnotationDisplayState;
    get annotationStates(): import("#src/ui/annotations.js").MergedAnnotationStates;
    private schemaTable;
    private schemaTableBody;
    private schemaTableAddButtonField;
    private schemaViewTextElement;
    private schemaPasteButton;
    private schemaUploadButton;
    private schema;
    private defaultValueHeaderCell;
    annotationUIProperties: Map<string, AnnotationUIProperty>;
    readonly: WatchableValueInterface<boolean>;
    textWidthCanvas: HTMLCanvasElement | null;
    private addPropertyDropdown;
    private fileInput;
    private pendingFileResolve;
    constructor(layer: Borrowed<UserLayerWithAnnotations>, displayState: AnnotationDisplayState);
    private createFileInput;
    private selectFile;
    private updateOnReadonlyChange;
    private updateAnnotationText;
    private updateElementVisibility;
    private makeUI;
    private updateSchemaRepresentation;
    private populateSchemaTable;
    private createSchemaTableHeader;
    private createAnnotationSchemaDropdown;
    private clickOutsideDropdownHandler;
    private closeAddPropertyDropdown;
    createTableCell: (content: string | HTMLElement, className?: string) => HTMLDivElement;
    getDisplayNameForType(type: AnnotationPropertyType, enumLabels?: string[]): string;
    createIconWrapper(type: AnnotationPropertyType, enumLabels?: string[], isEnum?: boolean): HTMLSpanElement;
    ensureUniquePropertyIdentifier(suggestedIdentifier: string): string;
    private getCategoryForType;
    getIconForType(type: AnnotationPropertyType, enumValues?: string[], isEnum?: boolean): string;
    includesEnumProperties(): boolean;
    private defaultValuePerType;
    private setupInitialEnumsIfNeeded;
    private get mutableSources();
    addProperty(property: AnnotationPropertySpec): void;
    removeProperty(propertyIdentifer: string): void;
    updateProperty(oldProperty: AnnotationPropertySpec, newPropertyValues: Partial<AnnotationPropertySpec>): void;
    private get jsonSchema();
    private downloadSchema;
    private uploadSchema;
    private copySchemaToClipboard;
    private applySchema;
    private pasteSchemaFromClipboard;
    private extractSchema;
    getPropertyByIdentifier(identifier: string): AnnotationPropertySpec | undefined;
    private updateView;
    dispose(): void;
}
export declare class AnnotationSchemaTab extends Tab {
    layer: Borrowed<UserLayerWithAnnotations>;
    private schemaView;
    constructor(layer: Borrowed<UserLayerWithAnnotations>);
}
export {};
