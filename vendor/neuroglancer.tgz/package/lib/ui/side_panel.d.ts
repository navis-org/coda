/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/side_panel.css";
import type { DisplayContext } from "#src/display_context.js";
import type { Side, SidePanelLocation } from "#src/ui/side_panel_location.js";
import { TrackableSidePanelLocation } from "#src/ui/side_panel_location.js";
import { RefCounted } from "#src/util/disposable.js";
import { Signal } from "#src/util/signal.js";
import { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
export declare const DRAG_OVER_CLASSNAME = "neuroglancer-drag-over";
type FlexDirection = "row" | "column";
export declare const SIZE_FOR_DIRECTION: Record<FlexDirection, "width" | "height">;
export declare class SidePanel extends RefCounted {
    sidePanelManager: SidePanelManager;
    location: TrackableSidePanelLocation;
    element: HTMLElement;
    visibility: WatchableVisibilityPriority;
    getDragDropDescription(): string;
    constructor(sidePanelManager: SidePanelManager, location?: TrackableSidePanelLocation);
    canCopy(): boolean;
    copyToNewLocation(location: SidePanelLocation): void;
    makeDragSource(): DragSource;
    close(): void;
    addTitleBar(options: {
        title?: string;
    }): {
        titleBar: HTMLDivElement;
        titleElement: HTMLElement | undefined;
        closeButton: HTMLElement;
    };
    addBody(body: HTMLElement): void;
}
export interface SidePanelDropLocation {
    side: Side;
    row: number;
    col: number;
}
export interface DragSource {
    canDropAsTabs?: (target: SidePanel) => number;
    dropAsTab?: (target: SidePanel) => void;
    dropAsNewPanel: (location: SidePanelDropLocation, dropEffect: DataTransfer["dropEffect"]) => void;
    getNewPanelDropEffect: (event: DragEvent) => {
        dropEffect: DataTransfer["dropEffect"];
        description: string;
        dropEffectMessage?: string;
        leaveHandler?: () => void;
    };
}
export interface RegisteredSidePanel {
    location: TrackableSidePanelLocation;
    makePanel: () => SidePanel;
    panel?: SidePanel | undefined;
}
export declare class SidePanelManager extends RefCounted {
    display: DisplayContext;
    center: HTMLElement;
    visibility: WatchableVisibilityPriority;
    element: HTMLDivElement;
    centerColumn: HTMLDivElement;
    beforeRender: Signal<() => void>;
    private sides;
    private registeredPanels;
    dragSource: DragSource | undefined;
    private layoutNeedsUpdate;
    private shouldResetFlexGroupSizes;
    get visible(): boolean;
    constructor(display: DisplayContext, center: HTMLElement, visibility?: WatchableVisibilityPriority);
    private makeSidePanelSideState;
    hasDroppablePanel(): boolean;
    startDrag(dragSource: DragSource, event: DragEvent): void;
    endDrag(): void;
    /**
     * Once a panel is added to a flex group, the panel no longer controls the
     * size of the flex group. This resets the flex group sizes so that
     * panels can set the size of the flex group. This is useful when
     * panel sizes are manually set from the JSON state.
     */
    reset(): void;
    private makeDropZone;
    registerPanel(registeredPanel: RegisteredSidePanel): () => void;
    unregisterPanel(registeredPanel: RegisteredSidePanel): void;
    disposed(): void;
    invalidateLayout: () => void;
    render(): void;
    private makeCrossGutter;
    private makeFlexGutter;
    private renderSide;
}
export {};
