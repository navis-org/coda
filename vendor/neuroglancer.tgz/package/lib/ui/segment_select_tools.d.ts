/**
 * /**
 * @license
 * This work is a derivative of the Google Neuroglancer project,
 * Copyright 2016 Google Inc.
 * The Derivative Work is covered by
 * Copyright 2021 Howard Hughes Medical Institute
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import type { ToolActivation } from "#src/ui/tool.js";
import { LayerTool } from "#src/ui/tool.js";
export declare const SELECT_SEGMENTS_TOOLS_ID = "selectSegments";
export declare class SelectSegmentsTool extends LayerTool<SegmentationUserLayer> {
    toJSON(): string;
    activate(activation: ToolActivation<this>): void;
    get description(): string;
}
export declare function registerSegmentSelectTools(contextType: typeof SegmentationUserLayer): void;
