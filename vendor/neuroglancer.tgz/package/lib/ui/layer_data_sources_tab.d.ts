/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Tab for showing layer data sources and coordinate transforms.
 */
import "#src/ui/layer_data_sources_tab.css";
import type { UserLayer, UserLayerConstructor } from "#src/layer/index.js";
import type { LayerDataSource, LoadedDataSubsource } from "#src/layer/layer_data_source.js";
import { LoadedLayerDataSource } from "#src/layer/layer_data_source.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { Borrowed } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { MessageList } from "#src/util/message_list.js";
import { AutocompleteTextInput } from "#src/widget/multiline_autocomplete.js";
import { Tab } from "#src/widget/tab_view.js";
declare class SourceUrlAutocomplete extends AutocompleteTextInput {
    dataSourceView: DataSourceView;
    dirty: WatchableValueInterface<boolean>;
    constructor(dataSourceView: DataSourceView);
    cancel(): boolean;
}
export declare class MessagesView extends RefCounted {
    model: MessageList;
    element: HTMLUListElement;
    generation: number;
    constructor(model: MessageList);
    updateView(): void;
}
export declare class DataSourceSubsourceView extends RefCounted {
    loadedSubsource: LoadedDataSubsource;
    element: HTMLDivElement;
    constructor(loadedSource: LoadedLayerDataSource, loadedSubsource: LoadedDataSubsource);
}
export declare class LoadedDataSourceView extends RefCounted {
    source: Borrowed<LoadedLayerDataSource>;
    element: HTMLDivElement;
    constructor(source: Borrowed<LoadedLayerDataSource>);
}
export declare class DataSourceView extends RefCounted {
    tab: Borrowed<LayerDataSourcesTab>;
    source: Borrowed<LayerDataSource>;
    element: HTMLDivElement;
    urlInput: SourceUrlAutocomplete;
    seenGeneration: number;
    generation: number;
    private loadedView;
    constructor(tab: Borrowed<LayerDataSourcesTab>, source: Borrowed<LayerDataSource>);
    updateView(): void;
    disposed(): void;
}
export declare class LayerDataSourcesTab extends Tab {
    layer: Borrowed<UserLayer>;
    generation: number;
    private sourceViews;
    private addDataSourceIcon;
    private layerTypeDetection;
    private multiChannelLayerCreate;
    private layerTypeElement;
    private dataSourcesContainer;
    private reRender;
    constructor(layer: Borrowed<UserLayer>);
    detectedLayerConstructor: UserLayerConstructor | undefined;
    updateLayerTypeDetection(): void;
    disposed(): void;
    private updateView;
}
export {};
