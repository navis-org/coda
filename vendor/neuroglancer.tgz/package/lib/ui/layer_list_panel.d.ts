/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/layer_list_panel.css";
import type { LayerManager, ManagedUserLayer, TopLevelLayerListSpecification } from "#src/layer/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { DropLayers } from "#src/ui/layer_drag_and_drop.js";
import type { SidePanelManager } from "#src/ui/side_panel.js";
import { SidePanel } from "#src/ui/side_panel.js";
import { TrackableSidePanelLocation } from "#src/ui/side_panel_location.js";
import { RefCounted } from "#src/util/disposable.js";
import type { Trackable } from "#src/util/trackable.js";
export declare class LayerListPanelState implements Trackable {
    location: TrackableSidePanelLocation;
    get changed(): import("../util/signal").Signal<() => void>;
    restoreState(obj: unknown): void;
    reset(): void;
    toJSON(): any;
}
export declare class LayerVisibilityWidget extends RefCounted {
    layer: ManagedUserLayer;
    element: HTMLDivElement;
    constructor(layer: ManagedUserLayer);
}
export declare class LayerListPanel extends SidePanel {
    manager: TopLevelLayerListSpecification;
    state: LayerListPanelState;
    layerPanelVisibility: WatchableValueInterface<boolean>;
    showLayerPanel?: WatchableValueInterface<boolean> | undefined;
    private items;
    itemContainer: HTMLDivElement;
    layerDropZone: HTMLDivElement;
    titleElement: HTMLElement;
    get layerManager(): LayerManager;
    get selectedLayer(): import("#src/layer/index.js").SelectedLayerState;
    dropLayers: DropLayers | undefined;
    dragEnterCount: number;
    private generation;
    constructor(sidePanelManager: SidePanelManager, manager: TopLevelLayerListSpecification, state: LayerListPanelState, layerPanelVisibility: WatchableValueInterface<boolean>, showLayerPanel?: WatchableValueInterface<boolean> | undefined);
    render(): void;
}
export declare class LayerArchiveCountWidget extends RefCounted {
    layerManager: LayerManager;
    element: HTMLDivElement;
    constructor(layerManager: LayerManager);
    private render;
}
