/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/ui/annotation_properties.css";
import type { AnnotationColorPropertySpec, AnnotationPropertySpec } from "#src/annotation/index.js";
import { WatchableValue } from "#src/trackable_value.js";
import type { vec3 } from "#src/util/geom.js";
import { ColorWidget } from "#src/widget/color.js";
export type AnnotationColorKey = AnnotationColorPropertySpec["type"];
export type AnnotationPropertyType = AnnotationPropertySpec["type"];
export declare const ANNOTATION_TYPES: AnnotationPropertyType[];
export declare function createTextAreaElement(inputValue: string, readonly: boolean): HTMLTextAreaElement;
export declare function isEnumType(enumLabels?: string[]): boolean;
export declare function makeBoolCheckbox(value: boolean | number, onChange?: (event: Event) => void): HTMLInputElement;
export declare function makeDescriptionIcon(description: string): HTMLElement;
export declare function makeReadonlyColorProperty(packColor: number, type: AnnotationColorKey): HTMLDivElement;
export declare function makeEditableColorProperty(packedColor: number, type: AnnotationColorKey): {
    element: HTMLElement;
    color: ColorWidget;
    model: WatchableValue<vec3>;
    alpha?: HTMLInputElement;
};
