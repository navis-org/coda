/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { Signal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
export type Side = "left" | "right" | "top" | "bottom";
export declare const DEFAULT_SIDE_PANEL_WIDTH = 300;
export declare const DEFAULT_MIN_SIDE_PANEL_WIDTH = 100;
export interface SidePanelLocation {
    side: Side;
    col: number;
    row: number;
    flex: number;
    size: number;
    minSize: number;
    visible: boolean;
}
export declare const DEFAULT_SIDE_PANEL_LOCATION: SidePanelLocation;
export declare class TrackableSidePanelLocation implements Trackable {
    defaultValue: SidePanelLocation;
    value: SidePanelLocation;
    changed: Signal<() => void>;
    locationChanged: Signal<() => void>;
    readonly watchableVisible: WatchableValueInterface<boolean>;
    constructor(defaultValue?: SidePanelLocation, value?: SidePanelLocation);
    toJSON(defaultValue?: SidePanelLocation): any;
    get visible(): boolean;
    set visible(visible: boolean);
    reset(): void;
    restoreState(obj: unknown, defaultLocation?: SidePanelLocation): void;
}
