/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @file UI menu for taking screenshots from the viewer.
 */
import "#src/ui/screenshot_menu.css";
import { FramedDialog } from "#src/overlay.js";
import type { ScreenshotManager } from "#src/util/screenshot_manager.js";
import { ScreenshotMode } from "#src/util/trackable_screenshot_mode.js";
import type { Viewer } from "#src/viewer.js";
/**
 * This menu allows the user to take a screenshot of the current view, with options to
 * set the filename, scale, and force the screenshot to be taken immediately.
 * Once a screenshot is initiated, the user is locked into the menu until the
 * screenshot is taken or cancelled, to prevent
 * the user from interacting with the viewer while the screenshot is being taken.
 *
 * The menu displays statistics about the current view, such as the number of loaded
 * chunks, GPU memory usage, and download speed. These are to inform the user about the
 * progress of the screenshot, as it may take some time to load all the data.
 *
 * The menu also displays the resolution of each panel in the viewer, as well as the resolution
 * of the voxels loaded for each Image, Volume, and Segmentation layer.
 * This is to inform the user about the the physical units of the data and panels,
 * and to help them decide on the scale of the screenshot.
 *
 * The screenshot menu supports keeping the slice view FOV fixed when changing the scale of the screenshot.
 * This will cause the viewer to zoom in or out to keep the same FOV in the slice view.
 * For example, an x2 scale will cause the viewer in slice views to zoom in by a factor of 2
 * such that when the number of pixels in the slice view is doubled, the FOV remains the same.
 */
export declare class ScreenshotDialog extends FramedDialog {
    private screenshotManager;
    private nameInput;
    private cancelScreenshotButton;
    private forceScreenshotButton;
    private statisticsTable;
    private panelResolutionTable;
    private layerResolutionTable;
    private statisticsContainer;
    private filenameInputContainer;
    private screenshotSizeText;
    private warningElement;
    private progressText;
    private scaleRadioButtonsContainer;
    private keepSliceFOVFixedCheckbox;
    private helpTooltips;
    private statisticsKeyToCellMap;
    private layerResolutionKeyToCellMap;
    private throttledUpdateTableStatistics;
    private screenshotWidth;
    private screenshotHeight;
    private screenshotPixelSize;
    constructor(screenshotManager: ScreenshotManager);
    dispose(): void;
    close(): void;
    private setupHelpTooltips;
    private initializeUI;
    private setupEventListeners;
    private createNameInput;
    private createButton;
    private createScaleRadioButtons;
    private createStatisticsTable;
    private createPanelResolutionTable;
    private populatePanelResolutionTable;
    private createLayerResolutionTable;
    private populateLayerResolutionTable;
    private forceScreenshot;
    private cancelScreenshot;
    private screenshot;
    private populateStatistics;
    private handleScreenshotResize;
    private updateScreenshotSizeDisplay;
    private parseStatistics;
    private generateScreenshotMetadataJson;
    private updateUIBasedOnMode;
    get screenshotMode(): ScreenshotMode;
}
export declare function bindScreenshotDialog(viewer: Viewer): void;
