/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpace, DimensionId } from "#src/coordinate_transform.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { mat3, mat4, quat, vec3 } from "#src/util/geom.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import { TrackableEnum } from "#src/util/trackable_enum.js";
export declare enum NavigationLinkType {
    LINKED = 0,
    RELATIVE = 1,
    UNLINKED = 2
}
export declare enum NavigationSimpleLinkType {
    LINKED = 0,
    UNLINKED = 2
}
export declare class TrackableNavigationLink extends TrackableEnum<NavigationLinkType> {
    constructor(value?: NavigationLinkType);
}
export declare class TrackableNavigationSimpleLink extends TrackableEnum<NavigationSimpleLinkType> {
    constructor(value?: NavigationSimpleLinkType);
}
export declare class Position extends RefCounted {
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    private coordinates_;
    private curCoordinateSpace;
    changed: NullarySignal;
    constructor(coordinateSpace: WatchableValueInterface<CoordinateSpace>);
    get valid(): boolean;
    /**
     * Returns the position in voxels.
     */
    get value(): Float32Array;
    reset(): void;
    set value(coordinates: Float32Array);
    private handleCoordinateSpaceChanged;
    toJSON(): number[] | undefined;
    restoreState(obj: any): void;
    snapToVoxel(): void;
    assign(other: Borrowed<Position>): void;
    /**
     * Get the offset of `a` relative to `b`.
     */
    static getOffset(a: Position, b: Position): Float32Array | undefined;
    static addOffset(target: Position, source: Position, offset: Float32Array | undefined, scale?: number): void;
    get legacyJsonView(): {
        changed: NullarySignal;
        toJSON(): number[] | undefined;
        reset(): void;
        restoreState(obj: unknown): void;
    };
}
export declare enum VelocityBoundaryBehavior {
    STOP = 0,
    LOOP = 1,
    REVERSE = 2
}
export declare const DEFAULT_PLAYBACK_VELOCITY = 10;
export declare class DimensionPlaybackVelocity {
    velocity: number;
    atBoundary: VelocityBoundaryBehavior;
    paused: boolean;
}
export declare function dimensionVelocitiesEqual(a: DimensionPlaybackVelocity, b: DimensionPlaybackVelocity): boolean;
export declare class CoordinateSpacePlaybackVelocity extends RefCounted {
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    private velocities_;
    private curCoordinateSpace;
    changed: NullarySignal;
    constructor(coordinateSpace: WatchableValueInterface<CoordinateSpace>);
    get valid(): boolean;
    get value(): (Readonly<DimensionPlaybackVelocity> | undefined)[];
    set value(velocities: (Readonly<DimensionPlaybackVelocity> | undefined)[]);
    get(id: DimensionId): DimensionPlaybackVelocity | undefined;
    dimensionVelocity(owner: RefCounted, id: DimensionId): WatchableValueInterface<DimensionPlaybackVelocity | undefined>;
    modifyDimension(id: DimensionId, callback: (oldInfo: DimensionPlaybackVelocity | undefined) => DimensionPlaybackVelocity | undefined): void;
    togglePlayback(id: DimensionId, newValue?: boolean | undefined): void;
    playbackEnabled(id: DimensionId): WatchableValueInterface<boolean>;
    multiplyVelocity(id: DimensionId, factor: number): void;
    private handleCoordinateSpaceChanged;
    toJSON(): Record<string, any> | undefined;
    reset(): void;
    restoreState(obj: any): void;
    assign(other: Borrowed<CoordinateSpacePlaybackVelocity>): void;
}
export declare class LinkedCoordinateSpacePlaybackVelocity extends RefCounted {
    peer: Owned<CoordinateSpacePlaybackVelocity>;
    positionLink: TrackableLinkInterface;
    changed: NullarySignal;
    velocity: CoordinateSpacePlaybackVelocity;
    constructor(peer: Owned<CoordinateSpacePlaybackVelocity>, positionLink: TrackableLinkInterface);
    toJSON(): Record<string, any> | undefined;
    reset(): void;
    restoreState(obj: unknown): void;
    copyToPeer(): void;
}
export declare class PlaybackManager extends RefCounted {
    display: {
        updateStarted: NullarySignal;
        scheduleRedraw(): void;
    };
    position: Position;
    velocity: CoordinateSpacePlaybackVelocity;
    private dimensionStates;
    private lastUpdateGeneration;
    private unregisterUpdateStartedCallback;
    constructor(display: {
        updateStarted: NullarySignal;
        scheduleRedraw(): void;
    }, position: Position, velocity: CoordinateSpacePlaybackVelocity);
    disposed(): void;
    private handleVelocityChanged;
    private updateStarted;
}
type TrackableLinkInterface = TrackableNavigationLink | TrackableNavigationSimpleLink;
interface LinkableState<T> extends RefCounted, Trackable {
    assign(other: T): void;
}
declare abstract class LinkedBase<T extends LinkableState<T>, Link extends TrackableLinkInterface = TrackableNavigationLink> implements Trackable {
    peer: Owned<T>;
    link: Link;
    value: T;
    get changed(): import("#src/util/signal.js").NullaryReadonlySignal;
    constructor(peer: Owned<T>, link?: Link);
    toJSON(): {
        link: string | undefined;
        value: any;
    } | undefined;
    protected getValueJson(): any;
    reset(): void;
    restoreState(obj: any): void;
    copyToPeer(): void;
}
declare abstract class SimpleLinkedBase<T extends RefCounted & Trackable & {
    assign(other: T): void;
}> extends LinkedBase<T, TrackableNavigationSimpleLink> implements Trackable {
}
export declare class LinkedPosition extends LinkedBase<Position> {
    value: Position;
}
export declare class OrientationState extends RefCounted {
    orientation: quat;
    changed: NullarySignal;
    constructor(orientation?: quat);
    toJSON(): any;
    restoreState(obj: any): void;
    reset(): void;
    snap(): void;
    /**
     * Returns a new OrientationState with orientation fixed to peerToSelf * peer.orientation.  Any
     * changes to the returned OrientationState will cause a corresponding change in peer, and vice
     * versa.
     */
    static makeRelative(peer: OrientationState, peerToSelf: quat): OrientationState;
    assign(other: Borrowed<OrientationState>): void;
}
export declare class LinkedOrientationState extends LinkedBase<OrientationState> {
    value: OrientationState;
}
export interface RelativeDisplayScales {
    /**
     * Array of length `coordinateSpace.rank` specifying scale factors on top of (will be multiply by)
     * `coordinateSpace.scales` to use for display purposes.  This allows non-uniform zooming.
     */
    factors: Float64Array;
}
export declare class TrackableRelativeDisplayScales extends RefCounted implements Trackable, WatchableValueInterface<RelativeDisplayScales> {
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    changed: NullarySignal;
    private curCoordinateSpace;
    private value_;
    constructor(coordinateSpace: WatchableValueInterface<CoordinateSpace>);
    get value(): RelativeDisplayScales;
    reset(): void;
    toJSON(): any;
    restoreState(json: unknown): void;
    setFactors(factors: Float64Array): void;
    private update;
    assign(other: TrackableRelativeDisplayScales): void;
}
export declare class LinkedRelativeDisplayScales extends LinkedBase<TrackableRelativeDisplayScales> {
    value: TrackableRelativeDisplayScales;
}
export interface DisplayDimensionRenderInfo {
    /**
     * Number of global dimensions.
     */
    globalRank: number;
    /**
     * Array of length `globalRank` specifying global dimension names.
     */
    globalDimensionNames: readonly string[];
    /**
     * Number of displayed dimensions.  Must be <= 3.
     */
    displayRank: number;
    /**
     * Array of length 3.  The first `displayRank` elements specify the indices of the the global
     * dimensions that are displayed.  The remaining elements are `-1`.
     */
    displayDimensionIndices: Int32Array;
    /**
     * Array of length 3.  `voxelPhysicalScales[i]` equals
     * `relativeDisplayScales[d] * coordinateSpace.scales[d]`,
     * where `d = displayDimensionIndices[i]`, or `1` for `i >= rank`.
     */
    voxelPhysicalScales: Float64Array;
    /**
     * Unit corresponding to each dimension in `displayDimensionIndices`.  `displayDimensionUnits[i]`
     * is equal to `coordinateSpace.units[displayDimensionIndices[i]]`, or `''` if
     * `displayDimensionIndices[i] == -1`.
     */
    displayDimensionUnits: readonly string[];
    /**
     * Scale corresponding to each dimension in `displayDimensionIndices`.
     * `displayDimensionScales[i]` is equal to `coordinateSpace.scales[displayDimensionIndices[i]]`,
     * or `1` if `displayDimensionIndices[i] == -1`.
     */
    displayDimensionScales: Float64Array;
    /**
     * Physical scale corresponding to the canonical voxel.  Equal to minimum of
     * `voxelPhysicalScales.slice(0, rank)`, or `1` if `rank == 0`.
     */
    canonicalVoxelPhysicalSize: number;
    /**
     * Array of length 3.  Amount by which the voxel coordinates of each display dimensions must be
     * multiplied to convert to canonical voxels.  canonicalVoxelFactors[i] = voxelPhysicalScales[d] /
     * canonicalVoxelPhysicalSize, where d = dimensionIndices[i], or `1` for `i >= rank`.
     */
    canonicalVoxelFactors: Float64Array;
}
export declare function displayDimensionRenderInfosEqual(a: DisplayDimensionRenderInfo, b: DisplayDimensionRenderInfo): boolean;
export declare function validateDisplayDimensionRenderInfoProperty(obj: {
    displayDimensionRenderInfo: DisplayDimensionRenderInfo;
}, expected: DisplayDimensionRenderInfo): boolean;
export declare class WatchableDisplayDimensionRenderInfo extends RefCounted {
    relativeDisplayScales: Owned<TrackableRelativeDisplayScales>;
    displayDimensions: Owned<TrackableDisplayDimensions>;
    changed: NullarySignal;
    private curRelativeDisplayScales;
    private curDisplayDimensions;
    private curCoordinateSpace;
    private value_;
    get value(): DisplayDimensionRenderInfo;
    constructor(relativeDisplayScales: Owned<TrackableRelativeDisplayScales>, displayDimensions: Owned<TrackableDisplayDimensions>);
}
export interface DisplayDimensions {
    coordinateSpace: CoordinateSpace;
    displayRank: number;
    displayDimensionIndices: Int32Array;
}
export declare class TrackableDisplayDimensions extends RefCounted implements Trackable {
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    changed: NullarySignal;
    private default_;
    private value_;
    constructor(coordinateSpace: WatchableValueInterface<CoordinateSpace>);
    get value(): DisplayDimensions;
    private update;
    private setToDefault;
    private assignValue;
    reset(): void;
    restoreState(obj: any): void;
    get default(): boolean;
    set default(value: boolean);
    setDimensionIndices(rank: number, dimensionIndices: Int32Array): void;
    toJSON(): string[] | undefined;
    assign(other: TrackableDisplayDimensions): void;
}
export declare class LinkedDisplayDimensions extends SimpleLinkedBase<TrackableDisplayDimensions> {
    value: TrackableDisplayDimensions;
}
export declare class DisplayPose extends RefCounted {
    position: Owned<Position>;
    displayDimensionRenderInfo: WatchableDisplayDimensionRenderInfo;
    orientation: Owned<OrientationState>;
    changed: NullarySignal;
    get displayDimensions(): Borrowed<TrackableDisplayDimensions>;
    get relativeDisplayScales(): Borrowed<TrackableRelativeDisplayScales>;
    constructor(position: Owned<Position>, displayDimensionRenderInfo: WatchableDisplayDimensionRenderInfo, orientation: Owned<OrientationState>);
    get valid(): boolean;
    /**
     * Resets everything.
     */
    reset(): void;
    updateDisplayPosition(fun: (pos: vec3) => boolean | void, temp?: vec3): boolean;
    toMat4(mat: mat4, zoom: number): void;
    toMat3(mat: mat3, zoom: number): void;
    /**
     * Snaps the orientation to the nearest axis-aligned orientation, and
     * snaps the position to the nearest voxel.
     */
    snap(): void;
    translateDimensionRelative(dimensionIndex: number, adjustment: number): void;
    translateVoxelsRelative(translation: vec3): void;
    rotateRelative(axis: vec3, angle: number): void;
    rotateAbsolute(axis: vec3, angle: number, fixedPoint: Float32Array): void;
    translateNonDisplayDimension(nonSpatialDimensionIndex: number, adjustment: number): void;
}
export type TrackableZoomInterface = TrackableProjectionZoom | TrackableCrossSectionZoom;
export declare class LinkedZoomState<T extends TrackableProjectionZoom | TrackableCrossSectionZoom> extends LinkedBase<T> {
    constructor(peer: Owned<T>, displayDimensionRenderInfo: Owned<WatchableDisplayDimensionRenderInfo>);
}
export declare function linkedStateLegacyJsonView<T extends LinkableState<T> & {
    readonly legacyJsonView: Trackable;
}>(linked: LinkedBase<T>): {
    changed: import("#src/util/signal.js").NullaryReadonlySignal;
    toJSON(): {
        link: string | undefined;
        value: any;
    } | undefined;
    restoreState(obj: unknown): void;
    reset(): void;
};
declare abstract class TrackableZoom extends RefCounted implements Trackable, WatchableValueInterface<number> {
    displayDimensionRenderInfo: Owned<WatchableDisplayDimensionRenderInfo>;
    readonly changed: NullarySignal;
    private curCanonicalVoxelPhysicalSize;
    private value_;
    protected legacyValue_: number;
    /**
     * Zoom factor.  For cross section views, in canonical voxels per viewport pixel.  For projection
     * views, in canonical voxels per viewport height (for orthographic projection).
     */
    get value(): number;
    set value(value: number);
    get canonicalVoxelPhysicalSize(): number;
    get coordinateSpaceValue(): CoordinateSpace;
    /**
     * Sets the zoom factor in the legacy units.  For cross section views, `1e-9` spatial units per
     * viewport pixel.  For projection views, `2 * 100 * Math.tan(Math.PI / 8) * 1e-9` spatial units
     * per viewport height (for orthographic projection).
     */
    set legacyValue(value: number);
    get legacyValue(): number;
    constructor(displayDimensionRenderInfo: Owned<WatchableDisplayDimensionRenderInfo>);
    handleCoordinateSpaceChanged(): void;
    protected abstract getDefaultValue(): number;
    toJSON(): number | undefined;
    restoreState(obj: any): void;
    reset(): void;
    get legacyJsonView(): {
        changed: NullarySignal;
        toJSON(): number | undefined;
        reset(): void;
        restoreState(obj: any): void;
    };
    setPhysicalScale(scaleInCanonicalVoxels: number, canonicalVoxelPhysicalSize: number): void;
    assign(source: TrackableZoomInterface): void;
}
export declare class TrackableCrossSectionZoom extends TrackableZoom {
    protected getDefaultValue(): number;
}
export declare class TrackableProjectionZoom extends TrackableZoom {
    protected getDefaultValue(): number;
}
export declare class TrackableDepthRange extends RefCounted implements WatchableValueInterface<number> {
    readonly defaultValue: number;
    displayDimensionRenderInfo: WatchableValueInterface<DisplayDimensionRenderInfo>;
    changed: NullarySignal;
    constructor(defaultValue: number, displayDimensionRenderInfo: WatchableValueInterface<DisplayDimensionRenderInfo>);
    private value_;
    canonicalVoxelPhysicalSize: number;
    get value(): number;
    set value(value: number);
    toJSON(): number | undefined;
    reset(): void;
    restoreState(obj: unknown): void;
    setValueAbsolute(value: number, sourceCanonicalVoxelPhysicalSize: number): void;
    assign(other: TrackableDepthRange): void;
}
export declare class LinkedDepthRange extends SimpleLinkedBase<TrackableDepthRange> {
    constructor(peer: Owned<TrackableDepthRange>, displayDimensionRenderInfo: WatchableValueInterface<DisplayDimensionRenderInfo>);
}
export declare class NavigationState<Zoom extends TrackableZoomInterface = TrackableZoomInterface> extends RefCounted {
    pose: Owned<DisplayPose>;
    zoomFactor: Owned<Zoom>;
    depthRange: Owned<TrackableDepthRange>;
    changed: NullarySignal;
    constructor(pose: Owned<DisplayPose>, zoomFactor: Owned<Zoom>, depthRange: Owned<TrackableDepthRange>);
    get coordinateSpace(): WatchableValueInterface<CoordinateSpace>;
    /**
     * Resets everything.
     */
    reset(): void;
    get position(): Position;
    get displayDimensions(): TrackableDisplayDimensions;
    get relativeDisplayScales(): TrackableRelativeDisplayScales;
    get displayDimensionRenderInfo(): WatchableDisplayDimensionRenderInfo;
    toMat4(mat: mat4): void;
    toMat3(mat: mat3): void;
    get relativeDepthRange(): number;
    get valid(): boolean;
    zoomBy(factor: number): void;
}
export {};
