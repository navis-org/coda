/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { DataType } from "#src/util/data_type.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
import type { ShaderBuilder, ShaderCodePart, ShaderProgram } from "#src/webgl/shader.js";
export declare const dataTypeShaderLerpParametersType: Record<DataType, string>;
export declare const glsl_dataTypeComputeInvlerp: Record<DataType, ShaderCodePart>;
export declare const glsl_dataTypeComputeLerp: Record<DataType, ShaderCodePart>;
export declare function defineInvlerpShaderFunction(builder: ShaderBuilder, name: string, dataType: DataType, clamp?: boolean): ShaderCodePart;
export declare function defineLerpShaderFunction(builder: ShaderBuilder, name: string, dataType: DataType): ShaderCodePart;
export declare function enableLerpShaderFunction(shader: ShaderProgram, name: string, dataType: DataType, interval: DataTypeInterval): void;
