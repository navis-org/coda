/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpaceCombiner } from "#src/coordinate_transform.js";
import type { TrackableValueInterface, WatchableValueInterface } from "#src/trackable_value.js";
import { TrackableValue, WatchableValue } from "#src/trackable_value.js";
import { DataType } from "#src/util/data_type.js";
import { RefCounted } from "#src/util/disposable.js";
import { vec3 } from "#src/util/geom.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import type { GL } from "#src/webgl/context.js";
import { HistogramSpecifications } from "#src/webgl/empirical_cdf.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
import { type ShaderStringLiteralIdMap } from "#src/webgl/shader_source_string_preprocessing.js";
import type { TransferFunctionParameters } from "#src/widget/transfer_function.js";
import { ControlPoint } from "#src/widget/transfer_function.js";
export interface ShaderSliderControl {
    type: "slider";
    valueType: "int" | "uint" | "float";
    min: number;
    max: number;
    step: number;
    default: number;
}
export interface ShaderColorControl {
    type: "color";
    valueType: "vec3";
    defaultString: string;
    default: vec3;
}
export interface ShaderImageInvlerpControl {
    type: "imageInvlerp";
    dataType: DataType;
    clamp: boolean;
    default: ImageInvlerpParameters;
}
export type PropertiesSpecification = Map<string, DataType>;
export interface ShaderPropertyInvlerpControl {
    type: "propertyInvlerp";
    clamp: boolean;
    properties: PropertiesSpecification;
    default: PropertyInvlerpParameters;
}
export interface ShaderCheckboxControl {
    type: "checkbox";
    valueType: "bool";
    default: boolean;
}
export type ShaderSelectValueType = "string_t" | "int" | "uint" | "float";
export type ShaderSelectValue = string | number;
export interface ShaderSelectOption {
    value: ShaderSelectValue;
    label?: string;
}
export interface ShaderSelectControl {
    type: "select";
    valueType: ShaderSelectValueType;
    options: ShaderSelectOption[];
    default: ShaderSelectValue;
}
export interface ShaderTransferFunctionControl {
    type: "transferFunction";
    dataType: DataType;
    default: TransferFunctionParameters;
}
export type ShaderUiControl = ShaderSliderControl | ShaderColorControl | ShaderImageInvlerpControl | ShaderPropertyInvlerpControl | ShaderCheckboxControl | ShaderSelectControl | ShaderTransferFunctionControl;
export interface ShaderControlParseError {
    line: number;
    message: string;
}
export interface ShaderControlsParseResult {
    source: string;
    code: string;
    controls: Controls;
    preprocessing: {
        stringLiteralIds: ShaderStringLiteralIdMap;
    };
    errors: ShaderControlParseError[];
}
export interface ShaderControlsBuilderState {
    key: string;
    parseResult: ShaderControlsParseResult;
    builderValues: ShaderBuilderValues;
    referencedProperties: string[];
}
export declare function stripComments(code: string): string;
type DirectiveParameters = Map<string, any>;
export declare function parseDirectiveParameters(input: string | undefined): {
    parameters: DirectiveParameters;
    errors: string[];
};
export declare function getShaderSelectOptionLabel(option: ShaderSelectOption): string;
export interface ImageDataSpecification {
    dataType: DataType;
    channelRank: number;
}
export interface ShaderDataContext {
    imageData?: ImageDataSpecification;
    properties?: Map<string, DataType>;
}
export declare function parseShaderUiControls(code: string, dataContext?: ShaderDataContext): ShaderControlsParseResult;
export type Controls = Map<string, ShaderUiControl>;
export declare function addControlsToBuilder(builderState: ShaderControlsBuilderState, builder: ShaderBuilder): void;
export declare class WatchableShaderUiControls implements WatchableValueInterface<Controls | undefined> {
    changed: NullarySignal;
    controls: Controls | undefined;
    get value(): Controls | undefined;
    set value(newControls: Controls | undefined);
}
export interface InvlerpParameters {
    range: DataTypeInterval;
    window: DataTypeInterval;
    autoCompute?: boolean;
}
export interface ImageInvlerpParameters extends InvlerpParameters {
    channel: number[];
}
export interface PropertyInvlerpParameters {
    range: DataTypeInterval | undefined;
    window: DataTypeInterval | undefined;
    property: string;
    dataType: DataType;
}
export declare function parseTransferFunctionParameters(obj: unknown, dataType: DataType, defaultValue: TransferFunctionParameters): TransferFunctionParameters;
export declare class TrackableTransferFunctionParameters extends TrackableValue<TransferFunctionParameters> {
    dataType: DataType;
    defaultValue: TransferFunctionParameters;
    constructor(dataType: DataType, defaultValue: TransferFunctionParameters);
    controlPointsToJson(controlPoints: ControlPoint[], dataType: DataType): (string | number | bigint)[][];
    toJSON(): {
        channel: number[] | undefined;
        defaultColor: string | undefined;
        window: string[] | [number, number] | [bigint, bigint] | undefined;
        controlPoints: (string | number | bigint)[][] | undefined;
    } | undefined;
}
export interface SingleShaderControlState {
    control: ShaderUiControl;
    trackable: TrackableValueInterface<any>;
    getBuilderValue: (value: any) => any;
}
export type ShaderControlMap = Map<string, SingleShaderControlState>;
export type ShaderBuilderValues = {
    [key: string]: any;
};
export declare function getFallbackBuilderState(parseResult: ShaderControlsParseResult): ShaderControlsBuilderState;
export declare class ShaderControlState extends RefCounted implements Trackable, WatchableValueInterface<ShaderControlMap> {
    fragmentMain: WatchableValueInterface<string>;
    dataContext: WatchableValueInterface<ShaderDataContext | null>;
    channelCoordinateSpaceCombiner?: CoordinateSpaceCombiner | undefined;
    changed: NullarySignal;
    controls: WatchableShaderUiControls;
    parseErrors: WatchableValueInterface<ShaderControlParseError[]>;
    processedFragmentMain: WatchableValueInterface<string>;
    parseResult: WatchableValueInterface<ShaderControlsParseResult>;
    builderState: WatchableValueInterface<ShaderControlsBuilderState>;
    histogramSpecifications: HistogramSpecifications;
    activeControls: WatchableValue<Set<string> | undefined>;
    private fragmentMainGeneration;
    private dataContextGeneration;
    private parseErrors_;
    private processedFragmentMain_;
    private parseResult_;
    private controlsGeneration;
    private parseResultChanged;
    private lastReportedProgram;
    constructor(fragmentMain: WatchableValueInterface<string>, dataContext?: WatchableValueInterface<ShaderDataContext | null>, channelCoordinateSpaceCombiner?: CoordinateSpaceCombiner | undefined);
    private handleFragmentMainChanged;
    reportLinkedShader(shader: ShaderProgram): void;
    private handleControlsChanged;
    private state_;
    get state(): ShaderControlMap;
    get value(): ShaderControlMap;
    private unparsedJson;
    restoreState(value: any): void;
    reset(): void;
    toJSON(): any;
}
export declare function setControlsInShader(gl: GL, shader: ShaderProgram, shaderControlState: ShaderControlState, parseResult: ShaderControlsParseResult): void;
export {};
