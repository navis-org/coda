/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { DataType } from "#src/util/data_type.js";
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import { FramebufferConfiguration, TextureBuffer } from "#src/webgl/offscreen.js";
import type { ShaderProgram } from "#src/webgl/shader.js";
import { ShaderBuilder } from "#src/webgl/shader.js";
export type ShaderIoType = "int" | "uint" | "float" | "bool" | DataType;
export interface FragmentShaderTestOutputs {
    [key: string]: ShaderIoType;
}
export type ShaderIoJavascriptType<T extends ShaderIoType> = T extends DataType ? T extends DataType.UINT64 ? bigint : number : T extends "bool" ? boolean : number;
export declare class FragmentShaderTester<Inputs extends FragmentShaderTestOutputs, Outputs extends FragmentShaderTestOutputs> extends RefCounted {
    gl: GL;
    inputs: Inputs;
    outputs: Outputs;
    builder: ShaderBuilder;
    private shader_;
    offscreenFramebuffer: FramebufferConfiguration<TextureBuffer>;
    private vertexPositionsBuffer;
    constructor(gl: GL, inputs: Inputs, outputs: Outputs);
    get shader(): ShaderProgram;
    build(): void;
    execute(inputValues?: {
        [P in keyof Inputs]: ShaderIoJavascriptType<Inputs[P]>;
    }): void;
    get values(): {
        [P in keyof Outputs]: ShaderIoJavascriptType<Outputs[P]>;
    };
    read(key: keyof Outputs): number | bigint | boolean;
}
export declare function fragmentShaderTest<Inputs extends FragmentShaderTestOutputs, Outputs extends FragmentShaderTestOutputs>(inputs: Inputs, outputs: Outputs, f: (tester: FragmentShaderTester<Inputs, Outputs>) => void): void;
