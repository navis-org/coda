/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file
 * Facilities for reading various data types from 2-D and 3-D WebGL textures.
 *
 * WebGL2 only supports 2-D and 3-D textures, and because implementations typically limit the size
 * of each dimension, a large 1-D array has to be fit to a rectangular 2-D texture, which may
 * require padding.
 */
import type { TypedArray, TypedNumberArray, TypedNumberArrayConstructor } from "#src/util/array.js";
import { DataType } from "#src/util/data_type.js";
import type { vec3 } from "#src/util/geom.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderCodePart, ShaderSamplerPrefix } from "#src/webgl/shader.js";
export type TextureAccessCoefficients = vec3;
export declare class TextureFormat {
    /**
     * Number of texels per multi-channel element.
     */
    texelsPerElement: number;
    /**
     * Texture internal format to specify when uploading the texture data.
     */
    textureInternalFormat: number;
    /**
     * Texture format to specify when uploading the texture data.
     */
    textureFormat: number;
    /**
     * Texel type to specify when uploading the texture data.
     */
    texelType: number;
    /**
     * Number of typed array elements per texel.
     */
    arrayElementsPerTexel: number;
    /**
     * TypedArray type that must be used when uploading the texture data.
     */
    arrayConstructor: TypedNumberArrayConstructor;
    samplerPrefix: ShaderSamplerPrefix;
}
export declare const integerTextureFormatForNumComponents: number[];
export declare const floatTextureFormatForNumComponents: number[];
export declare const textureSelectorForNumComponents: string[];
export declare const internalUint8FormatForNumComponents: number[];
export declare const internalInt8FormatForNumComponents: number[];
export declare const internalUint16FormatForNumComponents: number[];
export declare const internalInt16FormatForNumComponents: number[];
export declare const internalUint32FormatForNumComponents: number[];
export declare const internalInt32FormatForNumComponents: number[];
export declare const internalFloatFormatForNumComponents: number[];
export declare function getSamplerPrefixForDataType(dataType: DataType): ShaderSamplerPrefix;
/**
 * Fills in a OneDimensionalTextureFormat object with the suitable texture format for the specified
 * DataType and number of components.
 */
export declare function computeTextureFormat(format: TextureFormat, dataType: DataType, numComponents?: number): TextureFormat;
export declare function setOneDimensionalTextureData(gl: GL, format: TextureFormat, data: TypedArray): void;
export declare function setTwoDimensionalTextureData(gl: GL, format: TextureFormat, data: TypedNumberArray, width: number, height: number): void;
export declare function setThreeDimensionalTextureData(gl: GL, format: TextureFormat, data: TypedArray, width: number, height: number, depth: number): void;
export declare class OneDimensionalTextureAccessHelper {
    key: string;
    readTextureValue: string;
    constructor(key: string);
    defineShader(builder: ShaderBuilder): void;
    getReadTextureValueCode(texelsPerElement: number, samplerPrefix: ShaderSamplerPrefix): string[];
    getAccessor(functionName: string, samplerName: string, dataType: DataType, numComponents?: number): ShaderCodePart[];
}
export declare class TextureAccessHelper {
    key: string;
    textureDims: number;
    readTextureValue: string;
    constructor(key: string, textureDims: number);
    getReadTextureValueCode(texelsPerElement: number, samplerPrefix: ShaderSamplerPrefix): string;
    getAccessor(functionName: string, samplerName: string, dataType: DataType, numComponents?: number): ShaderCodePart[];
}
