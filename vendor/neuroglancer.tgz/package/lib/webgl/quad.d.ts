/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facilities for drawing quads in WebGL as two triangles.
 */
export declare const VERTICES_PER_QUAD = 6;
export declare const TRIANGLES_PER_QUAD = 2;
export declare const glsl_getQuadVertexPosition = "\nvec2 getQuadVertexPosition(vec2 lower, vec2 upper) {\n  const vec2 coeffs[] = vec2[](\n    vec2(0.0, 0.0),\n    vec2(0.0, 1.0),\n    vec2(1.0, 1.0),\n    vec2(1.0, 1.0),\n    vec2(1.0, 0.0),\n    vec2(0.0, 0.0)\n  );\n  int v = gl_VertexID % 6;\n  return mix(lower, upper, coeffs[v]);\n}\n";
export declare function drawQuads(gl: WebGL2RenderingContext, quadsPerInstance: number, numInstances: number): void;
