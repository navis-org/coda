/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facilities for drawing spheres in WebGL
 */
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare function getSphereVertexArray(latitudeBands: number, longitudeBands: number): Float32Array<ArrayBuffer>;
export declare function getSphereIndexArray(latitudeBands: number, longitudeBands: number): Uint16Array<ArrayBuffer>;
export declare class SphereRenderHelper extends RefCounted {
    private vertexBuffer;
    private indexBuffer;
    private numIndices;
    constructor(gl: GL, latitudeBands: number, longitudeBands: number);
    defineShader(builder: ShaderBuilder): void;
    draw(shader: ShaderProgram, numInstances: number): void;
}
