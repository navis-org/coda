/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { WatchableValue, TrackableValue } from "#src/trackable_value.js";
import type { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderCompilationError, ShaderLinkError, ShaderModule, ShaderProgram } from "#src/webgl/shader.js";
import { ShaderBuilder } from "#src/webgl/shader.js";
/**
 * undefined means shader has not been compiled.  null means shader was compiled successfully.
 */
export type WatchableShaderError = WatchableValue<ShaderCompilationError | ShaderLinkError | undefined | null>;
export declare function makeWatchableShaderError(): WatchableValue<ShaderCompilationError | ShaderLinkError | null | undefined>;
export type TrackableFragmentMain = TrackableValue<string>;
export declare function makeTrackableFragmentMain(value: string): TrackableValue<string>;
export interface ParameterizedShaderGetterResult<Parameters = any, ExtraParameters = any> {
    shader: ShaderProgram | null;
    fallback: boolean;
    parameters: Parameters;
    extraParameters: ExtraParameters;
}
export interface ParameterizedContextDependentShaderGetter<Context, Parameters, ExtraParameters = undefined> {
    (context: Context): ParameterizedShaderGetterResult<Parameters, ExtraParameters>;
}
export interface ParameterizedShaderOptions<Parameters = any, ExtraParameters = any> {
    memoizeKey: any;
    parameters: WatchableValueInterface<Parameters>;
    fallbackParameters?: WatchableValueInterface<Parameters> | undefined;
    shaderError?: WatchableShaderError | undefined;
    encodeParameters?: (p: Parameters) => any;
    extraParameters?: WatchableValueInterface<ExtraParameters>;
    encodeExtraParameters?: (p: ExtraParameters) => any;
}
export declare function parameterizedContextDependentShaderGetter<Context, ContextKey, Parameters, ExtraParameters = undefined>(refCounted: RefCounted, gl: GL, options: ParameterizedShaderOptions<Parameters, ExtraParameters> & {
    getContextKey: (context: Context) => ContextKey;
    defineShader: (builder: ShaderBuilder, context: Context, parameters: Parameters, extraParameters: ExtraParameters) => void;
    encodeContext?: (context: Context) => any;
}): ParameterizedContextDependentShaderGetter<Context, Parameters, ExtraParameters>;
export interface ParameterizedEmitterDependentShaderOptions<Parameters = any, ExtraParameters = any> extends ParameterizedShaderOptions<Parameters, ExtraParameters> {
    defineShader: (builder: ShaderBuilder, parameters: Parameters, extraParameters: ExtraParameters) => void;
}
export type ParameterizedEmitterDependentShaderGetter<Parameters = any, ExtraParameters = any> = ParameterizedContextDependentShaderGetter<ShaderModule, Parameters, ExtraParameters>;
export declare function parameterizedEmitterDependentShaderGetter<Parameters, ExtraParameters = undefined>(refCounted: RefCounted, gl: GL, options: ParameterizedEmitterDependentShaderOptions<Parameters, ExtraParameters>): ParameterizedEmitterDependentShaderGetter<Parameters, ExtraParameters>;
export declare function shaderCodeWithLineDirective(code: string, sourceStringNumber?: number, line?: number): string;
