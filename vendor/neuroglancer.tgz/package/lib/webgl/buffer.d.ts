/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Disposable } from "#src/util/disposable.js";
import { RefCountedValue } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { AttributeIndex } from "#src/webgl/shader.js";
export type BufferType = number;
export type WebGLDataType = number;
export type WebGLBufferUsage = number;
export declare class GLBuffer implements Disposable {
    gl: WebGL2RenderingContext;
    bufferType: BufferType;
    buffer: WebGLBuffer | null;
    constructor(gl: WebGL2RenderingContext, bufferType?: BufferType);
    bind(): void;
    bindToVertexAttrib(location: AttributeIndex, componentsPerVertexAttribute: number, attributeType?: WebGLDataType, normalized?: boolean, stride?: number, offset?: number): void;
    bindToVertexAttribI(location: AttributeIndex, componentsPerVertexAttribute: number, attributeType?: WebGLDataType, stride?: number, offset?: number): void;
    setData(data: ArrayBufferView, usage?: WebGLBufferUsage): void;
    dispose(): void;
    static fromData(gl: WebGL2RenderingContext, data: ArrayBufferView, bufferType?: BufferType, usage?: WebGLBufferUsage): GLBuffer;
}
export declare function getMemoizedBuffer(gl: GL, bufferType: number, getter: (...args: any[]) => ArrayBufferView, ...args: any[]): RefCountedValue<GLBuffer>;
