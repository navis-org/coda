/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { GL } from "#src/webgl/context.js";
/**
 * Sets parameters to make a texture suitable for use as a raw array: NEAREST
 * filtering, clamping.
 */
export declare function setRawTextureParameters(gl: WebGL2RenderingContext): void;
export declare function setRawTexture3DParameters(gl: WebGL2RenderingContext): void;
export declare function resizeTexture(gl: GL, texture: WebGLTexture | null, width: number, height: number, internalFormat?: number, format?: number, dataType?: number): void;
export declare function setTextureFromCanvas(gl: GL, texture: WebGLTexture | null, canvas: HTMLCanvasElement): void;
