/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { DataType } from "#src/util/data_type.js";
import type { ShaderBuilder, ShaderCodePart } from "#src/webgl/shader.js";
export declare const glsl_mixLinear = "\nfloat mixLinear(float x, float y, float a) { return mix(x, y, a); }\n";
export declare const glsl_hsvToRgb = "\nvec3 hueToRgb(float hue) {\n  float hue6 = hue * 6.0;\n  float r = abs(hue6 - 3.0) - 1.0;\n  float g = 2.0 - abs(hue6 - 2.0);\n  float b = 2.0 - abs(hue6 - 4.0);\n  return clamp(vec3(r, g, b), 0.0, 1.0);\n}\nvec3 hsvToRgb(vec3 c) {\n  vec3 hueRgb = hueToRgb(c.x);\n  return c.z * ((hueRgb - 1.0) * c.y + 1.0);\n}\n";
export declare const glsl_string = "\nstruct string_t {\n  highp uint value;\n};\n";
export declare const glsl_uint64 = "\nstruct uint64_t {\n  highp uvec2 value;\n};\nstruct uint64x2_t {\n  highp uvec4 value;\n};\nuint64_t mixLinear(uint64_t x, uint64_t y, float a) {\n  return x;\n}\nuint64_t toUint64(uint64_t x) { return x; }\n";
export declare const glsl_unpackUint64leFromUint32: string[];
export declare const glsl_equalUint64: string[];
export declare const glsl_compareLessThanUint64: string[];
export declare const glsl_subtractUint64: string[];
export declare const glsl_addUint64: string[];
export declare const glsl_addSaturateUint64: (string | string[])[];
export declare const glsl_subtractSaturateUint64: (string | string[])[];
export declare const glsl_shiftRightUint64: string[];
export declare const glsl_shiftLeftUint64: string[];
export declare const glsl_uint8: string[];
export declare const glsl_int8: string[];
export declare const glsl_float = "\nhighp float toRaw(highp float x) { return x; }\nhighp float toNormalized(highp float x) { return x; }\nvec2 toRaw(vec2 x) { return x; }\nvec2 toNormalized(vec2 x) { return x; }\nvec3 toRaw(vec3 x) { return x; }\nvec3 toNormalized(vec3 x) { return x; }\nvec4 toRaw(vec4 x) { return x; }\nvec4 toNormalized(vec4 x) { return x; }\n";
export declare const glsl_uint16: string[];
export declare const glsl_int16: string[];
export declare const glsl_uint32: string[];
export declare const glsl_int32: string[];
export declare const glsl_getFortranOrderIndex = "\nhighp int getFortranOrderIndex(ivec3 subscripts, ivec3 size) {\n  return subscripts.x + size.x * (subscripts.y + size.y * subscripts.z);\n}\n";
export declare const glsl_log2Exact = "\nhighp uint log2Exact(highp uint i) {\n  highp uint r;\n  r = uint((i & 0xAAAAAAAAu) != 0u);\n  r |= uint((i & 0xFFFF0000u) != 0u) << 4;\n  r |= uint((i & 0xFF00FF00u) != 0u) << 3;\n  r |= uint((i & 0xF0F0F0F0u) != 0u) << 2;\n  r |= uint((i & 0xCCCCCCCCu) != 0u) << 1;\n  return r;\n}\n";
export declare const glsl_clipLineToDepthRange = "\nbool clipLineToDepthRange(inout highp vec4 a, inout highp vec4 b) {\n  highp float tmin = 0.0, tmax = 1.0;\n  highp float k1 = b.w - a.w + a.z - b.z;\n  highp float k2 = a.w - b.w + a.z - b.z;\n  highp float q1 = (a.z - a.w) / k1;\n  highp float q2 = (a.z + a.w) / k2;\n  if (k1 > 0.0) tmin = max(tmin, q1);\n  else if (k1 < 0.0) tmax = min(tmax, q1);\n  if (k2 > 0.0) tmax = min(tmax, q2);\n  else if (k2 < 0.0) tmin = max(tmin, q2);\n  if (tmin <= tmax) {\n    highp vec4 tempA = a;\n    highp vec4 tempB = b;\n    a = mix(tempA, tempB, tmin);\n    b = mix(tempA, tempB, tmax);\n    return true;\n  }\n  return false;\n}\n";
export declare const glsl_simpleFloatHash = "\nhighp float simpleFloatHash(highp vec2 co) {\n    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);\n}\n";
export declare const glsl_shiftLeftSaturateUint32 = "\nhighp uint shiftLeftSaturate(highp uint x, int shiftAmount) {\n  highp uint result = x << shiftAmount;\n  if ((result >> shiftAmount) != x) return 0xffffffffu;\n  return result;\n}\n";
export declare const glsl_addSaturateUint32 = "\nhighp uint addSaturate(highp uint x, highp uint y) {\n  highp uint result = x + y;\n  if (result < x) return 0xffffffffu;\n  return result;\n}\n";
export declare const glsl_subtractSaturateUint32 = "\nhighp uint subtractSaturate(highp uint x, highp uint y) {\n  highp uint result = x - y;\n  if (result > x) return 0u;\n  return result;\n}\n";
export declare const glsl_addSaturateInt32: string[];
export declare const glsl_subtractSaturateInt32: string[];
export declare function getShaderType(dataType: DataType, numComponents?: number): string;
export declare const dataTypeShaderDefinition: Record<DataType, ShaderCodePart>;
export declare function getShaderVectorType(typeName: "float" | "int" | "uint", n: number): string;
export declare const webglTypeSizeInBytes: {
    [webglType: number]: number;
};
export declare function defineVectorArrayVertexShaderInput(builder: ShaderBuilder, typeName: "float" | "int" | "uint", attributeType: number, normalized: boolean, name: string, vectorRank: number, arraySize?: number): void;
