/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { RefCounted } from "#src/util/disposable.js";
import { GLBuffer } from "#src/webgl/buffer.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare class CountingBuffer extends RefCounted {
    gl: GL;
    length: number | undefined;
    webglType: number | undefined;
    buffer: GLBuffer;
    constructor(gl: GL);
    resize(length: number): void;
    ensure(length: number): this;
    bindToVertexAttrib(location: number): void;
    bind(shader: ShaderProgram, divisor?: number): void;
}
export declare function disableCountingBuffer(gl: GL, shader: ShaderProgram, instanced?: boolean): void;
export declare function getCountingBuffer(gl: GL): CountingBuffer;
export declare function countingBufferShaderModule(builder: ShaderBuilder): void;
/**
 * Helper class for using a buffer containing uint32 index values as a vertex attribute.
 */
export declare class IndexBufferAttributeHelper {
    name: string;
    constructor(name: string);
    defineShader(builder: ShaderBuilder): void;
    bind(buffer: GLBuffer, shader: ShaderProgram): void;
    disable(shader: ShaderProgram): void;
}
export declare function makeIndexBuffer(gl: WebGL2RenderingContext, data: Uint32Array): GLBuffer;
