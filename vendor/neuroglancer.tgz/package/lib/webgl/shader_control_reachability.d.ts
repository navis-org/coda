/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ShaderProgram } from "#src/webgl/shader.js";
import type { ShaderControlsParseResult } from "#src/webgl/shader_ui_controls.js";
export declare function computeActiveControls(shader: ShaderProgram, parseResult: ShaderControlsParseResult): Set<string>;
export declare function activeControlsEqual(a: Set<string> | undefined, b: Set<string> | undefined): boolean;
