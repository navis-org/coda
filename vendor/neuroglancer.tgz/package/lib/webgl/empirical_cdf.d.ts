/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Defines facilities for GPU computation of empirical cumulative distribution functions.
 *
 * This is based on the technique described in
 * http://shaderwrangler.com/publications/histogram/
 *
 * In particular, the "scatter" operation required to compute a histogram is performed by
 * rendering point primitives.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
import { VisibilityPriorityAggregator } from "#src/visibility_priority/frontend.js";
import type { GL } from "#src/webgl/context.js";
import type { TextureBuffer } from "#src/webgl/offscreen.js";
import { FramebufferConfiguration } from "#src/webgl/offscreen.js";
export interface HistogramChannelSpecification {
    channel: Uint32Array;
}
export declare class HistogramSpecifications extends RefCounted {
    channels: WatchableValueInterface<HistogramChannelSpecification[]>;
    properties: WatchableValueInterface<string[]>;
    bounds: WatchableValueInterface<DataTypeInterval[]>;
    visibility: VisibilityPriorityAggregator;
    framebuffers: FramebufferConfiguration<TextureBuffer>[];
    producerVisibility: VisibilityPriorityAggregator;
    frameNumber: number;
    constructor(channels: WatchableValueInterface<HistogramChannelSpecification[]>, properties: WatchableValueInterface<string[]>, bounds: WatchableValueInterface<DataTypeInterval[]>, visibility?: VisibilityPriorityAggregator);
    getFramebuffers(gl: GL): FramebufferConfiguration<TextureBuffer, import("#src/webgl/offscreen.js").DepthRenderbuffer | import("#src/webgl/offscreen.js").DepthTextureBuffer>[];
    get visibleHistograms(): number;
    disposed(): void;
}
/**
 * Generates a histogram from a single-channel uint8 texture.
 */
export declare class TextureHistogramGenerator extends RefCounted {
    gl: GL;
    private shader;
    private inputIndexBuffer;
    constructor(gl: GL);
    static get(gl: GL): TextureHistogramGenerator;
    compute(count: number, depthTexture: WebGLTexture | null, inputTextures: TextureBuffer[], histogramSpecifications: HistogramSpecifications, frameNumber: number): void;
}
export declare function copyHistogramToCPU(gl: GL): Float32Array<ArrayBuffer>;
