/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Ellipse-related shader functions.
 */
import type { mat3, vec3 } from "#src/util/geom.js";
import { vec2 } from "#src/util/geom.js";
/**
 * Specifies the parameters of an ellipse in quadratic form.
 */
export declare const glsl_EllipseQuadraticForm = "\nstruct EllipseQuadraticForm {\n  highp float A;  // x*x coefficient\n  highp float B;  // x*y coefficient\n  highp float C;  // y*y coefficient\n  highp float D;  // x coefficient\n  highp float E;  // y coefficient\n  highp float F;  // 1 coefficient\n};\n";
/**
 * Given a 3-d ellipsoid, finds the ellipse corresponding to the z=0 cross-section.
 * @param A The positive semi-definite matrix defining the ellipsoid shape.
 * @param c The centroid.
 */
export declare const glsl_computeCrossSectionEllipse: string[];
export declare function computeCrossSectionEllipseDebug(Ao: mat3, c: vec3): {
    A: number;
    B: number;
    C: number;
    D: number;
    E: number;
    F: number;
};
export declare const glsl_CenterOrientEllipse = "\nstruct CenterOrientEllipse {\n  vec2 k;   // center\n  vec2 u1;  // minor axis direction\n  vec2 u2;  // major axis direction\n  float a;  // semimajor axis\n  float b;  // semiminor axis\n  bool valid; // indicates if the ellipse is valid\n};\n";
/**
 * Compute the center-orient parameterization of an ellipse from the quadratic parameterization.
 *
 * See: https://www.geometrictools.com/Documentation/InformationAboutEllipses.pdf
 */
export declare const glsl_computeCenterOrientEllipse: string[];
export declare function computeCenterOrientEllipseDebug(p: {
    A: number;
    B: number;
    C: number;
    D: number;
    E: number;
    F: number;
}): {
    k: vec2;
    u1: vec2;
    u2: vec2;
    a: number;
    b: number;
    lambda1: number;
    lambda2: number;
    m11: number;
    m12: number;
    m22: number;
    valid: boolean;
};
