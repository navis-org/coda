/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderModule, ShaderProgram } from "#src/webgl/shader.js";
export declare abstract class SizeManaged extends RefCounted {
    width: number;
    height: number;
    hasSize(width: number, height: number): boolean;
    resize(width: number, height: number): void;
    protected abstract performResize(): void;
}
export declare class Renderbuffer extends SizeManaged {
    gl: GL;
    internalformat: number;
    renderbuffer: WebGLRenderbuffer | null;
    constructor(gl: GL, internalformat: number);
    protected performResize(): void;
    disposed(): void;
    attachToFramebuffer(attachment: number): void;
}
export declare class DepthRenderbuffer extends Renderbuffer {
    gl: GL;
    includeStencilBuffer: boolean;
    constructor(gl: GL, includeStencilBuffer?: boolean);
    attachToFramebuffer(): void;
}
export declare class DepthStencilRenderbuffer extends DepthRenderbuffer {
    constructor(gl: GL);
}
export declare const StencilRenderbuffer: typeof DepthStencilRenderbuffer;
export declare class Framebuffer extends RefCounted {
    gl: GL;
    framebuffer: WebGLFramebuffer;
    constructor(gl: GL);
    disposed(): void;
    bind(): void;
    unbind(): void;
}
export declare class TextureBuffer extends SizeManaged {
    gl: GL;
    internalFormat: number;
    format: number;
    dataType: number;
    texture: WebGLTexture | null;
    constructor(gl: GL, internalFormat: number, format: number, dataType: number);
    protected performResize(): void;
    disposed(): void;
    attachToFramebuffer(attachment: number): void;
}
export declare class DepthTextureBuffer extends TextureBuffer {
    constructor(gl: GL, internalFormat?: number, format?: number, dataType?: number);
    attachToFramebuffer(): void;
}
export declare function makeTextureBuffers(gl: GL, count: number, internalFormat?: number, format?: number, dataType?: number): TextureBuffer[];
export declare class FramebufferConfiguration<ColorBuffer extends TextureBuffer | Renderbuffer = TextureBuffer | Renderbuffer, DepthBuffer extends DepthTextureBuffer | DepthRenderbuffer = DepthTextureBuffer | DepthRenderbuffer> extends RefCounted {
    gl: GL;
    width: number;
    height: number;
    colorBuffers: ColorBuffer[];
    framebuffer: Framebuffer;
    depthBuffer: DepthBuffer | undefined;
    fullAttachmentList: number[];
    private attachmentVerified;
    singleAttachmentList: 36064[];
    constructor(gl: GL, configuration: {
        framebuffer?: Framebuffer;
        colorBuffers: ColorBuffer[];
        depthBuffer?: DepthBuffer;
    });
    hasSize(width: number, height: number): boolean;
    bind(width: number, height: number): void;
    bindSingle(textureIndex: number): void;
    unbind(): void;
    readPixelFloat32IntoBuffer(textureIndex: number, glWindowX: number, glWindowY: number, offset: number, width?: number, height?: number): void;
    verifyAttachment(): void;
}
export declare class OffscreenCopyHelper extends RefCounted {
    gl: GL;
    shader: ShaderProgram;
    constructor(gl: GL, shader: ShaderProgram);
    private copyVertexPositionsBuffer;
    private copyTexCoordsBuffer;
    draw(...textures: (WebGLTexture | null)[]): void;
    static get(gl: GL, shaderModule?: ShaderModule, numTextures?: number): OffscreenCopyHelper;
}
