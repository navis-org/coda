/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DataType } from "#src/util/data_type.js";
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ControlPointTexture, SortedControlPoints } from "#src/widget/transfer_function.js";
export declare enum ShaderType {
    VERTEX,
    FRAGMENT
}
export interface ShaderErrorMessage {
    file?: number;
    line?: number;
    message: string;
}
/**
 * Parses the output of getShaderInfoLog into a list of messages.
 */
export declare function parseShaderErrors(log: string): ShaderErrorMessage[];
export declare class ShaderCompilationError extends Error {
    shaderType: ShaderType;
    source: string;
    log: string;
    errorMessages: ShaderErrorMessage[];
    constructor(shaderType: ShaderType, source: string, log: string, errorMessages: ShaderErrorMessage[]);
}
export declare class ShaderLinkError extends Error {
    vertexSource: string;
    fragmentSource: string;
    log: string;
    constructor(vertexSource: string, fragmentSource: string, log: string);
}
export declare function getShader(gl: WebGL2RenderingContext, source: string, shaderType: ShaderType): WebGLShader;
export type AttributeIndex = number;
export type AttributeType = number;
export interface VertexShaderInputBinder {
    enable(divisor: number): void;
    disable(): void;
    bind(stride: number, offset: number): void;
}
export declare class ShaderProgram extends RefCounted {
    gl: GL;
    vertexSource: string;
    fragmentSource: string;
    program: WebGLProgram;
    vertexShader: WebGLShader;
    fragmentShader: WebGLShader;
    attributes: Map<string, number>;
    uniforms: Map<string, WebGLUniformLocation | null>;
    textureUnits: Map<any, number>;
    vertexShaderInputBinders: {
        [name: string]: VertexShaderInputBinder;
    };
    vertexDebugOutputs?: VertexDebugOutput[];
    transferFunctionTextures: Map<any, ControlPointTexture>;
    constructor(gl: GL, vertexSource: string, fragmentSource: string, uniformNames?: string[], attributeNames?: string[], vertexDebugOutputs?: VertexDebugOutput[]);
    uniform(name: string): WebGLUniformLocation | null;
    attribute(name: string): number;
    textureUnit(symbol: symbol | string): number;
    bind(): void;
    bindAndUpdateTransferFunctionTexture(symbol: symbol | string, sortedControlPoints: SortedControlPoints, dataType: DataType, lookupTableSize: number): number | undefined;
    unbindTransferFunctionTextures(): void;
    disposed(): void;
}
export declare function drawArraysInstanced(gl: WebGL2RenderingContext, mode: number, first: number, count: number, instanceCount: number): void;
export type ShaderCodePart = string | ShaderCodePartArray | ShaderCodePartFunction;
interface ShaderCodePartFunction {
    (): ShaderCodePart;
}
type ShaderCodePartArray = Array<ShaderCodePart>;
export declare class ShaderCode {
    code: string;
    parts: Set<ShaderCodePart>;
    add(x: ShaderCodePart): void;
    toString(): string;
}
export type ShaderInitializer = (x: ShaderProgram) => void;
export type ShaderModule = (x: ShaderBuilder) => void;
export type ShaderSamplerPrefix = "i" | "u" | "";
export type ShaderSamplerType = "sampler2D" | "usampler2D" | "isampler2D" | "sampler3D" | "usampler3D" | "isampler3D";
export type ShaderInterpolationMode = "" | "centroid" | "flat centroid" | "smooth centroid" | "flat" | "smooth";
export declare const textureTargetForSamplerType: {
    sampler2D: 3553;
    isampler2D: 3553;
    usampler2D: 3553;
    sampler3D: 32879;
    isampler3D: 32879;
    usampler3D: 32879;
};
export type DebugOutputType = "float" | "vec2" | "vec3" | "vec4";
interface VertexDebugOutput {
    typeName: DebugOutputType;
    name: string;
}
export declare class ShaderBuilder {
    gl: GL;
    private nextSymbolID;
    private nextTextureUnit;
    private uniformsCode;
    private attributesCode;
    private varyingsCodeVS;
    private varyingsCodeFS;
    private fragmentExtensionsSet;
    private fragmentExtensions;
    private vertexCode;
    private vertexMain;
    private fragmentCode;
    private outputBufferCode;
    private fragmentMain;
    private required;
    private uniforms;
    private attributes;
    private initializers;
    private textureUnits;
    private vertexDebugOutputs;
    constructor(gl: GL);
    addVertexPositionDebugOutput(): void;
    addVertexDebugOutput(typeName: DebugOutputType, name: string): void;
    allocateTextureUnit(symbol: symbol | string, count?: number): number;
    addTextureSampler(samplerType: ShaderSamplerType, name: string, symbol: symbol | string, extent?: number): number;
    symbol(name: string): string;
    addAttribute(typeName: string, name: string, location?: number): string;
    addVarying(typeName: string, name: string, interpolationMode?: ShaderInterpolationMode): void;
    addOutputBuffer(typeName: string, name: string, location: number | null): void;
    addUniform(typeName: string, name: string, extent?: number): string;
    addFragmentExtension(name: string): void;
    addVertexCode(code: ShaderCodePart): void;
    addFragmentCode(code: ShaderCodePart): void;
    setVertexMain(code: string): void;
    addVertexMain(code: string): void;
    setFragmentMain(code: string): void;
    setFragmentMainFunction(code: string): void;
    addInitializer(f: ShaderInitializer): void;
    require(f: ShaderModule): void;
    build(): ShaderProgram;
}
export declare function shaderContainsIdentifiers(code: string, identifiers: Iterable<string>): Set<string>;
export {};
