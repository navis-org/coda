/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare const EDGES_PER_BOX = 12;
export declare const CORNERS_PER_BOX = 8;
export declare const FACES_PER_BOX = 6;
export declare const glsl_getBoxFaceVertexPosition = "\nvec3 getBoxFaceVertexPosition(int vertexIndex) {\n  const vec3 vertexPositions[] = vec3[](\n  // Front face\n  vec3(0.0, 0.0,  1.0), // 0\n  vec3(1.0, 0.0,  1.0), // 1\n  vec3(1.0,  1.0,  1.0), // 2\n  vec3(0.0,  1.0,  1.0), // 3\n\n  // Back face\n  vec3(0.0, 0.0, 0.0), // 4\n  vec3(0.0,  1.0, 0.0), // 5\n  vec3(1.0,  1.0, 0.0), // 6\n  vec3(1.0, 0.0, 0.0), // 7\n\n  // Top face\n  vec3(0.0,  1.0, 0.0), // 8\n  vec3(0.0,  1.0,  1.0), // 9\n  vec3(1.0,  1.0,  1.0), // 10\n  vec3(1.0,  1.0, 0.0), // 11\n\n  // Bottom face\n  vec3(0.0, 0.0, 0.0), // 12\n  vec3( 1.0, 0.0, 0.0), // 13\n  vec3( 1.0, 0.0,  1.0), // 14\n  vec3(0.0, 0.0,  1.0), // 15\n\n  // Right face\n  vec3( 1.0, 0.0, 0.0), // 16\n  vec3( 1.0,  1.0, 0.0), // 17\n  vec3( 1.0,  1.0,  1.0), // 18\n  vec3( 1.0, 0.0,  1.0), // 19\n\n  // Left face\n  vec3(0.0, 0.0, 0.0), // 20\n  vec3(0.0, 0.0,  1.0), // 21\n  vec3(0.0,  1.0,  1.0), // 22\n  vec3(0.0,  1.0, 0.0) // 23\n  );\n  const int indices[] = int[](\n    0,  1,  2,      0,  2,  3,    // front\n    4,  5,  6,      4,  6,  7,    // back\n    8,  9,  10,     8,  10, 11,   // top\n    12, 13, 14,     12, 14, 15,   // bottom\n    16, 17, 18,     16, 18, 19,   // right\n    20, 21, 22,     20, 22, 23   // left\n  );\n  return vertexPositions[indices[vertexIndex]];\n}\n";
export declare const glsl_getBoxEdgeVertexPosition = "\nvec3 getBoxEdgeVertexPosition(int vertexIndex) {\n  // 12 edges \u00D7 2 endpoints = 24\n  const int edgeTable[24] = int[24](\n    0,1, 2,3, 4,5, 6,7,\n    0,2, 1,3, 4,6, 5,7,\n    0,4, 1,5, 2,6, 3,7\n  );\n  // Order is x, y, z, so at\n  // corner i: x=i&1, y=(i>>1)&1, z=(i>>2)&1\n  // for example, corner 5 is 0101 in binary, so x=1, y=0, z=1\n  int corner = edgeTable[vertexIndex];\n  return vec3(float(corner & 1), float((corner >> 1) & 1), float((corner >> 2) & 1));\n}\n";
export declare function drawBoxEdges(gl: WebGL2RenderingContext, boxesPerInstance: number, numInstances: number): void;
export declare function drawBoxes(gl: WebGL2RenderingContext, boxesPerInstance: number, numInstances: number): void;
