/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare const VERTICES_PER_LINE = 6;
export declare function defineLineShader(builder: ShaderBuilder, rounded?: boolean): void;
export declare function drawLines(gl: WebGL2RenderingContext, linesPerInstance: number, numInstances: number): void;
export declare function initializeLineShader(shader: ShaderProgram, projectionParameters: {
    width: number;
    height: number;
}, featherWidthInPixels: number): void;
