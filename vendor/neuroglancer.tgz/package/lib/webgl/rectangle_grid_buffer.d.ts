/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { GL } from "#src/webgl/context.js";
/**
 * Create a Float32Array of vertices gridded in a rectangle
 * Only grids along the x-axis are created, the y-axis is assumed to be the same for all grids
 */
export declare function createGriddedRectangleArray(numGrids: number, startX?: number, endX?: number, startY?: number, endY?: number): Float32Array;
/**
 * Get a buffer of vertices representing a rectangle that is gridded
 * along the x dimension, useful for drawing grids, such as a lookup table / heatmap
 */
export declare function getGriddedRectangleBuffer(gl: GL, numGrids: number, startX?: number, endX?: number, startY?: number, endY?: number): import("#src/webgl/buffer.js").GLBuffer;
