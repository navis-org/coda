/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { LayerChunkProgressInfo } from "#src/chunk_manager/base.js";
import { RenderViewport } from "#src/display_context.js";
import type { LayerView, MouseSelectionState, PickState, UserLayer, VisibleLayerInfo } from "#src/layer/index.js";
import type { DisplayDimensionRenderInfo, NavigationState } from "#src/navigation_state.js";
import type { PickIDManager } from "#src/object_picking.js";
import { ProjectionParameters } from "#src/projection_parameters.js";
import type { RenderLayerTransformOrError } from "#src/render_coordinate_transform.js";
import type { WatchableValueChangeInterface } from "#src/trackable_value.js";
import { WatchableSet } from "#src/trackable_value.js";
import type { Borrowed } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { mat4 } from "#src/util/geom.js";
import { MessageList } from "#src/util/message_list.js";
import { NullarySignal, Signal } from "#src/util/signal.js";
import { VisibilityPriorityAggregator } from "#src/visibility_priority/frontend.js";
import type { RPC } from "#src/worker_rpc.js";
import { SharedObject } from "#src/worker_rpc.js";
export declare enum RenderLayerRole {
    DATA = 0,
    ANNOTATION = 1,
    DEFAULT_ANNOTATION = 2
}
export declare function allRenderLayerRoles(): WatchableSet<RenderLayerRole>;
export declare class RenderLayer extends RefCounted {
    userLayer: UserLayer | undefined;
    role: RenderLayerRole;
    messages: MessageList;
    layerChanged: NullarySignal;
    redrawNeeded: NullarySignal;
    layerChunkProgressInfo: LayerChunkProgressInfo;
    handleAction(_action: string): void;
    getValueAt(_x: Float32Array): any;
    /**
     * Transform the stored pickedValue and offset associated with the retrieved pick ID into the
     * actual value.
     */
    transformPickedValue(pickState: PickState): any;
    /**
     * Optionally updates the mouse state based on the retrived pick information.  This might snap the
     * 3-d position to the center of the picked point.
     */
    updateMouseState(_mouseState: MouseSelectionState, _pickedValue: bigint, _pickedOffset: number, _data: any): void;
}
/**
 * Extends RenderLayer with functionality for tracking the number of panels in which the layer is
 * visible.
 */
export declare class VisibilityTrackedRenderLayer<View extends LayerView = LayerView, AttachmentState = unknown> extends RenderLayer {
    backend: SharedObject | undefined;
    visibility: VisibilityPriorityAggregator;
    attach(attachment: VisibleLayerInfo<View, AttachmentState>): void;
}
export interface ThreeDimensionalReadyRenderContext {
    projectionParameters: ProjectionParameters;
}
export interface ThreeDimensionalRenderContext extends ThreeDimensionalReadyRenderContext {
    pickIDs: PickIDManager;
    wireFrame: boolean;
    bindFramebuffer: () => void;
    frameNumber: number;
}
export interface ThreeDimensionalRenderLayerAttachmentState {
    transform: RenderLayerTransformOrError;
    displayDimensionRenderInfo: DisplayDimensionRenderInfo;
    modelTransform: mat4 | undefined;
}
export declare function update3dRenderLayerAttachment(transform: RenderLayerTransformOrError, displayDimensionRenderInfo: DisplayDimensionRenderInfo, attachment: VisibleLayerInfo<LayerView, ThreeDimensionalRenderLayerAttachmentState>): mat4 | undefined;
export declare class DerivedProjectionParameters<Parameters extends ProjectionParameters = ProjectionParameters> extends RefCounted implements WatchableValueChangeInterface<Parameters> {
    private oldValue_;
    private value_;
    private renderViewport;
    changed: Signal<(oldValue: Parameters, newValue: Parameters) => void>;
    constructor(options: {
        navigationState: Borrowed<NavigationState>;
        update: (out: Parameters, navigationState: NavigationState) => void;
        isEqual?: (a: Parameters, b: Parameters) => boolean;
        parametersConstructor?: {
            new (): Parameters;
        };
    });
    setViewport(viewport: RenderViewport): void;
    get value(): Parameters;
    readonly update: (() => void) & {
        flush(): void;
    };
}
export declare class SharedProjectionParameters<T extends ProjectionParameters = ProjectionParameters> extends SharedObject {
    base: WatchableValueChangeInterface<T>;
    updateInterval: number;
    private prevDisplayDimensionRenderInfo;
    constructor(rpc: RPC, base: WatchableValueChangeInterface<T>, updateInterval?: number);
    flush(): void;
    private update;
}
