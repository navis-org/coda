/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { VisibleSegmentEquivalencePolicy } from "#src/segmentation_graph/segment_id.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { DisjointUint64Sets } from "#src/util/disjoint_sets.js";
import { NullarySignal } from "#src/util/signal.js";
import type { RPC } from "#src/worker_rpc.js";
import { SharedObjectCounterpart } from "#src/worker_rpc.js";
export declare class SharedDisjointUint64Sets extends SharedObjectCounterpart implements WatchableValueInterface<SharedDisjointUint64Sets> {
    disjointSets: DisjointUint64Sets;
    changed: NullarySignal;
    /**
     * For compatibility with `WatchableValueInterface`.
     */
    get value(): this;
    static makeWithCounterpart(rpc: RPC, highBitRepresentative: WatchableValueInterface<VisibleSegmentEquivalencePolicy>): SharedDisjointUint64Sets;
    link(a: bigint, b: bigint): boolean;
    linkAll(ids: bigint[]): void;
    has(x: bigint): boolean;
    get(x: bigint): bigint;
    clear(): void;
    setElements(a: bigint): IterableIterator<bigint>;
    deleteSet(x: bigint): void;
    get size(): number;
    toJSON(): string[][];
    /**
     * Restores the state from a JSON representation.
     */
    restoreState(obj: any): void;
    assignFrom(other: SharedDisjointUint64Sets | DisjointUint64Sets): void;
}
