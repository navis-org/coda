/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { RefCounted } from "#src/util/disposable.js";
import { EventActionMap } from "#src/util/keyboard_bindings.js";
import "#src/overlay.css";
export declare const overlayKeyboardHandlerPriority = 100;
export declare let overlaysOpen: number;
export declare const defaultEventMap: EventActionMap;
export declare class Overlay extends RefCounted {
    container: HTMLDivElement;
    content: HTMLDivElement;
    keyMap: EventActionMap;
    constructor();
    close(): void;
    disposed(): void;
}
export declare class FramedDialog extends Overlay {
    header: HTMLDivElement;
    headerTitle: HTMLSpanElement;
    closeMenuIcon: HTMLElement;
    primaryButton: HTMLButtonElement;
    body: HTMLDivElement;
    footer: HTMLDivElement;
    constructor(title?: string, primaryButtonText?: string, extraClassPrefix?: string, primaryButtonClickListener?: () => void);
}
