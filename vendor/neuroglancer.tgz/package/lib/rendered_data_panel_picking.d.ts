/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface ResolvedPanelPickSample {
    offset: number;
    relativeX: number;
    relativeY: number;
    pickValue: number;
    depthValue?: number;
}
export declare function getPickDiameter(pickRadius: number): number;
/**
 * Sequence of offsets into C order (pickDiameter, pickDiameter) array in order of increasing
 * distance from center.
 */
export declare function getPickOffsetSequence(pickRadius: number): Uint32Array<ArrayBufferLike>;
/**
 * Sets array elements to 0 that would be outside the viewport.
 *
 * @param buffer Array view, which contains a C order (pickDiameter, pickDiameter) array.
 * @param baseOffset Offset into `buffer` corresponding to (0, 0).
 * @param stride Stride between consecutive elements of the array.
 * @param glWindowX Center x pixel index.
 * @param glWindowY Center y pixel index.
 * @param viewportWidth Width of viewport in pixels.
 * @param viewportHeight Width of viewport in pixels.
 */
export declare function clearOutOfBoundsPickData(buffer: Float32Array, baseOffset: number, stride: number, glWindowX: number, glWindowY: number, viewportWidth: number, viewportHeight: number, pickRadius: number): void;
/**
 * Returns the nearest valid pick sample from a pick window.
 *
 * Samples are checked in `pickOffsetSequence` order, which is typically sorted by increasing
 * distance from the center of the pick window. For slice views, the pick value itself determines
 * whether a sample is valid. For perspective views, `depthBaseOffset` enables depth-buffer based
 * validity, while `pickBaseOffset` identifies the matching object-pick payload for the same sample.
 *
 * @param data Pick window data containing a C order (pickDiameter, pickDiameter) array.
 * @param pickOffsetSequence Offsets into the pick window to check, in priority order.
 * @param pickRadius Radius of the pick window.
 * @param options.depthBaseOffset Optional base offset of depth values in `data`.
 * @param options.pickBaseOffset Optional base offset of pick values in `data`.
 * @param options.stride Stride between consecutive elements of the pick window array.
 */
export declare function resolveNearestPanelPickSample(data: ArrayLike<number>, pickOffsetSequence: ArrayLike<number>, pickRadius: number, options?: {
    depthBaseOffset?: number;
    pickBaseOffset?: number;
    stride?: number;
}): ResolvedPanelPickSample | undefined;
