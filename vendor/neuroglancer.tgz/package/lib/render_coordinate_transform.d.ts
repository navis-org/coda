/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpace, CoordinateSpaceTransform } from "#src/coordinate_transform.js";
import type { DisplayDimensionRenderInfo } from "#src/navigation_state.js";
import type { CachedWatchableValue, WatchableValueInterface } from "#src/trackable_value.js";
import type { ValueOrError } from "#src/util/error.js";
import type { vec3 } from "#src/util/geom.js";
import { mat4 } from "#src/util/geom.js";
/**
 * Specifies coordinate transform information for a RenderLayer.
 */
export interface RenderLayerTransform {
    /**
     * Rank of chunk/model/layer subspace used by this RenderLayer, including any additional `[0,1)`
     * padding dimensions.
     */
    rank: number;
    /**
     * Rank of chunk/model/layer space, excluding any padding dimensions.
     */
    unpaddedRank: number;
    /**
     * Specifies for each local user layer dimension the corresponding "render layer" dimension.  A
     * value of `-1` indicates there is no corresponding "render layer" dimension.  The combined
     * values of `localToRenderLayerDimensions` and `globalToRenderLayerDimensions` that are not `-1`
     * must be distinct and partition `[0, ..., rank)`, where `rank` is the rank of the "model"
     * coordinate space.
     */
    localToRenderLayerDimensions: readonly number[];
    /**
     * Specifies for each global dimension the corresponding "render layer" dimension.  A value of
     * `-1` indicates there is no corresponding "render layer" dimension.
     */
    globalToRenderLayerDimensions: readonly number[];
    /**
     * Specifies for each channel dimension the corresponding "render layer" dimension.  A value of
     * `-1` indicates there is no corresponding "render layer" dimension.
     */
    channelToRenderLayerDimensions: readonly number[];
    channelToModelDimensions: readonly number[];
    channelSpaceShape: Uint32Array;
    /**
     * Homogeneous transform from "model" coordinate space to "render layer" coordinate space.
     */
    modelToRenderLayerTransform: Float32Array;
    modelDimensionNames: readonly string[];
    layerDimensionNames: readonly string[];
}
export interface ChannelSpace {
    channelCoordinateSpace: CoordinateSpace;
    shape: Uint32Array;
    numChannels: number;
    coordinates: Uint32Array;
}
export declare const zeroRankChannelSpace: ChannelSpace;
export declare function getChannelSpace(channelCoordinateSpace: CoordinateSpace): ChannelSpace;
export type RenderLayerTransformOrError = ValueOrError<RenderLayerTransform>;
export type WatchableRenderLayerTransform = WatchableValueInterface<RenderLayerTransformOrError>;
export declare function getRenderLayerTransform(globalCoordinateSpace: CoordinateSpace, localCoordinateSpace: CoordinateSpace, modelToLayerTransform: CoordinateSpaceTransform, subsourceEntry: {
    subsourceToModelSubspaceTransform: Float32Array;
    modelSubspaceDimensionIndices: readonly number[];
} | undefined, channelCoordinateSpace?: CoordinateSpace): RenderLayerTransformOrError;
export declare function renderLayerTransformsEqual(a: RenderLayerTransformOrError, b: RenderLayerTransformOrError): boolean;
export declare function getWatchableRenderLayerTransform(globalCoordinateSpace: WatchableValueInterface<CoordinateSpace>, localCoordinateSpace: WatchableValueInterface<CoordinateSpace>, modelToLayerTransform: WatchableValueInterface<CoordinateSpaceTransform>, subsourceEntry: {
    subsourceToModelSubspaceTransform: Float32Array;
    modelSubspaceDimensionIndices: readonly number[];
} | undefined, channelCoordinateSpace?: WatchableValueInterface<CoordinateSpace | undefined>): CachedWatchableValue<RenderLayerTransformOrError>;
export interface LayerDisplayDimensionMapping {
    /**
     * List of indices of layer dimensions that correspond to display dimensions.
     */
    layerDisplayDimensionIndices: number[];
    /**
     * Maps each display dimension index to the corresponding layer dimension index, or `-1`.
     */
    displayToLayerDimensionIndices: number[];
}
export interface ChunkChannelAccessParameters {
    channelSpaceShape: Uint32Array;
    /**
     * Equal to the values in `channelToChunkDimensionIndices` not equal to `-1`.
     */
    chunkChannelDimensionIndices: readonly number[];
    /**
     * Product of `modelTransform.channelSpaceShape`.
     */
    numChannels: number;
    /**
     * Row-major array of shape `[numChannels, chunkChannelDimensionIndices.length]`, specifies the
     * coordinates within the chunk channel dimensions corresponding to each flat channel index.
     */
    chunkChannelCoordinates: Uint32Array;
}
export interface ChunkTransformParameters extends ChunkChannelAccessParameters {
    modelTransform: RenderLayerTransform;
    chunkToLayerTransform: Float32Array;
    layerToChunkTransform: Float32Array;
    chunkToLayerTransformDet: number;
    /**
     * Maps channel dimension indices in the layer channel coordinate space to the corresponding chunk
     * dimension index, or `-1` if there is no correpsonding chunk dimension.
     */
    channelToChunkDimensionIndices: readonly number[];
    combinedGlobalLocalToChunkTransform: Float32Array;
    combinedGlobalLocalRank: number;
    layerRank: number;
}
export declare function layerToDisplayCoordinates(displayPosition: vec3, layerPosition: Float32Array, modelTransform: RenderLayerTransform, displayDimensionIndices: Int32Array): void;
export declare function displayToLayerCoordinates(layerPosition: Float32Array, displayPosition: vec3, modelTransform: RenderLayerTransform, displayDimensionIndices: Int32Array): void;
export declare function chunkToDisplayCoordinates(displayPosition: vec3, chunkPosition: Float32Array, chunkTransform: ChunkTransformParameters, displayDimensionIndices: Int32Array): vec3;
export interface ChunkDisplayTransformParameters {
    modelTransform: RenderLayerTransform;
    chunkTransform: ChunkTransformParameters;
    displaySubspaceModelMatrix: mat4;
    displaySubspaceInvModelMatrix: mat4;
    chunkDisplayDimensionIndices: number[];
    numChunkDisplayDims: number;
}
export declare function getChunkTransformParameters(modelTransform: RenderLayerTransform, chunkToModelTransform?: Float32Array): ChunkTransformParameters;
export declare function getLayerDisplayDimensionMapping(transform: RenderLayerTransform, displayDimensionIndices: Int32Array): LayerDisplayDimensionMapping;
export declare function getChunkDisplayTransformParameters(chunkTransform: ChunkTransformParameters, layerDisplayDimensionMapping: LayerDisplayDimensionMapping): ChunkDisplayTransformParameters;
export declare function getChunkPositionFromCombinedGlobalLocalPositions(chunkPosition: Float32Array, globalPosition: Float32Array, localPosition: Float32Array, layerRank: number, combinedGlobalLocalToChunkTransform: Float32Array): boolean;
export declare function getLayerPositionFromCombinedGlobalLocalPositions(layerPosition: Float32Array, globalPosition: Float32Array, localPosition: Float32Array, modelTransform: RenderLayerTransform): Float32Array<ArrayBufferLike>;
export declare function get3dModelToDisplaySpaceMatrix(out: mat4, displayDimensionRenderInfo: DisplayDimensionRenderInfo, transform: RenderLayerTransform): void;
