/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/data_panel_layout.css";
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { DisplayContext } from "#src/display_context.js";
import type { LayerManager, MouseSelectionState, SelectedLayerState, TrackableDataSelectionState } from "#src/layer/index.js";
import type { TrackableZoomInterface } from "#src/navigation_state.js";
import { LinkedOrientationState, LinkedPosition, LinkedZoomState, NavigationState } from "#src/navigation_state.js";
import type { RenderLayerRole } from "#src/renderlayer.js";
import { SliceView } from "#src/sliceview/frontend.js";
import { TrackableBoolean } from "#src/trackable_boolean.js";
import type { WatchableSet, WatchableValueInterface } from "#src/trackable_value.js";
import { TrackableValue } from "#src/trackable_value.js";
import type { TrackableRGB } from "#src/util/color.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { EventActionMap } from "#src/util/event_action_map.js";
import { quat } from "#src/util/geom.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import { WatchableMap } from "#src/util/watchable_map.js";
import type { VisibilityPrioritySpecification } from "#src/viewer_state.js";
import type { ScaleBarOptions } from "#src/widget/scale_bar.js";
export interface SliceViewViewerState {
    chunkManager: ChunkManager;
    navigationState: NavigationState;
    layerManager: LayerManager;
    wireFrame: WatchableValueInterface<boolean>;
}
export declare class InputEventBindings {
    perspectiveView: EventActionMap;
    sliceView: EventActionMap;
}
export interface ViewerUIState extends SliceViewViewerState, VisibilityPrioritySpecification {
    display: DisplayContext;
    mouseState: MouseSelectionState;
    perspectiveNavigationState: NavigationState;
    selectionDetailsState: TrackableDataSelectionState;
    showPerspectiveSliceViews: TrackableBoolean;
    showAxisLines: TrackableBoolean;
    wireFrame: TrackableBoolean;
    enableAdaptiveDownsampling: TrackableBoolean;
    showScaleBar: TrackableBoolean;
    scaleBarOptions: TrackableValue<ScaleBarOptions>;
    visibleLayerRoles: WatchableSet<RenderLayerRole>;
    selectedLayer: SelectedLayerState;
    inputEventBindings: InputEventBindings;
    crossSectionBackgroundColor: TrackableRGB;
    perspectiveViewBackgroundColor: TrackableRGB;
    hideCrossSectionBackground3D: TrackableBoolean;
    pickRadius: TrackableValue<number>;
}
export interface DataDisplayLayout extends RefCounted {
    rootElement: HTMLElement;
    container: DataPanelLayoutContainer;
}
type NamedAxes = "xy" | "xz" | "yz";
export declare function makeSliceView(viewerState: SliceViewViewerState, baseToSelf?: quat): SliceView;
export declare function makeNamedSliceView(viewerState: SliceViewViewerState, axes: NamedAxes): SliceView;
export declare function makeOrthogonalSliceViews(viewerState: SliceViewViewerState): Map<NamedAxes, SliceView>;
export declare function getCommonViewerState(viewer: ViewerUIState): {
    crossSectionBackgroundColor: TrackableRGB;
    perspectiveViewBackgroundColor: TrackableRGB;
    selectionDetailsState: TrackableDataSelectionState;
    mouseState: MouseSelectionState;
    layerManager: LayerManager;
    showAxisLines: TrackableBoolean;
    wireFrame: TrackableBoolean;
    enableAdaptiveDownsampling: TrackableBoolean;
    visibleLayerRoles: WatchableSet<RenderLayerRole>;
    selectedLayer: SelectedLayerState;
    visibility: import("./visibility_priority/frontend").WatchableVisibilityPriority;
    scaleBarOptions: TrackableValue<ScaleBarOptions>;
    hideCrossSectionBackground3D: TrackableBoolean;
    pickRadius: TrackableValue<number>;
};
export declare class FourPanelLayout extends RefCounted {
    container: DataPanelLayoutContainer;
    rootElement: HTMLElement;
    viewer: ViewerUIState;
    constructor(container: DataPanelLayoutContainer, rootElement: HTMLElement, viewer: ViewerUIState, crossSections: Borrowed<CrossSectionSpecificationMap>);
    disposed(): void;
}
export declare class FourPanelAltLayout extends RefCounted {
    container: DataPanelLayoutContainer;
    rootElement: HTMLElement;
    viewer: ViewerUIState;
    constructor(container: DataPanelLayoutContainer, rootElement: HTMLElement, viewer: ViewerUIState, crossSections: Borrowed<CrossSectionSpecificationMap>);
    disposed(): void;
}
export declare class SliceViewPerspectiveTwoPanelLayout extends RefCounted {
    container: DataPanelLayoutContainer;
    rootElement: HTMLElement;
    viewer: ViewerUIState;
    direction: "row" | "column";
    constructor(container: DataPanelLayoutContainer, rootElement: HTMLElement, viewer: ViewerUIState, direction: "row" | "column", axes: NamedAxes, crossSections: Borrowed<CrossSectionSpecificationMap>);
    disposed(): void;
}
export declare class SinglePanelLayout extends RefCounted {
    container: DataPanelLayoutContainer;
    rootElement: HTMLElement;
    viewer: ViewerUIState;
    constructor(container: DataPanelLayoutContainer, rootElement: HTMLElement, viewer: ViewerUIState, axes: NamedAxes);
    disposed(): void;
}
export declare class SinglePerspectiveLayout extends RefCounted {
    container: DataPanelLayoutContainer;
    rootElement: HTMLElement;
    viewer: ViewerUIState;
    constructor(container: DataPanelLayoutContainer, rootElement: HTMLElement, viewer: ViewerUIState, crossSections: Borrowed<CrossSectionSpecificationMap>);
    disposed(): void;
}
export declare const LAYOUTS: Map<string, {
    factory: (container: DataPanelLayoutContainer, element: HTMLElement, viewer: ViewerUIState, crossSections: Borrowed<CrossSectionSpecificationMap>) => DataDisplayLayout;
}>;
export declare function getLayoutByName(obj: any): {
    factory: (container: DataPanelLayoutContainer, element: HTMLElement, viewer: ViewerUIState, crossSections: Borrowed<CrossSectionSpecificationMap>) => DataDisplayLayout;
};
export declare function validateLayoutName(obj: any): string;
export declare class CrossSectionSpecification extends RefCounted implements Trackable {
    width: TrackableValue<number>;
    height: TrackableValue<number>;
    position: LinkedPosition;
    orientation: LinkedOrientationState;
    scale: LinkedZoomState<TrackableZoomInterface>;
    navigationState: NavigationState;
    changed: NullarySignal;
    constructor(parent: Borrowed<NavigationState>);
    restoreState(obj: any): void;
    reset(): void;
    toJSON(): {
        width: any;
        height: any;
        position: {
            link: string | undefined;
            value: any;
        } | undefined;
        orientation: {
            link: string | undefined;
            value: any;
        } | undefined;
        scale: {
            link: string | undefined;
            value: any;
        } | undefined;
    };
}
export declare class CrossSectionSpecificationMap extends WatchableMap<string, CrossSectionSpecification> {
    private parentNavigationState;
    constructor(parentNavigationState: Owned<NavigationState>);
    restoreState(obj: any): void;
    reset(): void;
    toJSON(): {
        [key: string]: any;
    } | undefined;
}
export declare class DataPanelLayoutSpecification extends RefCounted implements Trackable {
    changed: NullarySignal;
    type: TrackableValue<string>;
    crossSections: CrossSectionSpecificationMap;
    orthographicProjection: TrackableBoolean;
    constructor(parentNavigationState: Owned<NavigationState>, defaultLayout: string);
    reset(): void;
    restoreState(obj: any): void;
    toJSON(): string | {
        type: string;
        crossSections: {
            [key: string]: any;
        } | undefined;
        orthographicProjection: boolean | undefined;
    };
}
export declare class DataPanelLayoutContainer extends RefCounted {
    viewer: ViewerUIState;
    element: HTMLDivElement;
    specification: Owned<DataPanelLayoutSpecification>;
    private layout;
    get name(): string;
    set name(value: string);
    constructor(viewer: ViewerUIState, defaultLayout: string);
    get changed(): NullarySignal;
    toJSON(): string | {
        type: string;
        crossSections: {
            [key: string]: any;
        } | undefined;
        orthographicProjection: boolean | undefined;
    };
    restoreState(obj: any): void;
    reset(): void;
    private disposeLayout;
    private updateLayout;
    disposed(): void;
}
export {};
