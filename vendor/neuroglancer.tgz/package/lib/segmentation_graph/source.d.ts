/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import type { RenderLayer } from "#src/renderlayer.js";
import type { VisibleSegmentsState } from "#src/segmentation_display_state/base.js";
import type { SegmentationDisplayState3D } from "#src/segmentation_display_state/frontend.js";
import type { VisibleSegmentEquivalencePolicy } from "#src/segmentation_graph/segment_id.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { Disposer, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { DependentViewContext } from "#src/widget/dependent_view_widget.js";
import { Tab } from "#src/widget/tab_view.js";
export declare class SegmentationGraphSourceTab extends Tab {
    layer: SegmentationUserLayer;
    constructor(layer: SegmentationUserLayer);
}
export declare abstract class SegmentationGraphSource {
    abstract connect(layer: SegmentationUserLayer): Owned<SegmentationGraphSourceConnection>;
    abstract merge(a: bigint, b: bigint): Promise<bigint>;
    abstract split(include: bigint, exclude: bigint): Promise<{
        include: bigint;
        exclude: bigint;
    }>;
    abstract trackSegment(id: bigint, callback: (id: bigint | null) => void): () => void;
    abstract get visibleSegmentEquivalencePolicy(): VisibleSegmentEquivalencePolicy;
    tabContents?(layer: SegmentationUserLayer, context: DependentViewContext, tab: SegmentationGraphSourceTab): HTMLDivElement;
}
export interface ComputedSplit {
    includeRepresentative: bigint;
    includeBaseSegments: bigint[];
    excludeRepresentative: bigint;
    excludeBaseSegments: bigint[];
}
export declare abstract class SegmentationGraphSourceConnection<SourceType extends SegmentationGraphSource = SegmentationGraphSource> extends RefCounted {
    graph: SourceType;
    segmentsState: VisibleSegmentsState;
    constructor(graph: SourceType, segmentsState: VisibleSegmentsState);
    abstract computeSplit(include: bigint, exclude: bigint): ComputedSplit | undefined;
    createRenderLayers(chunkManager: ChunkManager, displayState: SegmentationDisplayState3D, localPosition: WatchableValueInterface<Float32Array>): RenderLayer[];
}
export declare function trackWatchableValueSegment(graph: SegmentationGraphSource, watchable: WatchableValueInterface<bigint | undefined>): Disposer;
