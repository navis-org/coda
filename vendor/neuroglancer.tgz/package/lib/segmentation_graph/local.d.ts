/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import { VisibleSegmentEquivalencePolicy } from "#src/segmentation_graph/segment_id.js";
import type { ComputedSplit } from "#src/segmentation_graph/source.js";
import { SegmentationGraphSource, SegmentationGraphSourceConnection } from "#src/segmentation_graph/source.js";
import { SharedDisjointUint64Sets } from "#src/shared_disjoint_sets.js";
import { Signal } from "#src/util/signal.js";
export declare class LocalSegmentationGraphSource extends SegmentationGraphSource {
    spanningTreeEdges: Map<bigint, Set<bigint>>;
    equivalences: SharedDisjointUint64Sets;
    connections: Set<LocalSegmentationGraphSourceConnection>;
    changed: Signal<() => void>;
    private link;
    private linkAll;
    private deleteSet;
    private normalizeAll;
    private addSpanningTreeEdge;
    private removeSpanningTreeEdge;
    private getSpanningTreeNeighbors;
    restoreState(obj: unknown): void;
    toJSON(): string[][] | undefined;
    get visibleSegmentEquivalencePolicy(): VisibleSegmentEquivalencePolicy;
    merge(a: bigint, b: bigint): Promise<bigint>;
    split(a: bigint, b: bigint): Promise<{
        include: bigint;
        exclude: bigint;
    }>;
    trackSegment(id: bigint, callback: (id: bigint | null) => void): () => void;
    computeSplit(include: bigint, exclude: bigint): ComputedSplit | undefined;
    connect(layer: SegmentationUserLayer): SegmentationGraphSourceConnection;
}
declare class LocalSegmentationGraphSourceConnection extends SegmentationGraphSourceConnection<LocalSegmentationGraphSource> {
    computeSplit(include: bigint, exclude: bigint): ComputedSplit | undefined;
}
export {};
