/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { AnnotationGeometryChunkSpecification } from "#src/annotation/base.js";
import type { Annotation, AnnotationId, AnnotationPropertySerializer, AnnotationPropertySpec, AnnotationSourceSignals, SerializedAnnotations } from "#src/annotation/index.js";
import { AnnotationReference, AnnotationType } from "#src/annotation/index.js";
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import { Chunk, ChunkSource } from "#src/chunk_manager/frontend.js";
import type { SliceViewSourceOptions } from "#src/sliceview/base.js";
import type { MultiscaleSliceViewChunkSource, SliceViewChunkSourceOptions, SliceViewSingleResolutionSource } from "#src/sliceview/frontend.js";
import { SliceViewChunk, SliceViewChunkSource } from "#src/sliceview/frontend.js";
import { WatchableValue } from "#src/trackable_value.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import type { Signal } from "#src/util/signal.js";
import { NullarySignal } from "#src/util/signal.js";
import type { GLBuffer } from "#src/webgl/buffer.js";
import type { GL } from "#src/webgl/context.js";
import type { RPC } from "#src/worker_rpc.js";
import { SharedObject } from "#src/worker_rpc.js";
export interface AnnotationGeometryChunkSourceOptions extends SliceViewChunkSourceOptions {
    spec: AnnotationGeometryChunkSpecification;
    parent: Borrowed<MultiscaleAnnotationSource>;
}
export declare function computeNumPickIds(serializedAnnotations: SerializedAnnotations): number;
export declare class AnnotationGeometryData {
    buffer: GLBuffer | undefined;
    bufferValid: boolean;
    serializedAnnotations: SerializedAnnotations;
    numPickIds: number;
    constructor(x: SerializedAnnotations);
    freeGPUMemory(gl: GL): void;
}
export declare class AnnotationSubsetGeometryChunk extends Chunk {
    source: AnnotationSubsetGeometryChunkSource;
    data: AnnotationGeometryData | undefined;
    constructor(source: AnnotationSubsetGeometryChunkSource, x: any);
    freeGPUMemory(gl: GL): void;
    dispose(): void;
}
export declare class AnnotationGeometryChunk extends SliceViewChunk {
    source: AnnotationGeometryChunkSource;
    data: AnnotationGeometryData | undefined;
    constructor(source: AnnotationGeometryChunkSource, x: any);
    freeGPUMemory(gl: GL): void;
    dispose(): void;
}
export declare class AnnotationGeometryChunkSource extends SliceViewChunkSource<AnnotationGeometryChunkSpecification, AnnotationGeometryChunk> {
    OPTIONS: AnnotationGeometryChunkSourceOptions;
    parent: Borrowed<MultiscaleAnnotationSource>;
    immediateChunkUpdates: boolean;
    /**
     * Transforms positions in the MultiscaleAnnotationSource coordinate space to grid cell
     * coordinates.  Equal to the inverse of `this.spec.chunkToMultiscaleTransform`, with rows divided
     * by `this.spec.chunkDataSize`.
     */
    multiscaleToChunkTransform: Float32Array;
    constructor(chunkManager: Borrowed<ChunkManager>, options: AnnotationGeometryChunkSourceOptions);
    disposed(): void;
    initializeCounterpart(rpc: RPC, options: any): void;
    addChunk(key: string, chunk: AnnotationGeometryChunk): void;
    getChunk(x: any): AnnotationGeometryChunk;
}
export declare class AnnotationSubsetGeometryChunkSource extends ChunkSource {
    parent: Borrowed<MultiscaleAnnotationSource>;
    relationshipIndex: number;
    immediateChunkUpdates: boolean;
    chunks: Map<string, AnnotationSubsetGeometryChunk>;
    constructor(chunkManager: Borrowed<ChunkManager>, parent: Borrowed<MultiscaleAnnotationSource>, relationshipIndex: number);
    addChunk(key: string, chunk: AnnotationSubsetGeometryChunk): void;
    getChunk(x: any): AnnotationSubsetGeometryChunk;
}
export declare class AnnotationMetadataChunk extends Chunk {
    annotation: Annotation | null;
    constructor(source: Borrowed<AnnotationMetadataChunkSource>, x: any);
}
export declare class AnnotationMetadataChunkSource extends ChunkSource {
    parent: Borrowed<MultiscaleAnnotationSource>;
    chunks: Map<string, AnnotationMetadataChunk>;
    constructor(chunkManager: Borrowed<ChunkManager>, parent: Borrowed<MultiscaleAnnotationSource>);
    getChunk(x: any): AnnotationMetadataChunk;
    addChunk(key: string, chunk: AnnotationMetadataChunk): void;
    deleteChunk(key: string): void;
}
export declare function updateAnnotation(chunk: AnnotationGeometryData, annotation: Annotation, propertySerializers: AnnotationPropertySerializer[]): void;
export declare function deleteAnnotation(chunk: AnnotationGeometryData, type: AnnotationType, id: AnnotationId, propertySerializers: AnnotationPropertySerializer[]): boolean;
interface LocalUpdateUndoState {
    /**
     * If commitInProgress === undefined, this must be undefined.  Otherwise, it specifies a commit
     * that has been requested and which will be initiated as soon as the in-progress request
     * completes.
     */
    pendingCommit: Annotation | null | undefined;
    reference: Owned<AnnotationReference>;
    /**
     * The state of the annotation prior to any local modifications.
     */
    existingAnnotation: Annotation | undefined;
    /**
     * If not undefined, a commit has been sent to the backend, and we are waiting for the result.
     */
    commitInProgress: Annotation | null | undefined;
    type: AnnotationType;
}
export declare function makeTemporaryChunk(): AnnotationGeometryChunk;
export declare class MultiscaleAnnotationSource extends SharedObject implements MultiscaleSliceViewChunkSource<AnnotationGeometryChunkSource>, AnnotationSourceSignals {
    chunkManager: Borrowed<ChunkManager>;
    OPTIONS: object;
    key: any;
    metadataChunkSource: AnnotationMetadataChunkSource;
    segmentFilteredSources: Owned<AnnotationSubsetGeometryChunkSource>[];
    spatiallyIndexedSources: Set<AnnotationGeometryChunkSource>;
    rank: number;
    readonly relationships: readonly string[];
    readonly properties: WatchableValue<readonly Readonly<AnnotationPropertySpec>[]>;
    readonly annotationPropertySerializers: AnnotationPropertySerializer[];
    constructor(chunkManager: Borrowed<ChunkManager>, options: {
        rank: number;
        relationships: readonly string[];
        properties: Readonly<AnnotationPropertySpec>[];
    });
    hasNonSerializedProperties(): boolean;
    getSources(_options: SliceViewSourceOptions): SliceViewSingleResolutionSource<AnnotationGeometryChunkSource>[][];
    temporary: AnnotationGeometryChunk;
    references: Map<string, AnnotationReference>;
    localUpdates: Map<string, LocalUpdateUndoState>;
    initializeCounterpart(rpc: RPC, options: any): void;
    add(annotation: Annotation, commit?: boolean): AnnotationReference;
    private applyLocalUpdate;
    private sendCommitRequest;
    delete(reference: Borrowed<AnnotationReference>): void;
    update(reference: AnnotationReference, newAnnotation: Annotation): void;
    private notifyChanged;
    /**
     * Must be called after `add` or `update` to commit the result.
     */
    commit(reference: Borrowed<AnnotationReference>): void;
    getReference(id: AnnotationId): Owned<AnnotationReference>;
    private forEachPossibleChunk;
    static encodeOptions(_options: object): {
        [key: string]: any;
    };
    handleSuccessfulUpdate(id: AnnotationId, newAnnotation: Annotation | null): void;
    private numCommitsInProgress;
    private commitStatus;
    disposed(): void;
    private updateCommitsInProgress;
    handleFailedUpdate(id: AnnotationId, message: string): void;
    private revertLocalUpdate;
    changed: NullarySignal;
    [Symbol.iterator](): Iterator<Annotation>;
    readonly: boolean;
    childAdded: Signal<(annotation: Annotation) => void>;
    childUpdated: Signal<(annotation: Annotation) => void>;
    childCommitted: Signal<(annotationId: string) => void>;
    childDeleted: Signal<(annotationId: string) => void>;
    childrenReordered: NullarySignal;
}
export {};
