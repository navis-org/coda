/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ProjectionParameters } from "#src/projection_parameters.js";
import type { MultiscaleVolumetricDataRenderLayer, SliceViewChunkSource, SliceViewChunkSpecification, TransformedSource } from "#src/sliceview/base.js";
export declare const ANNOTATION_METADATA_CHUNK_SOURCE_RPC_ID = "annotation.MetadataChunkSource";
export declare const ANNOTATION_GEOMETRY_CHUNK_SOURCE_RPC_ID = "annotation.GeometryChunkSource";
export declare const ANNOTATION_SUBSET_GEOMETRY_CHUNK_SOURCE_RPC_ID = "annotation.SubsetGeometryChunkSource";
export declare const ANNOTATION_REFERENCE_ADD_RPC_ID = "annotation.reference.add";
export declare const ANNOTATION_REFERENCE_DELETE_RPC_ID = "annotation.reference.delete";
export declare const ANNOTATION_COMMIT_UPDATE_RPC_ID = "annotation.commit";
export declare const ANNOTATION_COMMIT_UPDATE_RESULT_RPC_ID = "annotation.commit";
export interface AnnotationGeometryChunkSpecification extends SliceViewChunkSpecification {
    /**
     * Must equal the `chunkToMultiscaleTransform` in the `SliceViewSingleResolutionSource`.
     */
    chunkToMultiscaleTransform: Float32Array;
    /**
     * Specifies the maximum density of annotations provided by this chunk source, as `limit` per the
     * chunk volume.  The higher the value, the sooner chunks from this source will be subsampled.  To
     * disable subsampling completely, set `limit` to 0.
     */
    limit: number;
}
export declare const ANNOTATION_SPATIALLY_INDEXED_RENDER_LAYER_RPC_ID = "annotation/SpatiallyIndexedRenderLayer";
export declare const ANNOTATION_PERSPECTIVE_RENDER_LAYER_UPDATE_SOURCES_RPC_ID = "annotation/PerspectiveRenderLayer:updateSources";
export declare const ANNOTATION_RENDER_LAYER_RPC_ID = "annotation/RenderLayer";
export declare const ANNOTATION_RENDER_LAYER_UPDATE_SEGMENTATION_RPC_ID = "annotation/RenderLayer.updateSegmentation";
export declare function forEachVisibleAnnotationChunk<RLayer extends MultiscaleVolumetricDataRenderLayer, Source extends SliceViewChunkSource<AnnotationGeometryChunkSpecification>, Transformed extends TransformedSource<RLayer, Source>>(projectionParameters: ProjectionParameters, localPosition: Float32Array, renderScaleTarget: number, transformedSources: readonly Transformed[], beginScale: (source: Transformed, index: number) => void, callback: (source: Transformed, index: number, drawFraction: number, physicalSpacing: number, pixelSpacing: number) => void): void;
