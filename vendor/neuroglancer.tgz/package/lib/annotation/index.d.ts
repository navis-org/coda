/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Basic annotation data structures.
 */
import type { BoundingBox, WatchableCoordinateSpaceTransform } from "#src/coordinate_transform.js";
import { WatchableValue } from "#src/trackable_value.js";
import { DataType } from "#src/util/data_type.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal, Signal } from "#src/util/signal.js";
export type AnnotationId = string;
export declare class AnnotationReference extends RefCounted {
    id: AnnotationId;
    changed: NullarySignal;
    /**
     * If `undefined`, we are still waiting to look up the result.  If `null`, annotation has been
     * deleted.
     */
    value: Annotation | null | undefined;
    constructor(id: AnnotationId);
}
export declare enum AnnotationType {
    POINT = 0,
    LINE = 1,
    AXIS_ALIGNED_BOUNDING_BOX = 2,
    ELLIPSOID = 3,
    POLYLINE = 4
}
export declare const annotationTypes: AnnotationType[];
export interface AnnotationPropertySpecBase {
    identifier: string;
    description: string | undefined;
}
export interface AnnotationColorPropertySpec extends AnnotationPropertySpecBase {
    type: "rgb" | "rgba";
    default: number;
}
export interface AnnotationBoolPropertySpec extends AnnotationPropertySpecBase {
    type: "bool";
    default: number;
}
export interface AnnotationNumericPropertySpec extends AnnotationPropertySpecBase {
    type: "float32" | "uint32" | "int32" | "uint16" | "int16" | "uint8" | "int8";
    default: number;
    enumValues?: number[];
    enumLabels?: string[];
    min?: number;
    max?: number;
    step?: number;
}
export declare function isAnnotationTypeNumeric(type: AnnotationPropertySpec["type"]): boolean;
export declare function isAnnotationNumericPropertySpec(spec: AnnotationPropertySpec): spec is AnnotationNumericPropertySpec;
export declare const propertyTypeDataType: Record<AnnotationPropertySpec["type"], DataType | undefined>;
export type AnnotationPropertySpec = AnnotationColorPropertySpec | AnnotationNumericPropertySpec | AnnotationBoolPropertySpec;
export interface AnnotationPropertyTypeHandler {
    serializedBytes(rank: number): number;
    alignment(rank: number): number;
    serializeCode(property: string, offset: string, rank: number): string;
    deserializeCode(property: string, offset: string, rank: number): string;
    deserializeJson(obj: unknown): number;
    serializeJson(value: number): any;
}
export declare const annotationPropertyTypeHandlers: {
    [K in AnnotationPropertySpec["type"]]: AnnotationPropertyTypeHandler;
};
export declare function getPropertyOffsets(rank: number, firstGroupInitialOffset: number, propertySpecs: readonly Readonly<AnnotationPropertySpec>[]): {
    serializedBytes: number;
    offsets: {
        group: number;
        offset: number;
    }[];
    propertyGroupBytes: number[];
};
export declare class AnnotationPropertySerializer {
    rank: number;
    firstGroupInitialOffset: number;
    propertySpecs: readonly Readonly<AnnotationPropertySpec>[];
    serializedBytes: number;
    serialize: (buffer: DataView, offset: number, annotationIndex: number, annotationCount: number, isLittleEndian: boolean, properties: any[]) => void;
    deserialize: (buffer: DataView, offset: number, annotationIndex: number, annotationCount: number, isLittleEndian: boolean, properties: any[]) => void;
    propertyGroupBytes: number[];
    constructor(rank: number, firstGroupInitialOffset: number, propertySpecs: readonly Readonly<AnnotationPropertySpec>[]);
}
export declare function makeAnnotationPropertySerializers(rank: number, propertySpecs: readonly Readonly<AnnotationPropertySpec>[]): AnnotationPropertySerializer[];
export declare function formatNumericProperty(property: AnnotationNumericPropertySpec, value: number): string;
export declare function formatAnnotationPropertyValue(property: AnnotationPropertySpec, value: any): string;
export declare function parseAnnotationPropertyId(obj: unknown): string;
export declare function parseAnnotationPropertyType(obj: unknown): AnnotationPropertySpec["type"];
export declare function ensureUniqueAnnotationPropertyIds(properties: AnnotationPropertySpec[]): void;
export declare function compareAnnotationSpecProperties(a: Readonly<AnnotationPropertySpec>, b: Readonly<AnnotationPropertySpec>): {
    same: boolean;
    sameValues: {
        type: boolean;
        identifier: boolean;
        description: boolean;
        default: boolean;
        enumValues: boolean;
        enumLabels: boolean;
        enumLength: boolean;
    };
};
export declare function annotationPropertySpecsToJson(specs: readonly Readonly<AnnotationPropertySpec>[] | undefined): {
    id: string;
    description: string | undefined;
    type: "rgb" | "rgba" | "bool" | "float32" | "uint32" | "int32" | "uint16" | "int16" | "uint8" | "int8";
    default: any;
    enum_labels: string[] | undefined;
    enum_values: any[] | undefined;
}[] | undefined;
export declare function parseAnnotationPropertySpecs(obj: unknown): AnnotationPropertySpec[];
export interface AnnotationBase {
    /**
     * If equal to `undefined`, then the description is unknown (possibly still being loaded).  If
     * equal to `null`, then there is no description.
     */
    description?: string | undefined | null;
    id: AnnotationId;
    type: AnnotationType;
    relatedSegments?: BigUint64Array[];
    properties: any[];
}
export interface Line extends AnnotationBase {
    pointA: Float32Array;
    pointB: Float32Array;
    type: AnnotationType.LINE;
}
export interface Point extends AnnotationBase {
    point: Float32Array;
    type: AnnotationType.POINT;
}
export interface AxisAlignedBoundingBox extends AnnotationBase {
    pointA: Float32Array;
    pointB: Float32Array;
    type: AnnotationType.AXIS_ALIGNED_BOUNDING_BOX;
}
export interface Ellipsoid extends AnnotationBase {
    center: Float32Array;
    radii: Float32Array;
    type: AnnotationType.ELLIPSOID;
}
export interface PolyLine extends AnnotationBase {
    points: Float32Array[];
    type: AnnotationType.POLYLINE;
}
export type Annotation = Line | Point | AxisAlignedBoundingBox | Ellipsoid | PolyLine;
export interface AnnotationTypeHandler<T extends Annotation = Annotation> {
    icon: string;
    description: string;
    toJSON: (annotation: T, rank: number) => any;
    restoreState: (annotation: T, obj: any, rank: number) => void;
    /**
     * Number of bytes in the serialized version of one instance of annotation
     * Most annotations have only one instance per annotation
     * However, Polylines have an only rank-dependent instance size, but not a fixed
     * number of instances (this is numPoints - 1).
     * @param rank - rank of the co-ordinate transform matrix
     */
    serializedBytes: (rank: number) => number;
    serialize: (buffer: DataView, offset: number, isLittleEndian: boolean, rank: number, annotation: T, instanceStride?: number) => void;
    deserialize: (buffer: DataView, offset: number, isLittleEndian: boolean, rank: number, id: string, instanceStride?: number) => T;
    visitGeometry: (annotation: T, callback: (vec: Float32Array, isVector: boolean) => void) => void;
    defaultProperties: (annotation: T) => {
        properties: AnnotationNumericPropertySpec[];
        values: number[];
    };
}
export declare const annotationTypeHandlers: Record<AnnotationType, AnnotationTypeHandler>;
export interface AnnotationSchema {
    rank: number;
    relationships: readonly string[];
    properties: WatchableValue<readonly Readonly<AnnotationPropertySpec>[]>;
}
export declare function annotationToJson(annotation: Annotation, schema: AnnotationSchema): any;
export interface AnnotationSourceSignals {
    changed: NullarySignal;
    childAdded: Signal<(annotation: Annotation) => void>;
    childUpdated: Signal<(annotation: Annotation) => void>;
    childCommitted: Signal<(annotationId: string) => void>;
    childDeleted: Signal<(annotationId: string) => void>;
    childrenReordered: NullarySignal;
}
export declare class AnnotationSource extends RefCounted implements AnnotationSourceSignals {
    readonly relationships: readonly string[];
    readonly properties: WatchableValue<readonly Readonly<AnnotationPropertySpec>[]>;
    protected annotationMap: Map<string, Annotation>;
    changed: NullarySignal;
    readonly: boolean;
    childAdded: Signal<(annotation: Annotation) => void>;
    childUpdated: Signal<(annotation: Annotation) => void>;
    childCommitted: Signal<(annotationId: string) => void>;
    childDeleted: Signal<(annotationId: string) => void>;
    childrenReordered: NullarySignal;
    pending: Set<string>;
    protected rank_: number;
    get rank(): number;
    annotationPropertySerializers: AnnotationPropertySerializer[];
    constructor(rank: number, relationships?: readonly string[], properties?: WatchableValue<readonly Readonly<AnnotationPropertySpec>[]>);
    hasNonSerializedProperties(): boolean;
    add(annotation: Annotation, commit?: boolean): AnnotationReference;
    commit(reference: AnnotationReference): void;
    update(reference: AnnotationReference, annotation: Annotation): void;
    reorder(sourceId: AnnotationId, targetId: AnnotationId, placement: "before" | "after"): boolean;
    [Symbol.iterator](): MapIterator<Annotation>;
    get(id: AnnotationId): Annotation | undefined;
    delete(reference: AnnotationReference): void;
    getReference(id: AnnotationId): AnnotationReference;
    references: Map<string, AnnotationReference>;
    protected ensureUpdated(): void;
    toJSON(): any[];
    clear(): void;
    restoreState(obj: any): void;
    reset(): void;
}
export declare function canConvertTypes(oldType: AnnotationPropertySpec["type"], newType: AnnotationPropertySpec["type"]): boolean;
export declare class LocalAnnotationSource extends AnnotationSource {
    watchableTransform: WatchableCoordinateSpaceTransform;
    readonly properties: WatchableValue<AnnotationPropertySpec[]>;
    private curCoordinateTransform;
    get rank(): number;
    constructor(watchableTransform: WatchableCoordinateSpaceTransform, properties: WatchableValue<AnnotationPropertySpec[]> | undefined, relationships: string[]);
    updateAnnotationPropertySerializers(): void;
    addProperty(property: AnnotationPropertySpec): void;
    removeAllProperties(): void;
    removeProperty(identifier: string): void;
    updateProperty(oldProperty: AnnotationPropertySpec, newPropertyValues: Partial<AnnotationPropertySpec>): void;
    ensureUpdated(): void;
}
export declare const DATA_BOUNDS_DESCRIPTION = "Data Bounds";
export declare function makeAnnotationId(): string;
export declare function makeDataBoundsBoundingBoxAnnotation(box: BoundingBox): AxisAlignedBoundingBox;
export declare function makeDataBoundsBoundingBoxAnnotationSet(box: BoundingBox): AnnotationSource;
export interface SerializedAnnotations {
    data: Uint8Array<ArrayBuffer>;
    typeToInstanceCounts: number[][];
    typeToIds: string[][];
    typeToOffset: number[];
    typeToIdMaps: Map<string, number>[];
    typeToSize: number[];
}
export declare class AnnotationSerializer {
    propertySerializers: AnnotationPropertySerializer[];
    annotations: [
        Point[],
        Line[],
        AxisAlignedBoundingBox[],
        Ellipsoid[],
        PolyLine[]
    ];
    constructor(propertySerializers: AnnotationPropertySerializer[]);
    add(annotation: Annotation): void;
    serialize(): SerializedAnnotations;
}
