/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import { ChunkSource } from "#src/chunk_manager/frontend.js";
import type { IndexedSegmentProperty } from "#src/segmentation_display_state/base.js";
import type { Uint64OrderedSet } from "#src/uint64_ordered_set.js";
import type { Uint64Set } from "#src/uint64_set.js";
import type { TypedNumberArray } from "#src/util/array.js";
import { DataType } from "#src/util/data_type.js";
import type { Borrowed } from "#src/util/disposable.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
export type InlineSegmentProperty = InlineSegmentStringProperty | InlineSegmentTagsProperty | InlineSegmentNumericalProperty;
export interface InlineSegmentStringProperty {
    id: string;
    type: "string" | "label" | "description";
    description?: string | undefined;
    values: string[];
}
export interface InlineSegmentTagsProperty {
    id: string;
    type: "tags";
    tags: string[];
    tagDescriptions: string[];
    values: string[];
}
export interface InlineSegmentNumericalProperty {
    id: string;
    type: "number";
    dataType: DataType;
    description: string | undefined;
    values: TypedNumberArray<ArrayBuffer>;
    bounds: DataTypeInterval;
}
export interface InlineSegmentPropertyMap {
    ids: BigUint64Array<ArrayBuffer>;
    properties: InlineSegmentProperty[];
}
export interface IndexedSegmentPropertyMapOptions {
    properties: readonly Readonly<IndexedSegmentProperty>[];
}
export declare class IndexedSegmentPropertySource extends ChunkSource {
    OPTIONS: IndexedSegmentPropertyMapOptions;
    properties: readonly Readonly<IndexedSegmentProperty>[];
    constructor(chunkManager: Borrowed<ChunkManager>, options: IndexedSegmentPropertyMapOptions);
    static encodeOptions(options: IndexedSegmentPropertyMapOptions): {
        [key: string]: any;
    };
}
export type IndicesArray = Uint32Array | Uint16Array | Uint8Array;
export declare class SegmentPropertyMap {
    inlineProperties: InlineSegmentPropertyMap | undefined;
    constructor(options: {
        inlineProperties?: InlineSegmentPropertyMap | undefined;
    });
}
export declare class PreprocessedSegmentPropertyMap {
    segmentPropertyMap: SegmentPropertyMap;
    inlineIdToIndex: IndicesArray | undefined;
    tags: InlineSegmentTagsProperty | undefined;
    labels: InlineSegmentStringProperty | undefined;
    numericalProperties: InlineSegmentNumericalProperty[];
    getSegmentInlineIndex(id: bigint): number;
    constructor(segmentPropertyMap: SegmentPropertyMap);
    getSegmentLabel(id: bigint): string | undefined;
}
export declare function normalizeInlineSegmentPropertyMap(inlineProperties: InlineSegmentPropertyMap): InlineSegmentPropertyMap;
export declare function mergeSegmentPropertyMaps(maps: SegmentPropertyMap[]): SegmentPropertyMap | undefined;
export declare function getPreprocessedSegmentPropertyMap(chunkManager: ChunkManager, maps: SegmentPropertyMap[]): PreprocessedSegmentPropertyMap | undefined;
export interface SortBy {
    fieldId: string;
    order: "<" | ">";
}
export interface ExplicitIdQuery {
    ids: bigint[];
    prefix?: undefined;
    regexp?: undefined;
    includeTags?: undefined;
    excludeTags?: undefined;
    numericalConstraints?: undefined;
    sortBy?: undefined;
    includeColumns?: undefined;
    errors?: undefined;
}
export interface NumericalPropertyConstraint {
    fieldId: string;
    bounds: DataTypeInterval;
}
export interface FilterQuery {
    ids?: undefined;
    prefix: string | undefined;
    regexp: RegExp | undefined;
    includeTags: string[];
    excludeTags: string[];
    numericalConstraints: NumericalPropertyConstraint[];
    sortBy: SortBy[];
    includeColumns: string[];
    errors?: undefined;
}
export interface QueryParseError {
    begin: number;
    end: number;
    message: string;
}
export interface QueryParseErrors {
    errors: QueryParseError[];
    ids?: undefined;
    prefix?: undefined;
    regexp?: undefined;
    includeTags?: undefined;
    excludeTags?: undefined;
    numericalConstraints?: undefined;
    sortBy?: undefined;
    includeColumns?: undefined;
}
export type QueryParseResult = ExplicitIdQuery | FilterQuery | QueryParseErrors;
export declare function parseSegmentQuery(db: PreprocessedSegmentPropertyMap | undefined, queryString: string): QueryParseResult;
export interface TagCount {
    tag: string;
    tagIndex: number;
    count: number;
    desc: string;
}
export interface PropertyHistogram {
    queryResult: QueryResult;
    window: DataTypeInterval;
    histogram: Uint32Array;
}
export interface QueryResult {
    query: QueryParseResult;
    intermediateIndices?: IndicesArray | undefined;
    intermediateIndicesMask?: Uint32Array | Uint16Array | Uint8Array | undefined;
    indices?: IndicesArray | undefined;
    explicitIds?: bigint[] | undefined;
    tags?: TagCount[] | undefined;
    count: number;
    total: number;
    errors?: QueryParseError[] | undefined;
}
export declare function executeSegmentQuery(db: PreprocessedSegmentPropertyMap | undefined, query: QueryParseResult): QueryResult;
export declare function updatePropertyHistograms(db: PreprocessedSegmentPropertyMap | undefined, queryResult: QueryResult | undefined, propertyHistograms: PropertyHistogram[], bounds: DataTypeInterval[]): void;
export declare function unparseSegmentQuery(db: PreprocessedSegmentPropertyMap | undefined, query: ExplicitIdQuery | FilterQuery): string;
export declare function forEachQueryResultSegmentId(db: PreprocessedSegmentPropertyMap | undefined, queryResult: QueryResult | undefined, callback: (id: bigint, index: number) => void): void;
export declare function forEachQueryResultSegmentIdGenerator(db: PreprocessedSegmentPropertyMap | undefined, queryResult: QueryResult | undefined): IterableIterator<bigint>;
export declare function findQueryResultIntersectionSize(db: PreprocessedSegmentPropertyMap | undefined, queryResult: QueryResult | undefined, segmentSet: Uint64Set | Uint64OrderedSet): number;
export declare function changeTagConstraintInSegmentQuery(query: FilterQuery, tag: string, include: boolean, value: boolean): FilterQuery;
export declare function isQueryUnconstrained(query: QueryParseResult): boolean;
export declare function queryIncludesColumn(query: QueryParseResult | undefined, fieldId: string): boolean;
