/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SharedDisjointUint64Sets } from "#src/shared_disjoint_sets.js";
import type { SharedWatchableValue } from "#src/shared_watchable_value.js";
import type { WatchableValue } from "#src/trackable_value.js";
import type { Uint64OrderedSet } from "#src/uint64_ordered_set.js";
import type { Uint64Set } from "#src/uint64_set.js";
import type { RefCounted } from "#src/util/disposable.js";
export interface VisibleSegmentsState {
    timestamp: WatchableValue<number | undefined>;
    visibleSegments: Uint64Set;
    selectedSegments: Uint64OrderedSet;
    segmentEquivalences: SharedDisjointUint64Sets;
    temporaryVisibleSegments: Uint64Set;
    temporarySegmentEquivalences: SharedDisjointUint64Sets;
    useTemporaryVisibleSegments: SharedWatchableValue<boolean>;
    useTemporarySegmentEquivalences: SharedWatchableValue<boolean>;
}
export declare const VISIBLE_SEGMENTS_STATE_PROPERTIES: readonly ["visibleSegments", "segmentEquivalences", "temporaryVisibleSegments", "temporarySegmentEquivalences", "useTemporaryVisibleSegments", "useTemporarySegmentEquivalences"];
export declare function onVisibleSegmentsStateChanged(context: RefCounted, state: VisibleSegmentsState, callback: () => void): void;
export declare function onTemporaryVisibleSegmentsStateChanged(context: RefCounted, state: VisibleSegmentsState, callback: () => void): void;
/**
 * Returns a string key for identifying a uint64 object id.
 */
export declare function getObjectKey(objectId: bigint): string;
export declare function getVisibleSegments(state: VisibleSegmentsState): Uint64Set;
export declare function getSegmentEquivalences(state: VisibleSegmentsState): SharedDisjointUint64Sets;
export declare function forEachVisibleSegment(state: VisibleSegmentsState, callback: (objectId: bigint, rootObjectId: bigint) => void): void;
export interface IndexedSegmentProperty {
    id: string;
    type: "string";
    description: string | undefined;
}
