/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { WatchableValue } from "#src/trackable_value.js";
import type { TypedNumberArray } from "#src/util/array.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
export type DimensionId = number;
export declare function newDimensionId(): DimensionId;
export interface CoordinateArray {
    explicit: boolean;
    coordinates: number[];
    labels: string[];
}
export interface CoordinateSpace {
    /**
     * If `true`, has been fully initialized (i.e. based on at least one data source).  If `false`,
     * may be partially initialized.
     */
    readonly valid: boolean;
    readonly rank: number;
    /**
     * Specifies the name of each dimension.
     */
    readonly names: readonly string[];
    readonly ids: readonly DimensionId[];
    /**
     * Timestamp of last user action that changed the name, scale, or unit of each dimension, or
     * `undefined` if there was no user action.
     */
    readonly timestamps: readonly number[];
    /**
     * Specifies the physical units corresponding to this dimension.  May be empty to indicate
     * unitless.
     */
    readonly units: readonly string[];
    /**
     * Specifies a scale for this dimension.
     */
    readonly scales: Float64Array;
    readonly bounds: CoordinateSpaceBounds;
    readonly boundingBoxes: readonly TransformedBoundingBox[];
    readonly coordinateArrays: (CoordinateArray | undefined)[];
}
export declare function boundingBoxesEqual(a: BoundingBox, b: BoundingBox): boolean;
export declare function coordinateArraysEqual(a: CoordinateArray | undefined, b: CoordinateArray | undefined): boolean;
export declare function normalizeCoordinateArray(coordinates: number[], labels: string[]): {
    coordinates: number[];
    labels: string[];
};
export declare function mergeCoordinateArrays(coordinateArrays: ReadonlyArray<CoordinateArray>): CoordinateArray;
export declare function mergeOptionalCoordinateArrays(coordinateArrays: ReadonlyArray<CoordinateArray | undefined>): CoordinateArray | undefined;
export declare function transformedBoundingBoxesEqual(a: TransformedBoundingBox, b: TransformedBoundingBox): boolean;
export declare function coordinateSpacesEqual(a: CoordinateSpace, b: CoordinateSpace): boolean;
export declare function unitsFromJson(units: string[], scaleExponents: Float64Array, obj: any): void;
export declare function makeCoordinateSpace(space: {
    readonly valid?: boolean;
    readonly names: readonly string[];
    readonly units: readonly string[];
    readonly scales: Float64Array;
    readonly rank?: number;
    readonly timestamps?: readonly number[];
    readonly ids?: readonly DimensionId[];
    readonly boundingBoxes?: readonly TransformedBoundingBox[];
    readonly bounds?: CoordinateSpaceBounds;
    readonly coordinateArrays?: (CoordinateArray | undefined)[];
}): CoordinateSpace;
export declare const emptyInvalidCoordinateSpace: CoordinateSpace;
export declare const emptyValidCoordinateSpace: CoordinateSpace;
export declare function coordinateSpaceFromJson(obj: any, allowNumericalDimensions?: boolean): CoordinateSpace;
export declare function coordinateSpaceToJson(coordinateSpace: CoordinateSpace): any;
export declare class TrackableCoordinateSpace extends WatchableValue<CoordinateSpace> {
    constructor();
    toJSON(): any;
    reset(): void;
    restoreState(obj: any): void;
}
export interface BoundingBox {
    lowerBounds: Float64Array;
    upperBounds: Float64Array;
}
export interface CoordinateSpaceBounds extends BoundingBox {
    voxelCenterAtIntegerCoordinates: boolean[];
}
export declare function roundCoordinateToVoxelCenter(bounds: CoordinateSpaceBounds, dimIndex: number, coordinate: number): number;
export declare function getDisplayLowerUpperBounds(bounds: CoordinateSpaceBounds, dimIndex: number): number[];
export declare function clampCoordinateToBounds(bounds: CoordinateSpaceBounds, dimIndex: number, coordinate: number): number;
export declare function clampAndRoundCoordinateToVoxelCenter(bounds: CoordinateSpaceBounds, dimIndex: number, coordinate: number): number;
export declare function getCenterBound(lower: number, upper: number): number;
export declare function getBoundingBoxCenter(out: Float32Array, bounds: BoundingBox): Float32Array;
export interface TransformedBoundingBox {
    box: BoundingBox;
    /**
     * Transform from "box" coordinate space to target coordinate space.
     */
    transform: Float64Array;
}
export declare function makeIdentityTransformedBoundingBox(box: BoundingBox): {
    box: BoundingBox;
    transform: Float64Array<ArrayBuffer>;
};
export declare function computeCombinedLowerUpperBound(boundingBox: TransformedBoundingBox, outputDimension: number, outputRank: number): {
    lower: number;
    upper: number;
} | undefined;
export declare function computeCombinedBounds(boundingBoxes: readonly TransformedBoundingBox[], outputRank: number): CoordinateSpaceBounds;
export declare function extendTransformedBoundingBox(boundingBox: TransformedBoundingBox, newOutputRank: number, newOutputDims: readonly number[]): TransformedBoundingBox;
export declare function makeSingletonDimTransformedBoundingBox(outputRank: number, outputDim: number): {
    transform: Float64Array<ArrayBuffer>;
    box: {
        lowerBounds: Float64Array<ArrayBuffer>;
        upperBounds: Float64Array<ArrayBuffer>;
    };
};
export declare function extendTransformedBoundingBoxUpToRank(boundingBox: TransformedBoundingBox, oldOutputRank: number, newOutputRank: number): TransformedBoundingBox;
export interface CoordinateSpaceTransform {
    /**
     * Equal to `outputSpace.rank`.
     */
    readonly rank: number;
    /**
     * The source rank, which is <= rank.  Input dimensions >= sourceRank are synthetic and serve only
     * to embed the source data in a larger view space.
     */
    readonly sourceRank: number;
    /**
     * May have rank less than `outputSpace.rank`, in which case additional unnamed dimensions with
     * range `[0, 1)` are implicitly added.
     */
    readonly inputSpace: CoordinateSpace;
    readonly outputSpace: CoordinateSpace;
    /**
     * `(rank + 1) * (rank + 1)` homogeneous column-major transformation matrix, where columns
     * correspond to input dimensions and rows correspond to output dimensions.
     */
    readonly transform: Float64Array;
}
export declare function coordinateSpaceTransformsEquivalent(defaultTransform: CoordinateSpaceTransform, transform: CoordinateSpaceTransform): boolean;
export declare function makeIdentityTransform(inputSpace: CoordinateSpace): CoordinateSpaceTransform;
export declare function getOutputSpaceWithTransformedBoundingBoxes(inputSpace: CoordinateSpace, transform: Float64Array, oldOutputSpace: CoordinateSpace): CoordinateSpace;
export declare function isValidDimensionName(name: string, allowNumericalNames?: boolean): boolean;
export declare function validateDimensionNames(names: string[], allowNumericalNames?: boolean): boolean;
export declare function getDimensionNameValidity(names: readonly string[]): boolean[];
export declare function isLocalDimension(name: string): boolean;
export declare function isLocalOrChannelDimension(name: string): boolean;
export declare function isChannelDimension(name: string): boolean;
export declare function isGlobalDimension(name: string): boolean;
export declare function convertTransformOutputScales(existingTransform: Float64Array, existingOutputScales: Float64Array, newOutputScales: Float64Array): Float64Array<ArrayBuffer>;
export declare function makeDimensionNameUnique(name: string, existingNames: readonly string[]): string;
export declare function remapTransformInputSpace(old: CoordinateSpaceTransform, inputSpace: CoordinateSpace): CoordinateSpaceTransform;
export declare class WatchableCoordinateSpaceTransform implements Trackable, WatchableValueInterface<CoordinateSpaceTransform> {
    readonly mutableSourceRank: boolean;
    private value_;
    readonly outputSpace: WatchableValueInterface<CoordinateSpace>;
    readonly inputSpace: WatchableValueInterface<CoordinateSpace>;
    changed: NullarySignal;
    private inputSpaceChanged;
    readonly defaultTransform: CoordinateSpaceTransform;
    constructor(defaultTransform: CoordinateSpaceTransform, mutableSourceRank?: boolean);
    set value(value: CoordinateSpaceTransform);
    get value(): CoordinateSpaceTransform;
    reset(): void;
    get defaultInputSpace(): CoordinateSpace;
    get spec(): Readonly<CoordinateTransformSpecification> | undefined;
    set transform(transform: Float64Array);
    set spec(spec: Readonly<CoordinateTransformSpecification> | undefined);
    toJSON(): {
        sourceRank: number | undefined;
        matrix: number[][] | undefined;
        outputDimensions: any;
        inputDimensions: any;
    } | undefined;
    restoreState(obj: unknown): void;
}
export declare function expectDimensionName(obj: unknown, allowNumericalNames?: boolean): string;
export declare function dimensionNamesFromJson(obj: any, allowNumericalNames?: boolean): string[];
export declare class CoordinateSpaceCombiner {
    combined: WatchableValueInterface<CoordinateSpace>;
    private bindings;
    private retainCount;
    private prevCombined;
    dimensionRefCounts: Map<string, number>;
    getRenameValidity(newNames: readonly string[]): boolean[];
    private includeDimensionPredicate_;
    get includeDimensionPredicate(): (name: string) => boolean;
    set includeDimensionPredicate(value: (name: string) => boolean);
    constructor(combined: WatchableValueInterface<CoordinateSpace>, includeDimensionPredicate: (name: string) => boolean);
    private update;
    private handleCombinedChanged;
    retain(): () => void;
    bind(space: WatchableValueInterface<CoordinateSpace>): () => void;
}
export declare function homogeneousTransformSubmatrix<T extends TypedNumberArray>(arrayConstructor: {
    new (n: number): T;
}, oldTransform: TypedNumberArray, oldRank: number, oldRows: readonly number[], oldCols: readonly number[]): T;
export interface CoordinateTransformSpecification {
    sourceRank: number;
    transform: Float64Array | undefined;
    inputSpace: CoordinateSpace | undefined;
    outputSpace: CoordinateSpace;
}
export declare function coordinateTransformSpecificationFromLegacyJson(obj: unknown): CoordinateTransformSpecification | undefined;
export declare function coordinateTransformSpecificationFromJson(j: unknown): CoordinateTransformSpecification | undefined;
export declare function coordinateTransformSpecificationToJson(spec: CoordinateTransformSpecification | undefined): {
    sourceRank: number | undefined;
    matrix: number[][] | undefined;
    outputDimensions: any;
    inputDimensions: any;
} | undefined;
export declare function permuteTransformedBoundingBox(boundingBox: TransformedBoundingBox, newToOld: readonly number[], oldOutputRank: number): TransformedBoundingBox | undefined;
export declare function permuteCoordinateSpace(existing: CoordinateSpace, newToOld: readonly number[]): CoordinateSpace;
export declare function insertDimensionAt(existing: CoordinateSpace, targetIndex: number, sourceIndex: number): CoordinateSpace;
export declare function getInferredOutputScale(transform: CoordinateSpaceTransform, outputDim: number): {
    scale: number;
    unit: string;
} | undefined;
export declare function getDefaultInputScale(transform: WatchableCoordinateSpaceTransform, inputDim: number): {
    scale: number;
    unit: string;
} | undefined;
