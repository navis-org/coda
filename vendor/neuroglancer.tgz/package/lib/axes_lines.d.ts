/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ProjectionParameters } from "#src/projection_parameters.js";
import { RefCounted } from "#src/util/disposable.js";
import { mat4 } from "#src/util/geom.js";
import { GLBuffer } from "#src/webgl/buffer.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderProgram } from "#src/webgl/shader.js";
export declare function computeAxisLineMatrix(projectionParameters: ProjectionParameters, axisLength: number): mat4;
export declare class AxesLineHelper extends RefCounted {
    gl: GL;
    vertexBuffer: GLBuffer;
    colorBuffer: GLBuffer;
    trivialColorShader: ShaderProgram;
    constructor(gl: GL);
    static get(gl: GL): AxesLineHelper;
    draw(mat: mat4, blend?: boolean): void;
}
