/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { AnnotationLayerState } from "#src/annotation/annotation_layer_state.js";
import type { AnnotationType } from "#src/annotation/index.js";
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { CoordinateSpace, CoordinateTransformSpecification } from "#src/coordinate_transform.js";
import { CoordinateSpaceCombiner, TrackableCoordinateSpace } from "#src/coordinate_transform.js";
import type { DataSourceRegistry, DataSourceSpecification, DataSubsource } from "#src/datasource/index.js";
import type { DisplayContext, RenderedPanel } from "#src/display_context.js";
import type { LoadedDataSubsource } from "#src/layer/layer_data_source.js";
import { LayerDataSource } from "#src/layer/layer_data_source.js";
import type { DisplayDimensions, WatchableDisplayDimensionRenderInfo } from "#src/navigation_state.js";
import { CoordinateSpacePlaybackVelocity, Position } from "#src/navigation_state.js";
import type { RenderLayerTransform } from "#src/render_coordinate_transform.js";
import type { RenderLayer, RenderLayerRole, VisibilityTrackedRenderLayer } from "#src/renderlayer.js";
import type { VolumeType } from "#src/sliceview/volume/base.js";
import { TrackableBoolean } from "#src/trackable_boolean.js";
import type { TrackableValueInterface, WatchableSet, WatchableValueInterface } from "#src/trackable_value.js";
import { WatchableValue } from "#src/trackable_value.js";
import { UserLayerSidePanelsState } from "#src/ui/layer_side_panel_state.js";
import { TrackableSidePanelLocation } from "#src/ui/side_panel_location.js";
import type { GlobalToolBinder } from "#src/ui/tool.js";
import { LayerToolBinder, SelectedLegacyTool } from "#src/ui/tool.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { MessageList } from "#src/util/message_list.js";
import type { AnyConstructor } from "#src/util/mixin.js";
import { NullarySignal, Signal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import type { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
import type { DependentViewContext } from "#src/widget/dependent_view_widget.js";
import type { Tab } from "#src/widget/tab_view.js";
import { TabSpecification } from "#src/widget/tab_view.js";
import type { RPC } from "#src/worker_rpc.js";
export interface UserLayerSelectionState {
    generation: number;
    localPositionValid: boolean;
    localPosition: Float32Array;
    localCoordinateSpace: CoordinateSpace | undefined;
    annotationId: string | undefined;
    annotationType: AnnotationType | undefined;
    annotationBuffer: Uint8Array | undefined;
    annotationIndex: number | undefined;
    annotationCount: number | undefined;
    annotationInstanceIndex: number | undefined;
    annotationInstanceCount: number | undefined;
    annotationSourceIndex: number | undefined;
    annotationSubsource: string | undefined;
    annotationSubsubsourceId: string | undefined;
    annotationPartIndex: number | undefined;
    value: any;
}
export declare class LayerActionContext {
    callbacks: (() => void)[];
    defer(callback: () => void): void;
}
export interface UserLayerTab {
    id: string;
    label: string;
    order: number;
    getter: (layer: UserLayer) => Tab;
}
export declare const USER_LAYER_TABS: UserLayerTab[];
export declare class UserLayer extends RefCounted {
    managedLayer: Borrowed<ManagedUserLayer>;
    get localPosition(): Position;
    get localVelocity(): CoordinateSpacePlaybackVelocity;
    get localCoordinateSpaceCombiner(): CoordinateSpaceCombiner;
    get localCoordinateSpace(): TrackableCoordinateSpace;
    static type: string;
    static typeAbbreviation: string;
    get type(): string;
    static supportsPickOption: boolean;
    static supportsLayerBarColorSyncOption: boolean;
    pick: TrackableBoolean;
    selectionState: UserLayerSelectionState;
    messages: MessageList;
    layerEventListeners: Map<string, Signal<() => void>>;
    dispatchLayerEvent(type: string): void;
    registerLayerEvent(type: string, handler: () => void): () => boolean;
    observeLayerColor(_: () => void): () => void;
    get automaticLayerBarColors(): string[] | undefined;
    get layerBarColors(): string[] | undefined;
    initializeSelectionState(state: this["selectionState"]): void;
    resetSelectionState(state: this["selectionState"]): void;
    selectionStateFromJson(state: this["selectionState"], json: any): void;
    displaySelectionState(state: this["selectionState"], parent: HTMLElement, context: DependentViewContext): boolean;
    selectionStateToJson(state: this["selectionState"], forPython: boolean): any;
    captureSelectionState(state: this["selectionState"], mouseState: MouseSelectionState): void;
    copySelectionState(dest: this["selectionState"], source: this["selectionState"]): void;
    layersChanged: NullarySignal;
    readyStateChanged: NullarySignal;
    specificationChanged: NullarySignal;
    renderLayers: RenderLayer[];
    private loadingCounter;
    get isReady(): boolean;
    tabs: TabSpecification;
    panels: UserLayerSidePanelsState;
    tool: SelectedLegacyTool;
    toolBinder: LayerToolBinder<this>;
    dataSourcesChanged: NullarySignal;
    dataSources: LayerDataSource[];
    get manager(): LayerListSpecification;
    constructor(managedLayer: Borrowed<ManagedUserLayer>);
    canAddDataSource(): boolean;
    addDataSource(spec: DataSourceSpecification | undefined): LayerDataSource;
    activateDataSubsources(subsources: Iterable<LoadedDataSubsource>): void;
    updateDataSubsourceActivations(): void;
    private decrementLoadingCounter;
    markLoading(): () => void;
    addCoordinateSpace(coordinateSpace: WatchableValueInterface<CoordinateSpace>): () => void;
    initializationDone(): void;
    getLegacyDataSourceSpecifications(sourceSpec: string | undefined, layerSpec: any, legacyTransform: CoordinateTransformSpecification | undefined, explicitSpecs: DataSourceSpecification[]): DataSourceSpecification[];
    getDataSourceSpecifications(layerSpec: any): DataSourceSpecification[];
    restoreState(specification: any): void;
    addRenderLayer(layer: Owned<RenderLayer>): () => void;
    removeRenderLayer(layer: RenderLayer): void;
    disposed(): void;
    getValueAt(position: Float32Array, pickState: PickState): any;
    transformPickedValue(value: any): any;
    toJSON(): any;
    handleAction(_action: string, _context: LayerActionContext): void;
    selectedValueToJson(value: any): any;
    selectedValueFromJson(json: any): any;
    setLayerPosition(modelTransform: RenderLayerTransform, layerPosition: Float32Array): void;
}
export declare class ManagedUserLayer extends RefCounted {
    manager: Borrowed<LayerListSpecification>;
    localCoordinateSpace: TrackableCoordinateSpace;
    localCoordinateSpaceCombiner: CoordinateSpaceCombiner;
    localPosition: Position;
    localVelocity: CoordinateSpacePlaybackVelocity;
    nonArchivedLayerIndex: number;
    readyStateChanged: NullarySignal;
    layerChanged: NullarySignal;
    specificationChanged: NullarySignal;
    containers: Set<LayerManager>;
    private layer_;
    get layer(): UserLayer | null;
    private unregisterUserLayer;
    /**
     * If layer is not null, tranfers ownership of a reference.
     */
    set layer(layer: UserLayer | null);
    isReady(): boolean | undefined;
    private name_;
    get name(): string;
    set name(value: string);
    visible: boolean;
    archived: boolean;
    get supportsPickOption(): boolean;
    get pickEnabled(): boolean;
    set pickEnabled(value: boolean);
    get layerBarColors(): string[] | undefined;
    observeLayerColor(callback: () => void): () => void;
    get supportsLayerBarColorSyncOption(): boolean;
    /**
     * If layer is not null, tranfers ownership of a reference.
     */
    constructor(name: string, manager: Borrowed<LayerListSpecification>);
    toJSON(): any;
    setVisible(value: boolean): void;
    setArchived(value: boolean): void;
    disposed(): void;
}
export declare class LayerManager extends RefCounted {
    managedLayers: ManagedUserLayer[];
    layerSet: Set<ManagedUserLayer>;
    layersChanged: NullarySignal;
    readyStateChanged: NullarySignal;
    specificationChanged: NullarySignal;
    boundPositions: WeakSet<Position>;
    numDirectUsers: number;
    nonArchivedLayerIndexGeneration: number;
    private renderLayerToManagedLayerMapGeneration;
    private renderLayerToManagedLayerMap_;
    constructor();
    private scheduleRemoveLayersWithSingleRef;
    updateNonArchivedLayerIndices(): void;
    getLayerByNonArchivedIndex(index: number): ManagedUserLayer | undefined;
    get renderLayerToManagedLayerMap(): Map<RenderLayer, ManagedUserLayer>;
    filter(predicate: (layer: ManagedUserLayer) => boolean): void;
    private removeLayersWithSingleRef;
    private updateSignalBindings;
    useDirectly(): () => void;
    /**
     * Assumes ownership of an existing reference to managedLayer.
     */
    addManagedLayer(managedLayer: ManagedUserLayer, index?: number | undefined): ManagedUserLayer;
    readyRenderLayers(): Generator<RenderLayer, void, unknown>;
    unbindManagedLayer(managedLayer: ManagedUserLayer): void;
    clear(): void;
    remove(index: number): void;
    removeManagedLayer(managedLayer: ManagedUserLayer): void;
    reorderManagedLayer(oldIndex: number, newIndex: number): void;
    disposed(): void;
    getLayerByName(name: string): ManagedUserLayer | undefined;
    getUniqueLayerName(name: string): string;
    has(layer: Borrowed<ManagedUserLayer>): boolean;
    get renderLayers(): {
        [Symbol.iterator](): Generator<RenderLayer, void, unknown>;
    };
    get visibleRenderLayers(): {
        [Symbol.iterator](): Generator<RenderLayer, void, unknown>;
    };
    invokeAction(action: string): void;
}
export interface PickState {
    pickedRenderLayer: RenderLayer | null;
    pickedValue: bigint;
    pickedOffset: number;
    pickedAnnotationLayer: AnnotationLayerState | undefined;
    pickedAnnotationId: string | undefined;
    pickedAnnotationBuffer: ArrayBuffer | undefined;
    pickedAnnotationBufferBaseOffset: number | undefined;
    pickedAnnotationIndex: number | undefined;
    pickedAnnotationCount: number | undefined;
    pickedAnnotationType: AnnotationType | undefined;
    pickedAnnotationInstanceIndex: number | undefined;
    pickedAnnotationInstanceCount: number | undefined;
}
export declare class MouseSelectionState implements PickState {
    changed: NullarySignal;
    coordinateSpace: CoordinateSpace;
    position: Float32Array;
    unsnappedPosition: Float32Array;
    active: boolean;
    displayDimensions: DisplayDimensions | undefined;
    pickedRenderLayer: RenderLayer | null;
    pickedValue: bigint;
    pickedOffset: number;
    pickedAnnotationLayer: AnnotationLayerState | undefined;
    pickedAnnotationId: string | undefined;
    pickedAnnotationBuffer: ArrayBuffer | undefined;
    pickedAnnotationBufferBaseOffset: number | undefined;
    pickedAnnotationIndex: number | undefined;
    pickedAnnotationInstanceIndex: number | undefined;
    pickedAnnotationCount: number | undefined;
    pickedAnnotationInstanceCount: number | undefined;
    pickedAnnotationType: AnnotationType | undefined;
    pageX: number;
    pageY: number;
    private forcerFunction;
    removeForcer(forcer: () => void): void;
    setForcer(forcer: (() => void) | undefined): void;
    updateUnconditionally(): boolean;
    setActive(value: boolean): void;
}
export declare class LayerSelectedValues extends RefCounted {
    layerManager: LayerManager;
    mouseState: MouseSelectionState;
    changed: NullarySignal;
    needsUpdate: boolean;
    constructor(layerManager: LayerManager, mouseState: MouseSelectionState);
    /**
     * This should be called when the layer data may have changed, due to the set of managed layers
     * changing or new data having been received.
     */
    handleLayerChange(): void;
    handleChange(): void;
    update(): void;
    get<T extends UserLayer>(userLayer: T): T["selectionState"] | undefined;
    toJSON(): {
        [key: string]: any;
    };
}
export interface PersistentLayerSelectionState {
    layer: UserLayer;
    state: UserLayerSelectionState;
}
export interface PersistentViewerSelectionState {
    layers: PersistentLayerSelectionState[];
    coordinateSpace: CoordinateSpace;
    position: Float32Array | undefined;
}
export declare class TrackableDataSelectionState extends RefCounted implements TrackableValueInterface<PersistentViewerSelectionState | undefined> {
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    layerSelectedValues: Borrowed<LayerSelectedValues>;
    changed: NullarySignal;
    history: PersistentViewerSelectionState[];
    historyIndex: number;
    location: TrackableSidePanelLocation;
    constructor(coordinateSpace: WatchableValueInterface<CoordinateSpace>, layerSelectedValues: Borrowed<LayerSelectedValues>);
    private value_;
    pin: WatchableValue<boolean>;
    get value(): PersistentViewerSelectionState | undefined;
    goBack(): void;
    canGoBack(): boolean;
    canGoForward(): boolean;
    goForward(): void;
    set value(value: PersistentViewerSelectionState | undefined);
    captureSingleLayerState<T extends UserLayer>(userLayer: Borrowed<T>, capture: (state: T["selectionState"]) => boolean, pin?: boolean | "toggle" | "force-unpin"): void;
    reset(): void;
    toJSON(): any;
    select(): void;
    unpin(): void;
    capture(canRetain?: boolean): void;
    restoreState(obj: unknown): void;
}
export declare function capturePersistentViewerSelectionState(layerSelectedValues: Borrowed<LayerSelectedValues>): PersistentViewerSelectionState | undefined;
export interface LayerView {
    displayDimensionRenderInfo: WatchableDisplayDimensionRenderInfo;
    flushBackendProjectionParameters(): void;
    rpc: RPC;
    rpcId: number;
}
export declare class VisibleLayerInfo<View extends LayerView = LayerView, AttachmentState = unknown> extends RefCounted {
    view: View;
    messages: MessageList;
    seenGeneration: number;
    state: AttachmentState | undefined;
    constructor(view: View);
}
export declare class VisibleRenderLayerTracker<View extends LayerView, RenderLayerType extends VisibilityTrackedRenderLayer<View>> extends RefCounted {
    layerManager: LayerManager;
    renderLayerType: {
        new (...args: any[]): RenderLayerType;
    };
    view: View;
    roles: WatchableSet<RenderLayerRole>;
    private layerAdded;
    visibility: WatchableVisibilityPriority;
    /**
     * Maps a layer to the disposer to call when it is no longer visible.
     */
    private visibleLayers_;
    private debouncedUpdateVisibleLayers;
    constructor(layerManager: LayerManager, renderLayerType: {
        new (...args: any[]): RenderLayerType;
    }, view: View, roles: WatchableSet<RenderLayerRole>, layerAdded: (layer: RenderLayerType, info: VisibleLayerInfo<View>) => void, visibility: WatchableVisibilityPriority);
    disposed(): void;
    private updateVisibleLayers;
    get visibleLayers(): Map<RenderLayerType, VisibleLayerInfo<View, unknown>>;
}
export declare function makeRenderedPanelVisibleLayerTracker<View extends RenderedPanel & LayerView, RenderLayerType extends VisibilityTrackedRenderLayer<View>>(layerManager: LayerManager, renderLayerType: {
    new (...args: any[]): RenderLayerType;
}, roles: WatchableSet<RenderLayerRole>, panel: View, layerAdded?: (layer: RenderLayerType, info: VisibleLayerInfo<View>) => void): VisibleRenderLayerTracker<View, RenderLayerType>;
export declare class SelectedLayerState extends RefCounted implements Trackable {
    layerManager: Owned<LayerManager>;
    changed: NullarySignal;
    location: TrackableSidePanelLocation;
    layer_: ManagedUserLayer | undefined;
    get layer(): ManagedUserLayer | undefined;
    get visible(): boolean;
    toggle(layer: ManagedUserLayer): void;
    set visible(value: boolean);
    private maybeDeleteNewLayer;
    private existingLayerDisposer?;
    constructor(layerManager: Owned<LayerManager>);
    set layer(layer: ManagedUserLayer | undefined);
    toJSON(): any;
    restoreState(obj: any): void;
    reset(): void;
}
export declare class LayerReference extends RefCounted implements Trackable {
    layerManager: Owned<LayerManager>;
    filter: (layer: ManagedUserLayer) => boolean;
    private layerName_;
    private layer_;
    changed: NullarySignal;
    constructor(layerManager: Owned<LayerManager>, filter: (layer: ManagedUserLayer) => boolean);
    get layer(): ManagedUserLayer | undefined;
    get layerName(): string | undefined;
    set layer(value: ManagedUserLayer | undefined);
    set layerName(value: string | undefined);
    private validate;
    restoreState(obj: any): void;
    toJSON(): string | undefined;
    reset(): void;
}
export declare class LinkedLayerGroup extends RefCounted implements Trackable {
    layerManager: LayerManager;
    layer: UserLayer;
    predicate: (layer: UserLayer) => boolean;
    getGroup: (layer: UserLayer) => LinkedLayerGroup;
    private linkedLayers_;
    private root_;
    changed: NullarySignal;
    linkedLayersChanged: NullarySignal;
    readonly root: WatchableValueInterface<UserLayer>;
    get linkedLayers(): ReadonlySet<UserLayer>;
    get rootGroup(): LinkedLayerGroup;
    constructor(layerManager: LayerManager, layer: UserLayer, predicate: (layer: UserLayer) => boolean, getGroup: (layer: UserLayer) => LinkedLayerGroup);
    reset(): void;
    restoreState(obj: unknown): void;
    toJSON(): string | undefined;
    isolate(notifyChanged?: boolean): void;
    linkByName(otherLayerName: string): void;
    linkToLayer(otherUserLayer: UserLayer): void;
    disposed(): void;
}
export declare function initializeLayerFromSpec(managedLayer: Borrowed<ManagedUserLayer>, spec: any): void;
export declare function initializeLayerFromSpecShowErrorStatus(managedLayer: Borrowed<ManagedUserLayer>, spec: any): void;
export declare function makeLayer(manager: LayerListSpecification, name: string, spec: any): ManagedUserLayer;
export declare abstract class LayerListSpecification extends RefCounted {
    changed: NullarySignal;
    abstract rpc: RPC;
    abstract dataSourceProviderRegistry: Borrowed<DataSourceRegistry>;
    abstract layerManager: Borrowed<LayerManager>;
    abstract chunkManager: Borrowed<ChunkManager>;
    abstract layerSelectedValues: Borrowed<LayerSelectedValues>;
    abstract readonly root: TopLevelLayerListSpecification;
    abstract add(layer: Owned<ManagedUserLayer>, index?: number | undefined): void;
    abstract rootLayers: Borrowed<LayerManager>;
}
export declare class TopLevelLayerListSpecification extends LayerListSpecification {
    display: DisplayContext;
    dataSourceProviderRegistry: DataSourceRegistry;
    layerManager: LayerManager;
    chunkManager: ChunkManager;
    selectionState: Borrowed<TrackableDataSelectionState>;
    selectedLayer: Borrowed<SelectedLayerState>;
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    globalPosition: Borrowed<Position>;
    toolBinder: Borrowed<GlobalToolBinder>;
    get rpc(): RPC;
    get root(): this;
    coordinateSpaceCombiner: CoordinateSpaceCombiner;
    subsets: Set<LayerSubsetSpecification>;
    layerSelectedValues: LayerSelectedValues;
    constructor(display: DisplayContext, dataSourceProviderRegistry: DataSourceRegistry, layerManager: LayerManager, chunkManager: ChunkManager, selectionState: Borrowed<TrackableDataSelectionState>, selectedLayer: Borrowed<SelectedLayerState>, coordinateSpace: WatchableValueInterface<CoordinateSpace>, globalPosition: Borrowed<Position>, toolBinder: Borrowed<GlobalToolBinder>);
    reset(): void;
    restoreState(x: any): void;
    add(layer: ManagedUserLayer, index?: number | undefined): void;
    toJSON(): any[] | undefined;
    get rootLayers(): LayerManager;
}
/**
 * Class for specifying a subset of a TopLevelLayerListsSpecification.
 */
export declare class LayerSubsetSpecification extends LayerListSpecification {
    master: Owned<TopLevelLayerListSpecification>;
    changed: NullarySignal;
    get rpc(): RPC;
    get dataSourceProviderRegistry(): DataSourceRegistry;
    get chunkManager(): ChunkManager;
    get layerSelectedValues(): LayerSelectedValues;
    get root(): TopLevelLayerListSpecification;
    layerManager: LayerManager;
    constructor(master: Owned<TopLevelLayerListSpecification>);
    disposed(): void;
    reset(): void;
    restoreState(x: any): void;
    toJSON(): string[];
    add(layer: ManagedUserLayer, index?: number | undefined): void;
    get rootLayers(): LayerManager;
}
export type UserLayerConstructor<LayerType extends UserLayer = UserLayer> = typeof UserLayer & AnyConstructor<LayerType>;
export declare const layerTypes: Map<string, UserLayerConstructor<UserLayer>>;
export interface LayerTypeGuess {
    layerConstructor: UserLayerConstructor;
    priority: number;
}
export type LayerTypeDetector = (subsource: DataSubsource) => LayerTypeGuess | undefined;
export declare function registerLayerType(layerConstructor: UserLayerConstructor, name?: string): void;
export declare function registerLayerTypeDetector(detector: LayerTypeDetector): void;
export declare function registerVolumeLayerType(volumeType: VolumeType, layerConstructor: UserLayerConstructor): void;
export declare function changeLayerType(managedLayer: Borrowed<ManagedUserLayer>, layerConstructor: typeof UserLayer): void;
export declare function changeLayerName(managedLayer: Borrowed<ManagedUserLayer>, newName: string): boolean;
export declare function deleteLayer(managedLayer: Borrowed<ManagedUserLayer>): void;
export declare function detectLayerTypeFromDataSubsource(subsource: DataSubsource): LayerTypeGuess | undefined;
export declare function detectLayerType(userLayer: UserLayer): UserLayerConstructor | undefined;
/**
 * Special UserLayer type used when creating a new layer in the UI.
 */
export declare class NewUserLayer extends UserLayer {
    static type: string;
    static typeAbbreviation: string;
    detectedLayerConstructor: UserLayerConstructor | undefined;
    activateDataSubsources(subsources: Iterable<LoadedDataSubsource>): void;
}
/**
 * Special UserLayer type that automatically changes to the appropriate layer type.
 */
export declare class AutoUserLayer extends UserLayer {
    static type: string;
    static typeAbbreviation: string;
    activateDataSubsources(subsources: Iterable<LoadedDataSubsource>): void;
}
export declare function addNewLayer(manager: Borrowed<LayerListSpecification>, selectedLayer: Borrowed<SelectedLayerState>): void;
