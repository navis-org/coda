import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import type { LayerControlDefinition } from "#src/widget/layer_control.js";
export declare const LAYER_CONTROLS: LayerControlDefinition<SegmentationUserLayer>[];
export declare function registerLayerControls(layerType: typeof SegmentationUserLayer): void;
