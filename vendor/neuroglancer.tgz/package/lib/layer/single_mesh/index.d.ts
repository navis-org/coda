/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/layer/single_mesh/style.css";
import type { ManagedUserLayer } from "#src/layer/index.js";
import { UserLayer } from "#src/layer/index.js";
import type { LoadedDataSubsource } from "#src/layer/layer_data_source.js";
import type { VertexAttributeInfo } from "#src/single_mesh/base.js";
import { SingleMeshDisplayState } from "#src/single_mesh/frontend.js";
import { TrackableBoolean } from "#src/trackable_boolean.js";
import { WatchableValue } from "#src/trackable_value.js";
import type { Borrowed } from "#src/util/disposable.js";
export declare class SingleMeshUserLayer extends UserLayer {
    managedLayer: Borrowed<ManagedUserLayer>;
    displayState: SingleMeshDisplayState;
    codeVisible: TrackableBoolean;
    hideInactiveShaderControls: TrackableBoolean;
    vertexAttributes: WatchableValue<VertexAttributeInfo[] | undefined>;
    constructor(managedLayer: Borrowed<ManagedUserLayer>);
    restoreState(specification: any): void;
    activateDataSubsources(subsources: Iterable<LoadedDataSubsource>): void;
    toJSON(): any;
    static type: string;
    static typeAbbreviation: string;
}
