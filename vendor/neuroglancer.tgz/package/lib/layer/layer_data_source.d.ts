/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpace, CoordinateTransformSpecification } from "#src/coordinate_transform.js";
import { WatchableCoordinateSpaceTransform } from "#src/coordinate_transform.js";
import type { DataSource, DataSourceSpecification, DataSubsourceEntry, DataSubsourceSpecification } from "#src/datasource/index.js";
import type { UserLayer } from "#src/layer/index.js";
import type { RenderLayer } from "#src/renderlayer.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { MessageList } from "#src/util/message_list.js";
import { MultiConsumerProgressListener } from "#src/util/progress_listener.js";
import { NullarySignal } from "#src/util/signal.js";
export declare function parseDataSubsourceSpecificationFromJson(json: unknown): DataSubsourceSpecification;
export declare function layerDataSourceSpecificationFromJson(obj: unknown, legacyTransform?: CoordinateTransformSpecification | undefined): DataSourceSpecification;
export declare function layerDataSourceSpecificationToJson(spec: DataSourceSpecification): string | {
    url: string;
    transform: {
        sourceRank: number | undefined;
        matrix: number[][] | undefined;
        outputDimensions: any;
        inputDimensions: any;
    } | undefined;
    subsources: any;
    enableDefaultSubsources: boolean | undefined;
    state: any;
};
export declare class LoadedDataSubsource {
    loadedDataSource: LoadedLayerDataSource;
    subsourceEntry: DataSubsourceEntry;
    subsourceSpec: DataSubsourceSpecification | undefined;
    subsourceIndex: number;
    subsourceToModelSubspaceTransform: Float32Array;
    modelSubspaceDimensionIndices: number[];
    enabled: boolean;
    activated: RefCounted | undefined;
    guardValues: any[];
    messages: MessageList;
    isActiveChanged: NullarySignal;
    constructor(loadedDataSource: LoadedLayerDataSource, subsourceEntry: DataSubsourceEntry, subsourceSpec: DataSubsourceSpecification | undefined, subsourceIndex: number, enableDefaultSubsources: boolean);
    activate(callback: (refCounted: RefCounted) => void, ...guardValues: any[]): void;
    deactivate(error: string): void;
    addRenderLayer(renderLayer: Owned<RenderLayer>): void;
    getRenderLayerTransform(channelCoordinateSpace?: WatchableValueInterface<CoordinateSpace>): import("#src/trackable_value.js").CachedWatchableValue<import("#src/render_coordinate_transform.js").RenderLayerTransformOrError>;
}
export declare class LoadedLayerDataSource extends RefCounted {
    layerDataSource: LayerDataSource;
    dataSource: DataSource;
    error: undefined;
    enabledSubsourcesChanged: NullarySignal;
    activatedSubsourcesChanged: NullarySignal;
    messages: MessageList;
    transform: WatchableCoordinateSpaceTransform;
    subsources: LoadedDataSubsource[];
    enableDefaultSubsources: boolean;
    get enabledSubsources(): LoadedDataSubsource[];
    get layer(): UserLayer;
    constructor(layerDataSource: LayerDataSource, dataSource: DataSource, spec: DataSourceSpecification);
    disposed(): void;
}
export type LayerDataSourceLoadState = {
    error: Error;
} | LoadedLayerDataSource | undefined;
export declare class LayerDataSource extends RefCounted {
    layer: Borrowed<UserLayer>;
    changed: NullarySignal;
    messages: MessageList;
    progressListener: MultiConsumerProgressListener;
    private loadState_;
    private spec_;
    private specGeneration;
    private refCounted_;
    constructor(layer: Borrowed<UserLayer>, spec?: DataSourceSpecification | undefined);
    get spec(): DataSourceSpecification;
    get loadState(): LayerDataSourceLoadState;
    set spec(spec: DataSourceSpecification);
    disposed(): void;
    toJSON(): string | {
        url: string;
        transform: {
            sourceRank: number | undefined;
            matrix: number[][] | undefined;
            outputDimensions: any;
            inputDimensions: any;
        } | undefined;
        subsources: any;
        enableDefaultSubsources: boolean | undefined;
        state: any;
    };
}
