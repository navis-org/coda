/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { AnnotationPropertySpec } from "#src/annotation/index.js";
import type { AnnotationUserLayer } from "#src/layer/annotation/index.js";
import type { ToolActivation } from "#src/ui/tool.js";
import { LayerTool } from "#src/ui/tool.js";
import type { ActionEvent } from "#src/util/event_action_map.js";
import type { AnyConstructor } from "#src/util/mixin.js";
type AnnotationUserLayerConstructor = AnyConstructor<AnnotationUserLayer>;
export declare function registerAnnotationPropertyTools(contextType: AnnotationUserLayerConstructor): void;
export declare function removeInvalidPropertyToolBindings(layer: AnnotationUserLayer): void;
export declare function keyForEnumOptionIndex(index: number): string | undefined;
export declare function getEnumPropertyBindingConfigurationKey(optionCount: number): string;
export declare function boundKeyEventIdentifier(layer: AnnotationUserLayer, toolId: string): string | undefined;
type EntryKeyBinder = (eventKey: string, action: string, handler: (event: ActionEvent<Event>) => void) => void;
interface NumericEntryOptions {
    isFloat: () => boolean;
    allowNegative: () => boolean;
    range: () => [number, number];
    currentValue: () => number | undefined;
    commit: (value: number) => void;
}
export declare class NumericEntryBuffer {
    private readonly options;
    private buffer;
    constructor(options: NumericEntryOptions);
    reset(): void;
    private parse;
    private get outOfRange();
    bindKeys(addBinding: EntryKeyBinder, requestRefresh: () => void, activation: ToolActivation): void;
    render(container: HTMLElement): void;
}
export declare abstract class AnnotationPropertyEntryTool extends LayerTool<AnnotationUserLayer> {
    propertyIdentifier: string;
    constructor(propertyIdentifier: string, layer: AnnotationUserLayer);
    protected get property(): AnnotationPropertySpec | undefined;
    protected get currentValue(): number | undefined;
    protected abstract readonly modeVerb: string;
    protected configureValueBindings(_addBinding: EntryKeyBinder, _requestRefresh: () => void, _activation: ToolActivation<this>): void;
    protected renderValue(_valueContainer: HTMLElement, _entrySlot: HTMLElement): void;
    protected onAnnotationChanged(): void;
    protected navHintSuffix(): string;
    protected bindingConfigurationKey(): string;
    protected navKeyInfo(): {
        prevKey: string | undefined;
        nextKey: string | undefined;
        hint: string;
    };
    activate(activation: ToolActivation<this>): void;
    get description(): string;
    protected appendChip(container: HTMLElement, key: string, label: string, active: boolean): void;
}
export declare class EnumPropertyEntryTool extends AnnotationPropertyEntryTool {
    protected readonly modeVerb = "Set";
    protected bindingConfigurationKey(): string;
    private readonly entry;
    private get numericProperty();
    private get useNumberEntry();
    protected configureValueBindings(addBinding: EntryKeyBinder, requestRefresh: () => void, activation: ToolActivation<this>): void;
    protected renderValue(valueContainer: HTMLElement, entrySlot: HTMLElement): void;
    protected onAnnotationChanged(): void;
    protected navHintSuffix(): "" | "  ·  Enter to set · Esc to exit";
    toJSON(): import("#src/layer/annotation/tool_state.js").AnnotationPropertyToolJson;
}
export declare class ToggleBoolPropertyTool extends LayerTool<AnnotationUserLayer> {
    propertyIdentifier: string;
    constructor(propertyIdentifier: string, layer: AnnotationUserLayer);
    activate(activation: ToolActivation<this>): void;
    toJSON(): import("#src/layer/annotation/tool_state.js").AnnotationPropertyToolJson;
    get description(): string;
}
export declare class NumberPropertyEntryTool extends AnnotationPropertyEntryTool {
    protected readonly modeVerb = "Set";
    private get isFloat();
    private get dataType();
    private range;
    private readonly entry;
    protected configureValueBindings(addBinding: EntryKeyBinder, requestRefresh: () => void, activation: ToolActivation<this>): void;
    protected renderValue(valueContainer: HTMLElement, entrySlot: HTMLElement): void;
    protected onAnnotationChanged(): void;
    protected navHintSuffix(): string;
    toJSON(): import("#src/layer/annotation/tool_state.js").AnnotationPropertyToolJson;
}
export {};
