/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
export declare class TrackableBoolean implements Trackable {
    private value_;
    defaultValue: boolean;
    get value(): boolean;
    set value(newValue: boolean);
    toggle(): void;
    changed: NullarySignal;
    constructor(value_: boolean, defaultValue?: boolean);
    toJSON(): boolean | undefined;
    restoreState(x: any): void;
    reset(): void;
}
/**
 * @param model: A watchable value that is used to track the checkbox state.
 * @param options.enabledTitle: Optional title to show when the checkbox is checked.
 * @param options.disabledTitle: Optional title to show when the checkbox is unchecked.
 */
export declare class TrackableBooleanCheckbox extends RefCounted {
    model: WatchableValueInterface<boolean>;
    element: HTMLInputElement;
    constructor(model: WatchableValueInterface<boolean>, options?: {
        enabledTitle?: string;
        disabledTitle?: string;
    });
    disposed(): void;
}
export declare class ElementVisibilityFromTrackableBoolean extends RefCounted {
    model: WatchableValueInterface<boolean>;
    element: HTMLElement;
    private initialDisplay;
    constructor(model: WatchableValueInterface<boolean>, element: HTMLElement);
    updateVisibility(): void;
}
