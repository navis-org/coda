/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { LayerChunkProgressInfo } from "#src/chunk_manager/base.js";
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import { Chunk, ChunkSource } from "#src/chunk_manager/frontend.js";
import type { LayerView, VisibleLayerInfo } from "#src/layer/index.js";
import type { PerspectivePanel } from "#src/perspective_view/panel.js";
import type { PerspectiveViewRenderContext } from "#src/perspective_view/render_layer.js";
import { PerspectiveViewRenderLayer } from "#src/perspective_view/render_layer.js";
import type { RenderLayer, ThreeDimensionalRenderLayerAttachmentState } from "#src/renderlayer.js";
import type { SegmentationDisplayState3D } from "#src/segmentation_display_state/frontend.js";
import type { VertexAttributeInfo } from "#src/skeleton/base.js";
import type { SliceViewPanel } from "#src/sliceview/panel.js";
import type { SliceViewPanelRenderContext } from "#src/sliceview/renderlayer.js";
import { SliceViewPanelRenderLayer } from "#src/sliceview/renderlayer.js";
import { TrackableBoolean } from "#src/trackable_boolean.js";
import { TrackableValue, WatchableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import type { vec3 } from "#src/util/geom.js";
import { mat4 } from "#src/util/geom.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import { TrackableEnum } from "#src/util/trackable_enum.js";
import { GLBuffer } from "#src/webgl/buffer.js";
import type { GL } from "#src/webgl/context.js";
import type { WatchableShaderError } from "#src/webgl/dynamic_shader.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
import type { ShaderControlsBuilderState } from "#src/webgl/shader_ui_controls.js";
import { ShaderControlState } from "#src/webgl/shader_ui_controls.js";
import { TextureFormat } from "#src/webgl/texture_access.js";
interface VertexAttributeRenderInfo extends VertexAttributeInfo {
    name: string;
    webglDataType: number;
    glslDataType: string;
}
declare class RenderHelper extends RefCounted {
    base: SkeletonLayer;
    targetIsSliceView: boolean;
    private textureAccessHelper;
    private vertexIdHelper;
    get vertexAttributes(): VertexAttributeRenderInfo[];
    defineCommonShader(builder: ShaderBuilder): void;
    edgeShaderGetter: import("#src/webgl/dynamic_shader.js").ParameterizedEmitterDependentShaderGetter<ShaderControlsBuilderState, undefined>;
    nodeShaderGetter: import("#src/webgl/dynamic_shader.js").ParameterizedEmitterDependentShaderGetter<ShaderControlsBuilderState, undefined>;
    get gl(): GL;
    constructor(base: SkeletonLayer, targetIsSliceView: boolean);
    defineAttributeAccess(builder: ShaderBuilder): void;
    getCrossSectionFadeFactor(): "(clamp(1.0 - 2.0 * abs(0.5 - gl_FragCoord.z), 0.0, 1.0))" | "(1.0)";
    beginLayer(gl: GL, shader: ShaderProgram, renderContext: SliceViewPanelRenderContext | PerspectiveViewRenderContext, modelMatrix: mat4): void;
    setColor(gl: GL, shader: ShaderProgram, color: vec3): void;
    setPickID(gl: GL, shader: ShaderProgram, pickID: number): void;
    drawSkeleton(gl: GL, edgeShader: ShaderProgram, nodeShader: ShaderProgram, skeletonChunk: SkeletonChunk, projectionParameters: {
        width: number;
        height: number;
    }): void;
    endLayer(gl: GL, shader: ShaderProgram): void;
}
export declare enum SkeletonRenderMode {
    LINES = 0,
    LINES_AND_POINTS = 1
}
export declare class TrackableSkeletonRenderMode extends TrackableEnum<SkeletonRenderMode> {
    constructor(value: SkeletonRenderMode, defaultValue?: SkeletonRenderMode);
}
export declare class TrackableSkeletonLineWidth extends TrackableValue<number> {
    constructor(value: number, defaultValue?: number);
}
export interface ViewSpecificSkeletonRenderingOptions {
    mode: TrackableSkeletonRenderMode;
    lineWidth: TrackableSkeletonLineWidth;
}
export declare class SkeletonRenderingOptions implements Trackable {
    private compound;
    get changed(): NullarySignal;
    shader: TrackableValue<string>;
    shaderControlState: ShaderControlState;
    hideInactiveShaderControls: TrackableBoolean;
    params2d: ViewSpecificSkeletonRenderingOptions;
    params3d: ViewSpecificSkeletonRenderingOptions;
    constructor();
    reset(): void;
    restoreState(obj: any): void;
    toJSON(): any;
}
export interface SkeletonLayerDisplayState extends SegmentationDisplayState3D {
    shaderError: WatchableShaderError;
    skeletonRenderingOptions: SkeletonRenderingOptions;
}
export declare class SkeletonLayer extends RefCounted {
    chunkManager: ChunkManager;
    source: SkeletonSource;
    displayState: SkeletonLayerDisplayState;
    layerChunkProgressInfo: LayerChunkProgressInfo;
    redrawNeeded: NullarySignal;
    private sharedObject;
    vertexAttributes: VertexAttributeRenderInfo[];
    fallbackShaderParameters: WatchableValue<ShaderControlsBuilderState>;
    get visibility(): import("../visibility_priority/frontend").VisibilityPriorityAggregator;
    constructor(chunkManager: ChunkManager, source: SkeletonSource, displayState: SkeletonLayerDisplayState);
    get gl(): GL;
    draw(renderContext: SliceViewPanelRenderContext | PerspectiveViewRenderContext, layer: RenderLayer, renderHelper: RenderHelper, renderOptions: ViewSpecificSkeletonRenderingOptions, attachment: VisibleLayerInfo<LayerView, ThreeDimensionalRenderLayerAttachmentState>): void;
    isReady(): boolean;
}
export declare class PerspectiveViewSkeletonLayer extends PerspectiveViewRenderLayer {
    base: SkeletonLayer;
    private renderHelper;
    private renderOptions;
    constructor(base: SkeletonLayer);
    get gl(): GL;
    get isTransparent(): boolean;
    draw(renderContext: PerspectiveViewRenderContext, attachment: VisibleLayerInfo<PerspectivePanel, ThreeDimensionalRenderLayerAttachmentState>): void;
    isReady(): boolean;
}
export declare class SliceViewPanelSkeletonLayer extends SliceViewPanelRenderLayer {
    base: SkeletonLayer;
    private renderHelper;
    private renderOptions;
    constructor(base: SkeletonLayer);
    get gl(): GL;
    draw(renderContext: SliceViewPanelRenderContext, attachment: VisibleLayerInfo<SliceViewPanel, ThreeDimensionalRenderLayerAttachmentState>): void;
    isReady(): boolean;
}
export declare class SkeletonChunk extends Chunk {
    source: SkeletonSource;
    vertexAttributes: Uint8Array;
    indices: Uint32Array;
    indexBuffer: GLBuffer;
    numIndices: number;
    numVertices: number;
    vertexAttributeOffsets: Uint32Array;
    vertexAttributeTextures: (WebGLTexture | null)[];
    constructor(source: SkeletonSource, x: any);
    copyToGPU(gl: GL): void;
    freeGPUMemory(gl: GL): void;
}
export type SkeletonSourceOptions = object;
export declare class SkeletonSource extends ChunkSource {
    private attributeTextureFormats_?;
    get attributeTextureFormats(): TextureFormat[];
    chunks: Map<string, SkeletonChunk>;
    getChunk(x: any): SkeletonChunk;
    get vertexAttributes(): Map<string, VertexAttributeInfo>;
}
export {};
