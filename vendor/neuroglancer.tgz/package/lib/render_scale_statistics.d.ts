/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { TrackableValue } from "#src/trackable_value.js";
import { NullarySignal } from "#src/util/signal.js";
import { VisibilityPriorityAggregator } from "#src/visibility_priority/frontend.js";
export declare const numRenderScaleHistogramBins = 40;
export declare const renderScaleHistogramBinSize = 0.5;
export declare const renderScaleHistogramOrigin = -4;
export declare function getRenderScaleHistogramOffset(renderScale: number, origin?: number, binSize?: number): number;
export declare function getRenderScaleFromHistogramOffset(offset: number, origin?: number, binSize?: number): number;
export declare function trackableRenderScaleTarget(initialValue: number, scaleOrigin?: number, scaleMax?: number): TrackableValue<number>;
export declare class RenderScaleHistogram {
    readonly logScaleOrigin: number;
    readonly numBins: number;
    readonly binSize: number;
    visibility: VisibilityPriorityAggregator;
    changed: NullarySignal;
    constructor(logScaleOrigin?: number, numBins?: number, binSize?: number);
    /**
     * Frame number corresponding to the current histogram.
     */
    frameNumber: number;
    /**
     * Maps from spatial scale (nanometers) to histogram row index in the range
     * `[0, spatialScales.size)`.
     */
    spatialScales: Map<number, number>;
    /**
     * Current number of rows allocated for the histogram.
     */
    numHistogramRows: number;
    /**
     * Histogram value array, stores both present and not-present counts.
     */
    value: Uint32Array;
    /**
     * Number of chunks that are indication only (not present in the data).
     */
    fakeChunkCount: number;
    begin(frameNumber: number): void;
    /**
     * Adds a count to the histogram.
     *
     * @param spatialScale Spatial resolution of data in nanometers.
     * @param renderScale Rendered scale of data in screen pixels.
     * @param presentCount Number of present chunks.
     * @param notPresentCount Number of desired but not-present chunks.
     * @param renderOnly If true, indicates that the added bar is for display only, and is not linked
     *     to actual chunk loading stats. Defaults to false.
     */
    add(spatialScale: number, renderScale: number, presentCount: number, notPresentCount: number, renderOnly?: boolean): void;
}
