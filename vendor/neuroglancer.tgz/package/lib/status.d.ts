/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/status.css";
export declare const statusMessages: Set<StatusMessage>;
export declare const DEFAULT_STATUS_DELAY = 200;
export type Delay = boolean | number;
export declare function getStatusMessageContainers(): HTMLElement[];
export declare class StatusMessage {
    element: HTMLElement;
    private modalElementWrapper;
    private timer;
    private visibility;
    private preventFocusChangeOnMouseDown;
    private handleMouseDown;
    constructor(delay?: Delay, modal?: boolean, insertAtBottom?: boolean);
    [Symbol.dispose](): void;
    dispose(): void;
    setText(text: string, makeVisible?: boolean): void;
    setHTML(text: string, makeVisible?: boolean): void;
    setPreventFocusChangeOnMouseDown(value: boolean): void;
    setModal(value: boolean, insertAtBottom?: boolean): void;
    private applyVisibility;
    setVisible(value: boolean): void;
    static forPromise<T>(promise: Promise<T>, options: {
        initialMessage: string;
        delay?: Delay;
        errorPrefix: string;
    }): Promise<T>;
    setErrorMessage(message: string): void;
    static showMessage(message: string): StatusMessage;
    static showTemporaryMessage(message: string, closeAfter?: number): StatusMessage;
}
