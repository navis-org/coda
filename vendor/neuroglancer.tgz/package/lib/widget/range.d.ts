/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/range.css";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
export interface RangeWidgetOptions {
    min?: number;
    max?: number;
    step?: number;
}
export declare class RangeWidget extends RefCounted {
    value: WatchableValueInterface<number>;
    element: HTMLLabelElement;
    inputElement: HTMLInputElement;
    numericInputElement: HTMLInputElement;
    constructor(value: WatchableValueInterface<number>, { min, max, step }?: RangeWidgetOptions);
    private inputValueChanged;
    adjustViaWheel(element: HTMLInputElement, event: WheelEvent): void;
    disposed(): void;
}
