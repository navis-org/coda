/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpaceCombiner } from "#src/coordinate_transform.js";
import type { UserLayer } from "#src/layer/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { DataType } from "#src/util/data_type.js";
import type { HistogramSpecifications } from "#src/webgl/empirical_cdf.js";
import type { ImageInvlerpParameters } from "#src/webgl/shader_ui_controls.js";
import { InvlerpWidget } from "#src/widget/invlerp.js";
import type { LayerControlFactory } from "#src/widget/layer_control.js";
import type { LegendShaderOptions } from "#src/widget/shader_controls.js";
export declare function channelInvlerpLayerControl<LayerType extends UserLayer>(getter: (layer: LayerType) => {
    watchableValue: WatchableValueInterface<ImageInvlerpParameters>;
    dataType: DataType;
    defaultChannel: number[];
    channelCoordinateSpaceCombiner: CoordinateSpaceCombiner | undefined;
    histogramSpecifications: HistogramSpecifications;
    histogramIndex: number;
    legendShaderOptions: LegendShaderOptions | undefined;
}): LayerControlFactory<LayerType, InvlerpWidget>;
