/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/multiline_autocomplete.css";
import type { BasicCompletionResult, Completion, CompletionWithDescription } from "#src/util/completion.js";
import { RefCounted } from "#src/util/disposable.js";
import type { ProgressListener } from "#src/util/progress_listener.js";
import { Signal } from "#src/util/signal.js";
export type { Completion, CompletionWithDescription, } from "#src/util/completion.js";
export interface CompletionResult extends BasicCompletionResult {
    showSingleResult?: boolean;
    selectSingleResult?: boolean;
    makeElement?: (this: CompletionResult, completion: Completion) => HTMLElement;
}
export declare function makeDefaultCompletionElement(completion: Completion): HTMLDivElement;
export interface SyntaxHighlighter {
    splitPattern: RegExp;
    getSeparatorNode: (text: string) => HTMLElement;
}
export declare function makeCompletionElementWithDescription(completion: CompletionWithDescription): HTMLDivElement;
export interface CompletionRequest {
    value: string;
    selectionRange?: {
        begin: number;
        end: number;
    } | undefined;
}
export type Completer = (request: CompletionRequest, signal: AbortSignal, progressListener: ProgressListener) => Promise<CompletionResult> | null;
export declare class AutocompleteTextInput extends RefCounted {
    element: HTMLDivElement;
    inputElement: HTMLSpanElement;
    hintElement: HTMLSpanElement;
    private completionsVirtualList;
    onCommit: Signal<(value: string, explicit: boolean) => void>;
    onInput: Signal<(value: string) => void>;
    private prevInputValue;
    private completionsVisible;
    private activeCompletionPromise;
    private activeCompletionAbortController;
    private activeCompletionProgressListener;
    private completionErrorElement;
    private hasFocus;
    private completionResult;
    private dropdownContentsStale;
    private hasResultForDropdown;
    private commonPrefix;
    private completionDisabled;
    disableCompletion(): void;
    get placeholder(): string;
    set placeholder(value: string);
    private getSelectionRange;
    setValueAndSelection(value: string, selection?: {
        begin: number;
        end: number;
    } | undefined): void;
    /**
     * Index of the active completion.  The active completion is displayed as the hint text and is
     * highlighted in the dropdown.
     */
    private activeIndex;
    private dropdownStyleStale;
    private scheduleUpdateCompletions;
    completer: Completer;
    private resizeHandler;
    private resizeObserver;
    private syntaxHighlighter;
    constructor(options: {
        completer: Completer;
        syntaxHighlighter?: SyntaxHighlighter;
        delay?: number;
    });
    private removeProgressListener;
    private makeCompletionProgressListener;
    private showCompletionError;
    private shouldAttemptCompletion;
    hideCompletions(): void;
    private debouncedUpdateHintState;
    private updateHintState;
    private handleDropdownClick;
    cycleActiveCompletion(delta: number): void;
    private shouldShowDropdown;
    private updateDropdownStyle;
    private updateDropdown;
    private setCompletions;
    setHintValue(hintValue: string): void;
    /**
     * This sets the active completion, which causes it to be highlighted and displayed as the hint.
     * Additionally, if the user hits tab then it is chosen.
     */
    private setActiveIndex;
    private getCompletedValueByIndex;
    private getCompletedValue;
    private moveCaretToBeginningOfInput;
    private moveCaretToEndOfInput;
    selectActiveCompletion(allowPrefix: boolean): boolean;
    selectCompletion(index: number): void;
    /**
     * Called when user presses escape.  Does nothing here, but may be overridden in a subclass.
     */
    cancel(): boolean;
    private cancelActiveCompletion;
    private clearCompletions;
    get value(): string;
    set value(value: string);
    disposed(): void;
}
