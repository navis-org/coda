/**
 * @license
 * Copyright 2017-2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/position_widget.css";
import type { CoordinateSpace, CoordinateSpaceCombiner, DimensionId } from "#src/coordinate_transform.js";
import type { MouseSelectionState, UserLayer } from "#src/layer/index.js";
import type { LayerGroupViewer } from "#src/layer_group_viewer.js";
import type { CoordinateSpacePlaybackVelocity, Position } from "#src/navigation_state.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { LocalToolBinder } from "#src/ui/tool.js";
import type { Borrowed } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { vec3 } from "#src/util/geom.js";
import type { Viewer } from "#src/viewer.js";
export declare const positionDragType = "neuroglancer-position";
declare class DimensionWidget {
    coordinateSpace: CoordinateSpace;
    id: DimensionId;
    container: HTMLDivElement;
    nameContainer: HTMLSpanElement;
    nameElement: HTMLInputElement;
    scaleContainer: HTMLSpanElement;
    scaleElement: HTMLInputElement;
    coordinate: HTMLInputElement;
    coordinateLabel: HTMLSpanElement;
    playButton: HTMLDivElement;
    pauseButton: HTMLDivElement;
    coordinateLabelWidth: number;
    maxPositionWidth: number;
    maxPositionWidthSeen: number;
    dropdownOwner: RefCounted | undefined;
    modified: boolean;
    draggingPosition: boolean;
    hasFocus: boolean;
    dimensionIndex: number;
    constructor(coordinateSpace: CoordinateSpace, id: DimensionId, initialDimensionIndex: number, options: {
        allowFocus: boolean;
        showPlayback: boolean;
    });
}
export declare function copyPositionToClipboard(position: Position): void;
export declare class PositionWidget extends RefCounted {
    position: Borrowed<Position>;
    combiner: CoordinateSpaceCombiner;
    element: HTMLDivElement;
    private dimensionContainer;
    private coordinateSpace;
    private velocity;
    private singleDimensionId;
    private getToolBinder;
    private allowFocus;
    private showPlayback;
    private showDropdown;
    private showAllPlotBounds;
    private dimensionWidgets;
    private dimensionWidgetList;
    getDimensionIndex(id: DimensionId): number;
    private openRegularDropdown;
    private openCoordinateArrayDropdown;
    private openDropdown;
    private widgetWithOpenDropdown;
    private closeDropdown;
    private pasteString;
    private dragSource;
    private reorderDimensionTo;
    private updateDropdownVisibility;
    private newDimension;
    private forceUpdateDimensions;
    private updateDimensions;
    private selectAdjacentField;
    private selectAdjacentCoordinate;
    private handleLeftRightMovement;
    private updateNameValidity;
    private updateScaleValidity;
    constructor(position: Borrowed<Position>, combiner: CoordinateSpaceCombiner, { copyButton, velocity, singleDimensionId, getToolBinder, allowFocus, showPlayback, showDropdown, showAllPlotBounds, }?: {
        copyButton?: boolean;
        velocity?: CoordinateSpacePlaybackVelocity;
        singleDimensionId?: DimensionId;
        getToolBinder?: (() => LocalToolBinder | undefined) | undefined;
        allowFocus?: boolean;
        showPlayback?: boolean;
        showDropdown?: boolean;
        showAllPlotBounds?: WatchableValueInterface<boolean>;
    });
    adjustDimensionPosition(id: DimensionId, adjustment: number): void;
    adjustDimensionVelocity(widget: DimensionWidget, factor: number): void;
    private updatePosition;
    private updateNames;
    private updateScales;
    private getPositionText;
    private updateView;
    disposed(): void;
}
export declare class MousePositionWidget extends RefCounted {
    element: HTMLElement;
    mouseState: MouseSelectionState;
    coordinateSpace: WatchableValueInterface<CoordinateSpace | undefined>;
    tempPosition: vec3;
    constructor(element: HTMLElement, mouseState: MouseSelectionState, coordinateSpace: WatchableValueInterface<CoordinateSpace | undefined>);
    updateView(): void;
    disposed(): void;
}
export declare function registerDimensionToolForViewer(contextType: typeof Viewer): void;
export declare function registerDimensionToolForUserLayer(contextType: typeof UserLayer): void;
export declare function registerDimensionToolForLayerGroupViewer(contextType: typeof LayerGroupViewer): void;
export {};
