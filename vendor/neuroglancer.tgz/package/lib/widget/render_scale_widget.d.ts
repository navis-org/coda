/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/render_scale_widget.css";
import type { UserLayer } from "#src/layer/index.js";
import type { RenderScaleHistogram } from "#src/render_scale_statistics.js";
import type { TrackableValueInterface } from "#src/trackable_value.js";
import { WatchableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import type { LayerControlFactory } from "#src/widget/layer_control.js";
export interface RenderScaleWidgetOptions {
    histogram: RenderScaleHistogram;
    target: TrackableValueInterface<number>;
}
export declare class RenderScaleWidget extends RefCounted {
    histogram: RenderScaleHistogram;
    target: TrackableValueInterface<number>;
    label: HTMLDivElement;
    element: HTMLDivElement;
    canvas: HTMLCanvasElement;
    legend: HTMLDivElement;
    legendRenderScale: HTMLDivElement;
    legendSpatialScale: HTMLDivElement;
    legendChunks: HTMLDivElement;
    protected unitOfTarget: string;
    private ctx;
    hoverTarget: WatchableValue<[number, number] | undefined>;
    private throttledUpdateView;
    private debouncedUpdateView;
    adjustViaWheel(event: WheelEvent): void;
    constructor(histogram: RenderScaleHistogram, target: TrackableValueInterface<number>);
    getWheelMoveValue(event: WheelEvent): number;
    reset(): void;
    updateView(): void;
}
export declare class VolumeRenderingRenderScaleWidget extends RenderScaleWidget {
    protected unitOfTarget: string;
    getWheelMoveValue(event: WheelEvent): number;
}
export declare function renderScaleLayerControl<LayerType extends UserLayer, WidgetType extends RenderScaleWidget>(getter: (layer: LayerType) => RenderScaleWidgetOptions, widgetClass?: new (histogram: RenderScaleHistogram, target: TrackableValueInterface<number>) => WidgetType): LayerControlFactory<LayerType, RenderScaleWidget>;
