/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import CodeMirror from "codemirror";
import "codemirror/addon/lint/lint.js";
import "#src/widget/shader_code_widget.css";
import "codemirror/lib/codemirror.css";
import "codemirror/addon/lint/lint.css";
import type { UserLayer } from "#src/layer/index.js";
import type { Overlay } from "#src/overlay.js";
import { type TrackableBoolean } from "#src/trackable_boolean.js";
import type { WatchableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import type { WatchableShaderError } from "#src/webgl/dynamic_shader.js";
import type { ShaderControlState } from "#src/webgl/shader_ui_controls.js";
interface ShaderCodeState {
    shaderError: WatchableShaderError;
    shaderControlState?: ShaderControlState;
    fragmentMain: WatchableValue<string>;
    sourceStringNumber?: number;
}
export declare class ShaderCodeWidget extends RefCounted {
    state: ShaderCodeState;
    textEditor: CodeMirror.Editor;
    get element(): HTMLElement;
    private changingValue;
    private debouncedValueUpdater;
    constructor(state: ShaderCodeState);
    updateErrorState(): void;
    setValidState(valid?: boolean): void;
    disposed(): void;
}
type UserLayerWithCodeEditor = UserLayer & {
    codeVisible: TrackableBoolean;
};
type ShaderCodeOverlayConstructor<T extends Overlay> = new (layer: UserLayerWithCodeEditor) => T;
export declare function makeShaderCodeWidgetTopRow<T extends Overlay>(layer: UserLayerWithCodeEditor, codeWidget: ShaderCodeWidget, ShaderCodeOverlay: ShaderCodeOverlayConstructor<T>, help: {
    title: string;
    href: string;
}, className: string): HTMLDivElement;
export {};
