/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Coordinate space transform editor widget.
 */
import "#src/widget/coordinate_transform.css";
import type { CoordinateSpaceCombiner, WatchableCoordinateSpaceTransform } from "#src/coordinate_transform.js";
import { RefCounted } from "#src/util/disposable.js";
export declare class CoordinateSpaceTransformWidget extends RefCounted {
    transform: WatchableCoordinateSpaceTransform;
    localCombiner: CoordinateSpaceCombiner;
    globalCombiner: CoordinateSpaceCombiner;
    element: HTMLDivElement;
    private coefficientContainer;
    private translationContainer;
    private outputNameContainer;
    private outputScaleContainer;
    private inputNameContainer;
    private inputScaleContainer;
    private inputLowerBoundsContainer;
    private inputUpperBoundsContainer;
    private coefficientElements;
    private inputNameElements;
    private outputNameElements;
    private outputScaleElements;
    private outputScaleSuggestionElements;
    private inputScaleSuggestionElements;
    private inputScaleElements;
    private inputBoundsElements;
    private outputBoundsElements;
    private addSourceDimensionIcon;
    private addOutputDimensionIcon;
    private addOutputDimensionCell;
    private addOutputDimensionInput;
    private inputScaleModified;
    private outputScaleModified;
    private curSourceRank;
    private curRank;
    private curTransform;
    private addingSourceDimension;
    private resetToIdentityButton;
    private resetToDefaultButton;
    constructor(transform: WatchableCoordinateSpaceTransform, localCombiner: CoordinateSpaceCombiner, globalCombiner: CoordinateSpaceCombiner);
    private updateWillBeDeletedAttributes;
    private updateAddOutputDimensionCellStyle;
    private updateOutputNameValidity;
    private updateScaleValidity;
    private updateCoefficientValidity;
    private getElementGridPosition;
    private getElementByGridPosition;
    private dimensionRefCount;
    private updateModelInputScales;
    private updateModelOutputScales;
    private updateModelOutputNames;
    private updateModelTransform;
    private updateViewOutputNames;
    private updateViewTransformCoefficients;
    private ensureViewRankUpdated;
    private updateViewInputScales;
    private updateViewOutputScales;
    private updateResetButtonVisibility;
    updateView(): void;
    disposed(): void;
}
