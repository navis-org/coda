/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Tabbed view widget.
 */
import "#src/widget/tab_view.css";
import type { WatchableValueChangeInterface, WatchableValueInterface } from "#src/trackable_value.js";
import type { Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal, Signal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
export declare class Tab extends RefCounted {
    visibility: WatchableVisibilityPriority;
    element: HTMLDivElement;
    get visible(): boolean;
    constructor(visibility?: WatchableVisibilityPriority);
    disposed(): void;
}
export declare class OptionSpecification<T> extends RefCounted implements Trackable {
    changed: NullarySignal;
    options: Map<string, T>;
    optionsChanged: NullarySignal;
    private selectedValue;
    private defaultValue;
    get value(): string | undefined;
    set default(value: string | undefined);
    get default(): string | undefined;
    set value(value: string | undefined);
    get validValue(): string | undefined;
    add(id: string, value: T): void;
    remove(id: string): void;
    toJSON(): string | undefined;
    reset(): void;
    ready_: boolean;
    /**
     * When `ready` is `false`, the selected `value` may be set to an unknown option.
     */
    get ready(): boolean;
    set ready(value: boolean);
    restoreState(obj: any): void;
}
export declare class StackView<TabId, TabType extends Tab = Tab> extends RefCounted {
    getter: (id: TabId) => Owned<TabType>;
    selected: WatchableValueInterface<TabId | undefined>;
    visibility: WatchableVisibilityPriority;
    invalidateByDefault: boolean;
    element: HTMLDivElement;
    tabs: Map<TabId, TabType>;
    tabVisibilityChanged: Signal<(id: TabId, visible: boolean) => void>;
    private displayedTab;
    get visible(): boolean;
    private debouncedUpdateSelectedTab;
    flush(): void;
    constructor(getter: (id: TabId) => Owned<TabType>, selected: WatchableValueInterface<TabId | undefined>, visibility?: WatchableVisibilityPriority, invalidateByDefault?: boolean);
    invalidate(id: TabId): void;
    private hideTab;
    private showTab;
    private updateSelectedTab;
    invalidateAll(predicate?: ((id: TabId) => boolean) | undefined): void;
    disposed(): void;
}
export declare class TabSpecification extends OptionSpecification<{
    label: string;
    order?: number;
    getter: () => Owned<Tab>;
    hidden?: WatchableValueInterface<boolean>;
}> {
}
export interface TabViewOptions {
    makeTab: (id: string) => Tab;
    selectedTab: WatchableValueInterface<string | undefined>;
    tabs: WatchableValueChangeInterface<{
        id: string;
        label: string;
        hidden: boolean;
    }[]>;
    handleTabElement?: (id: string, element: HTMLElement) => void;
}
export declare class TabView extends RefCounted {
    visibility: WatchableVisibilityPriority;
    element: HTMLDivElement;
    tabBar: HTMLDivElement;
    tabs: WatchableValueChangeInterface<{
        id: string;
        label: string;
        hidden: boolean;
    }[]>;
    selectedTab: WatchableValueInterface<string | undefined>;
    private handleTabElement;
    private stack;
    private tabLabels;
    private tabsGeneration;
    get visible(): boolean;
    private debouncedUpdateView;
    constructor(options: TabViewOptions, visibility?: WatchableVisibilityPriority);
    private updateTabLabelStyles;
    private updateTabs;
    private destroyTabs;
    private makeTabs;
    disposed(): void;
}
