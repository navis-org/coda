/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Facility for drawing a scale bar to indicate pixel size in physical length
 * units.
 *
 * The physical length with which the scale bar is labeled will be of the form:
 *
 *   significand * 10^exponent
 *
 * Any exponent may be used, but the significand in the range [1, 10] will be
 * equal to one of a
 * discrete set of allowed significand values, in order to ensure that the scale
 * bar is easy to
 * understand.
 */
import type { RenderViewport } from "#src/display_context.js";
import type { DisplayDimensionRenderInfo, RelativeDisplayScales } from "#src/navigation_state.js";
import { TrackableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
export interface LengthUnit {
    unit: string;
    lengthInNanometers: number;
}
export declare const ALLOWED_UNITS: LengthUnit[];
export declare function pickLengthUnit(lengthInNanometers: number): LengthUnit;
export declare function pickVolumeUnit(volumeInCubicNanometers: number): LengthUnit;
export declare class ScaleBarDimensions {
    /**
     * Allowed significand values.  1 is not included, but is always considered
     * part of the set.
     */
    allowedSignificands: number[];
    /**
     * The target length in pixels.  The closest
     */
    targetLengthInPixels: number;
    /**
     * Pixel size in base physical units.
     */
    physicalSizePerPixel: number;
    /**
     * Base physical unit, e.g. "m" (for meters) or "s" (for seconds).
     */
    physicalBaseUnit: string;
    /**
     * Length that scale bar should be drawn, in pixels.
     */
    lengthInPixels: number;
    /**
     * Physical length with which to label the scale bar.
     */
    physicalLength: number;
    physicalUnit: string;
    prevPhysicalSizePerPixel: number;
    prevTargetLengthInPixels: number;
    prevPhysicalUnit: string;
    /**
     * Updates physicalLength, physicalUnit, and lengthInPixels to be the optimal values corresponding
     * to targetLengthInPixels and physicalSizePerPixel.
     *
     * @returns true if the scale bar has changed, false if it is unchanged.
     */
    update(): boolean;
}
export declare class ScaleBarTexture extends RefCounted {
    gl: GL;
    dimensions: ScaleBarDimensions;
    texture: WebGLTexture | null;
    width: number;
    height: number;
    label: string;
    factor: number;
    private priorOptions;
    private prevLabel;
    constructor(gl: GL, dimensions?: ScaleBarDimensions);
    update(options: ScaleBarTextureOptions): void;
    disposed(): void;
}
export declare class MultipleScaleBarTextures extends RefCounted {
    gl: GL;
    private scaleBarCopyHelper;
    private scaleBars;
    constructor(gl: GL);
    draw(viewport: RenderViewport, displayDimensionRenderInfo: DisplayDimensionRenderInfo, relativeDisplayScales: RelativeDisplayScales, effectiveZoom: number, options: ScaleBarOptions): void;
}
export interface ScaleBarTextureOptions {
    textHeightInPixels: number;
    barTopMarginInPixels: number;
    fontName: string;
    barHeightInPixels: number;
    paddingInPixels: number;
    scaleFactor: number;
}
export interface ScaleBarOptions extends ScaleBarTextureOptions {
    maxWidthInPixels: number;
    maxWidthFraction: number;
    leftPixelOffset: number;
    bottomPixelOffset: number;
    marginPixelsBetweenScaleBars: number;
}
export declare const defaultScaleBarTextureOptions: ScaleBarTextureOptions;
export declare const defaultScaleBarOptions: ScaleBarOptions;
export declare class TrackableScaleBarOptions extends TrackableValue<ScaleBarOptions> {
    constructor();
}
