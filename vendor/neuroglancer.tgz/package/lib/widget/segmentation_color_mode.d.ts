/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/segmentation_color_mode.css";
import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import { vec3 } from "#src/util/geom.js";
import type { ColorWidget } from "#src/widget/color.js";
import type { LayerControlFactory } from "#src/widget/layer_control.js";
export declare function colorSeedLayerControl(): LayerControlFactory<SegmentationUserLayer>;
export declare function fixedColorLayerControl(): LayerControlFactory<SegmentationUserLayer, ColorWidget<vec3 | undefined>>;
