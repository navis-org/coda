/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/channel_dimensions_widget.css";
import type { CoordinateSpace, CoordinateSpaceCombiner } from "#src/coordinate_transform.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
export declare class ChannelDimensionsWidget extends RefCounted {
    combiner: CoordinateSpaceCombiner;
    element: HTMLDivElement;
    private dimensionWidgets;
    private curCoordinateSpace;
    private dragSource;
    private reorderDimensionTo;
    coordinateSpace: WatchableValueInterface<CoordinateSpace>;
    constructor(combiner: CoordinateSpaceCombiner);
    private makeNewDimensionWidget;
    private selectAdjacentField;
    private updateNames;
    private updateNameValidity;
    private forceUpdateView;
    private updateView;
}
