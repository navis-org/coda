/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/layer_control.css";
import type { DisplayContext } from "#src/display_context.js";
import type { UserLayer, UserLayerConstructor } from "#src/layer/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { ToolActivation } from "#src/ui/tool.js";
import { LayerTool } from "#src/ui/tool.js";
import type { RefCounted } from "#src/util/disposable.js";
import { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
export interface LayerControlLabelOptions<LayerType extends UserLayer = UserLayer> {
    label: string;
    title?: string;
    toolDescription?: string;
    toolJson: any;
    isValid?: (layer: LayerType) => WatchableValueInterface<boolean>;
}
export interface LayerControlFactory<LayerType extends UserLayer, ControlType = unknown> {
    makeControl: (layer: LayerType, context: RefCounted, options: {
        labelContainer: HTMLElement;
        labelTextContainer: HTMLElement;
        display: DisplayContext;
        visibility: WatchableVisibilityPriority;
    }) => {
        control: ControlType;
        controlElement: HTMLElement;
    };
    activateTool: (activation: ToolActivation<LayerControlTool<LayerType>>, control: ControlType) => void;
}
export interface LayerControlDefinition<LayerType extends UserLayer, ControlType = unknown> extends LayerControlLabelOptions<LayerType>, LayerControlFactory<LayerType, ControlType> {
}
export declare class LayerControlTool<LayerType extends UserLayer = UserLayer> extends LayerTool<LayerType> {
    options: LayerControlDefinition<LayerType>;
    constructor(layer: LayerType, options: LayerControlDefinition<LayerType>);
    isLoading(): boolean;
    activate(activation: ToolActivation<this>): void;
    renderInPalette(context: RefCounted): HTMLLabelElement | undefined;
    get description(): string;
    toJSON(): any;
}
export declare function addLayerControlToOptionsTab<LayerType extends UserLayer>(context: RefCounted, layer: LayerType, visibility: WatchableVisibilityPriority, options: LayerControlDefinition<LayerType>): HTMLElement;
export declare function registerLayerControl<LayerType extends UserLayer>(layerType: UserLayerConstructor<LayerType>, options: LayerControlDefinition<LayerType>): void;
