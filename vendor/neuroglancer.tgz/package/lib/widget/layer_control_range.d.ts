/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { UserLayer } from "#src/layer/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { LayerControlFactory } from "#src/widget/layer_control.js";
import type { RangeWidgetOptions } from "#src/widget/range.js";
import { RangeWidget } from "#src/widget/range.js";
export declare function rangeLayerControl<LayerType extends UserLayer>(getter: (layer: LayerType) => {
    value: WatchableValueInterface<number>;
    options?: RangeWidgetOptions;
}): LayerControlFactory<LayerType, RangeWidget>;
