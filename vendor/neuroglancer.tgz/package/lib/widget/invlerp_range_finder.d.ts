/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DisplayContext } from "#src/display_context.js";
import { DataType } from "#src/util/data_type.js";
import { RefCounted } from "#src/util/disposable.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
import { NullarySignal } from "#src/util/signal.js";
import type { HistogramSpecifications } from "#src/webgl/empirical_cdf.js";
import "#src/widget/invlerp_range_finder.css";
interface AutoRangeData {
    inputPercentileBounds: [number, number];
    autoComputeInProgress: boolean;
    previouslyComputedRanges: DataTypeInterval[];
    numIterationsThisCompute: number;
    invertedInitialRange: boolean;
    finishedLerpRange: DataTypeInterval | null;
}
interface ParentInvlerpWidget {
    trackable: {
        value: {
            range?: DataTypeInterval;
            window: DataTypeInterval;
        };
    };
    dataType: DataType;
    display: DisplayContext;
    element: HTMLDivElement;
    histogramSpecifications: HistogramSpecifications;
    histogramIndex: number;
}
export declare class AutoRangeFinder extends RefCounted {
    parent: ParentInvlerpWidget;
    autoRangeData: AutoRangeData;
    finished: NullarySignal;
    element: HTMLDivElement;
    constructor(parent: ParentInvlerpWidget);
    get computedRange(): DataTypeInterval | null;
    private wasInputInverted;
    autoComputeRange(minPercentile: number, maxPercentile: number): void;
    setTrackableValue(range: DataTypeInterval, window: DataTypeInterval): void;
    maybeAutoComputeRange(): void;
    private resetAutoRangeData;
    makeAutoRangeButtons(minMaxHandler: () => void, oneTo99Handler: () => void, fiveTo95Handler: () => void): void;
}
export {};
