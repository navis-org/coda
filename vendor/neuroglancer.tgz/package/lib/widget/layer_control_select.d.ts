/**
 * @license
 * Copyright 2026 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { UserLayer } from "#src/layer/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { EnumSelectWidget } from "#src/widget/enum_widget.js";
import type { LayerControlFactory } from "#src/widget/layer_control.js";
export interface SelectLayerControlOption<T extends string | number> {
    value: T;
    label: string;
}
export declare function selectLayerControl<LayerType extends UserLayer, T extends string | number>(getter: (layer: LayerType) => {
    value: WatchableValueInterface<T>;
    options: SelectLayerControlOption<T>[];
}): LayerControlFactory<LayerType, EnumSelectWidget<number>>;
