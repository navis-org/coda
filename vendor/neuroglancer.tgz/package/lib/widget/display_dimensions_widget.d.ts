/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/display_dimensions_widget.css";
import type { RenderViewport } from "#src/display_context.js";
import type { OrientationState, TrackableDepthRange, TrackableZoomInterface, WatchableDisplayDimensionRenderInfo } from "#src/navigation_state.js";
import type { Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { NullarySignal } from "#src/util/signal.js";
interface DimensionWidget {
    container: HTMLDivElement;
    name: HTMLInputElement;
    scaleFactor: HTMLInputElement;
    scale: HTMLInputElement;
    scaleUnit: HTMLSpanElement;
    scaleFactorModified: boolean;
}
interface fovControl {
    container: HTMLDivElement;
    input: HTMLInputElement;
    unit: HTMLSpanElement;
}
export declare class DisplayDimensionsWidget extends RefCounted {
    displayDimensionRenderInfo: Owned<WatchableDisplayDimensionRenderInfo>;
    zoom: TrackableZoomInterface;
    depthRange: Owned<TrackableDepthRange>;
    orientation: Owned<OrientationState>;
    panelBoundsUpdated: NullarySignal;
    panelRenderViewport: RenderViewport;
    isSliceView: boolean;
    element: HTMLDivElement;
    dimensionGridContainer: HTMLDivElement;
    depthGridContainer: HTMLDivElement;
    fovGridContainer: HTMLDivElement;
    defaultCheckbox: HTMLInputElement;
    fovControls: fovControl[];
    dimensionElements: DimensionWidget[];
    private zoomDimension;
    private updateZoomFromScale;
    private updateZoomFromFOV;
    private updateScaleTooltip;
    private updateNameValidity;
    private scheduleUpdateView;
    private getFOVScales;
    private toggleFovInputVisibility;
    get displayDimensions(): import("#src/navigation_state.js").TrackableDisplayDimensions;
    get relativeDisplayScales(): import("#src/navigation_state.js").TrackableRelativeDisplayScales;
    get displayUnit(): "px" | "vh";
    constructor(displayDimensionRenderInfo: Owned<WatchableDisplayDimensionRenderInfo>, zoom: TrackableZoomInterface, depthRange: Owned<TrackableDepthRange>, orientation: Owned<OrientationState>, panelBoundsUpdated: NullarySignal, panelRenderViewport: RenderViewport, isSliceView: boolean);
    private updateNames;
    private updateDefault;
    private updateScaleFactors;
    private updateView;
    disposed(): void;
}
export {};
