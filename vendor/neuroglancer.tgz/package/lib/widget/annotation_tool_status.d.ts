/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/annotation_tool_status.css";
import type { SelectedLayerState } from "#src/layer/index.js";
import type { GlobalToolBinder } from "#src/ui/tool.js";
import { LegacyTool } from "#src/ui/tool.js";
import { RefCounted } from "#src/util/disposable.js";
export declare class AnnotationToolStatusWidget extends RefCounted {
    selectedLayer: SelectedLayerState;
    toolBinder: GlobalToolBinder;
    element: HTMLDivElement;
    private unbindPreviousLayer;
    get selectedTool(): LegacyTool | undefined;
    constructor(selectedLayer: SelectedLayerState, toolBinder: GlobalToolBinder);
    private selectedLayerChanged;
    disposed(): void;
    private makeWidget;
    private viewContext;
    private updateView;
}
