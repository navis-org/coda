/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/transfer_function.css";
import type { CoordinateSpaceCombiner } from "#src/coordinate_transform.js";
import type { DisplayContext } from "#src/display_context.js";
import type { UserLayer } from "#src/layer/index.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { ToolActivation } from "#src/ui/tool.js";
import { DataType } from "#src/util/data_type.js";
import { RefCounted } from "#src/util/disposable.js";
import { vec3, vec4 } from "#src/util/geom.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
import type { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
import type { GL } from "#src/webgl/context.js";
import type { HistogramSpecifications } from "#src/webgl/empirical_cdf.js";
import type { ShaderCodePart, ShaderProgram } from "#src/webgl/shader.js";
import { ShaderBuilder } from "#src/webgl/shader.js";
import { AutoRangeFinder } from "#src/widget/invlerp_range_finder.js";
import type { LayerControlFactory, LayerControlTool } from "#src/widget/layer_control.js";
import { Tab } from "#src/widget/tab_view.js";
export declare const NUM_COLOR_CHANNELS = 4;
/**
 * Options to update a lookup table texture with a direct lookup table
 */
export interface LookupTableTextureOptions {
    /** A lookup table is a series of color values (0 - 255) for each index in the transfer function texture
     */
    lookupTable: LookupTable;
    /** textureUnit to update with the new transfer function texture data */
    textureUnit: number | undefined;
}
/**
 * Options to update a transfer function texture using control points
 */
export interface ControlPointTextureOptions {
    /** controlPoints will be used to generate a lookup table as a first step */
    sortedControlPoints: SortedControlPoints;
    /** textureUnit to update with the new transfer function texture data */
    textureUnit: number | undefined;
    /** Data type of the control points */
    dataType: DataType;
    /** Lookup table number of elements*/
    lookupTableSize: number;
}
export interface TransferFunctionParameters {
    sortedControlPoints: SortedControlPoints;
    window: DataTypeInterval;
    channel: number[];
    defaultColor: vec3;
}
/**
 * Transfer functions are controlled via a set of control points
 * with an input value and an output RGBA color (Uint8).
 * These control points are interpolated between to form a lookup table
 * which maps an input data value to an RGBA color.
 * Such a lookup table is used to form a texture, which can be sampled
 * from during rendering.
 */
export declare class ControlPoint {
    inputValue: number | bigint;
    outputColor: vec4;
    constructor(inputValue: number | bigint, outputColor?: vec4);
    /** Convert the input value to a normalized value between 0 and 1 */
    normalizedInput(range: DataTypeInterval): number;
    /** Convert the input value to an integer index into the transfer function lookup texture */
    transferFunctionIndex(dataRange: DataTypeInterval, transferFunctionSize: number): number;
    interpolateColor(other: ControlPoint, t: number): vec4;
    static copyFrom(other: ControlPoint): ControlPoint;
}
export declare class SortedControlPoints {
    controlPoints: ControlPoint[];
    dataType: DataType;
    private autoComputeRange;
    range: DataTypeInterval;
    constructor(controlPoints: ControlPoint[] | undefined, dataType: DataType, autoComputeRange?: boolean);
    get length(): number;
    setDefaultControlPoints(controlPointRange: DataTypeInterval, finalColor: vec4): void;
    clear(): void;
    addPoint(controlPoint: ControlPoint): void;
    removePoint(index: number): void;
    updatePoint(index: number, controlPoint: ControlPoint): number;
    updatePointColor(index: number, color: vec4 | vec3): void;
    findNearestControlPointIndex(inputValue: number | bigint): number;
    findNearestControlPointIndexByNormalizedInput(normalizedInput: number): number;
    private sortAndComputeRange;
    private computeRange;
    copy(): SortedControlPoints;
}
export declare class LookupTable {
    lookupTableSize: number;
    outputValues: Uint8Array;
    constructor(lookupTableSize: number);
    resize(newSize: number): void;
    /**
     * Fill a lookup table with color values between control points via linear interpolation.
     * Everything before the first point is transparent,
     * everything after the last point has the color of the last point.
     *
     * @param controlPoints The control points to interpolate between
     * @param dataRange The range of the input data space
     */
    updateFromControlPoints(sortedControlPoints: SortedControlPoints, window?: DataTypeInterval | undefined): void;
    static equal(a: LookupTable, b: LookupTable): boolean;
    copy(): LookupTable;
}
/**
 * Handles a linked lookup table and control points for a transfer function.
 */
export declare class TransferFunction extends RefCounted {
    dataType: DataType;
    trackable: WatchableValueInterface<TransferFunctionParameters>;
    lookupTable: LookupTable;
    autoPointUpdateEnabled: boolean;
    constructor(dataType: DataType, trackable: WatchableValueInterface<TransferFunctionParameters>, size?: number);
    get sortedControlPoints(): SortedControlPoints;
    get range(): DataTypeInterval;
    get size(): number;
    updateLookupTable(window?: DataTypeInterval | undefined): void;
    addPoint(controlPoint: ControlPoint): void;
    /**
     * Generate two default control points for the transfer function, from transparent to a full color.
     * @param range The range of the two control points to interpolate between.
     * If null, the data window will be used to generate the control points.
     * @param window The window of the data in view. Control points are placed
     * at 30% and 70% of the window if range is not provided.
     * If the window is not provided, the current window of the transfer function
     * will be used.
     */
    generateDefaultControlPoints(range?: DataTypeInterval | null, window?: DataTypeInterval | undefined): void;
    generateDefaultWindow(range?: DataTypeInterval | null): void;
    updatePoint(index: number, controlPoint: ControlPoint): number;
    removePoint(index: number): void;
    updatePointColor(index: number, color: vec4 | vec3): void;
    findNearestControlPointIndex(normalizedInputValue: number, dataWindow: DataTypeInterval): number;
}
declare abstract class BaseLookupTexture extends RefCounted {
    gl: GL | null;
    texture: WebGLTexture | null;
    protected width: number;
    protected height: number;
    protected priorOptions: LookupTableTextureOptions | ControlPointTextureOptions | undefined;
    constructor(gl: GL | null);
    /**
     * Compare the existing options to the new options to determine if the texture needs to be updated
     */
    abstract optionsEqual(newOptions: LookupTableTextureOptions | ControlPointTextureOptions): boolean;
    abstract createLookupTable(options: LookupTableTextureOptions | ControlPointTextureOptions): LookupTable;
    abstract setOptions(options: LookupTableTextureOptions | ControlPointTextureOptions): void;
    updateAndActivate(options: LookupTableTextureOptions | ControlPointTextureOptions): number | undefined;
    setTextureWidthAndHeightFromSize(size: number): void;
    disposed(): void;
}
export declare class ControlPointTexture extends BaseLookupTexture {
    gl: GL | null;
    protected priorOptions: ControlPointTextureOptions | undefined;
    constructor(gl: GL | null);
    optionsEqual(newOptions: ControlPointTextureOptions): boolean;
    setOptions(options: ControlPointTextureOptions): void;
    createLookupTable(options: ControlPointTextureOptions): LookupTable;
    ensureTextureSize(size: number): number | undefined;
}
/**
 * Widget for the transfer function. Creates the UI elements required for the transfer function.
 */
declare class TransferFunctionWidget extends Tab {
    display: DisplayContext;
    dataType: DataType;
    trackable: WatchableValueInterface<TransferFunctionParameters>;
    histogramSpecifications: HistogramSpecifications;
    histogramIndex: number;
    private transferFunctionPanel;
    autoRangeFinder: AutoRangeFinder;
    window: {
        container: HTMLDivElement;
        inputs: HTMLInputElement[];
    };
    get autoPointUpdateEnabled(): boolean;
    set autoPointUpdateEnabled(value: boolean);
    get texture(): WebGLTexture | null;
    constructor(visibility: WatchableVisibilityPriority, display: DisplayContext, dataType: DataType, trackable: WatchableValueInterface<TransferFunctionParameters>, histogramSpecifications: HistogramSpecifications, histogramIndex: number);
    private createClearButton;
    private createColorPicker;
    private createWindowBoundInputs;
    updateView(): void;
    updateControlPointsAndDraw(): void;
    updateTrackable(value: TransferFunctionParameters): void;
    generateDefaultControlPoints(range?: DataTypeInterval | null): void;
    clearPoints(): void;
}
/**
 * Create a shader function for the transfer function to grab the nearest lookup table value
 */
export declare function defineTransferFunctionShader(builder: ShaderBuilder, name: string, dataType: DataType, channel: number[]): ShaderCodePart[];
/**
 * Create a lookup table and bind that lookup table to a shader via uniforms
 */
export declare function enableTransferFunctionShader(shader: ShaderProgram, name: string, dataType: DataType, sortedControlPoints: SortedControlPoints, lookupTableSize?: number): void;
/**
 * Behaviour of the transfer function widget in the tool popup window
 */
export declare function activateTransferFunctionTool(activation: ToolActivation<LayerControlTool>, control: TransferFunctionWidget): void;
/**
 * Create a layer control factory for the transfer function widget
 */
export declare function transferFunctionLayerControl<LayerType extends UserLayer>(getter: (layer: LayerType) => {
    watchableValue: WatchableValueInterface<TransferFunctionParameters>;
    defaultChannel: number[];
    channelCoordinateSpaceCombiner: CoordinateSpaceCombiner | undefined;
    histogramSpecifications: HistogramSpecifications;
    histogramIndex: number;
    dataType: DataType;
}): LayerControlFactory<LayerType, TransferFunctionWidget>;
export {};
