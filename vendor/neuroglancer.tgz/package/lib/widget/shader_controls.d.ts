/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/shader_controls.css";
import type { DisplayContext } from "#src/display_context.js";
import type { UserLayer, UserLayerConstructor } from "#src/layer/index.js";
import { TrackableBoolean } from "#src/trackable_boolean.js";
import type { AnyConstructor } from "#src/util/mixin.js";
import type { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
import type { ParameterizedEmitterDependentShaderOptions, ParameterizedShaderGetterResult } from "#src/webgl/dynamic_shader.js";
import { type ShaderControlState } from "#src/webgl/shader_ui_controls.js";
import { Tab } from "#src/widget/tab_view.js";
export interface LegendShaderOptions extends ParameterizedEmitterDependentShaderOptions {
    initializeShader: (shaderResult: ParameterizedShaderGetterResult) => void;
}
export interface ShaderControlsOptions {
    legendShaderOptions?: LegendShaderOptions;
    visibility?: WatchableVisibilityPriority;
    toolId?: string;
    hideInactiveShaderControls?: TrackableBoolean;
}
export declare class ShaderControls extends Tab {
    state: ShaderControlState;
    display: DisplayContext;
    layer: UserLayer;
    options: ShaderControlsOptions;
    private controlDisposer;
    private controlsContainer;
    private hiddenCountElement;
    private hideInactiveShaderControls;
    private toolId;
    constructor(state: ShaderControlState, display: DisplayContext, layer: UserLayer, options?: ShaderControlsOptions);
    updateControls(): void;
    disposed(): void;
}
interface LayerShaderControls {
    shaderControlState: ShaderControlState;
    legendShaderOptions?: LegendShaderOptions;
}
export declare const SHADER_CONTROL_TOOL_ID = "shaderControl";
export declare function registerLayerShaderControlsTool<LayerType extends UserLayer>(layerType: UserLayerConstructor & AnyConstructor<LayerType>, getter: (layer: LayerType) => LayerShaderControls, toolId?: string): void;
export {};
