/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
export declare class DependentViewContext extends RefCounted {
    redraw: () => void;
    constructor(redraw: () => void);
}
export declare class DependentViewWidget<T> extends RefCounted {
    model: WatchableValueInterface<T>;
    render: (value: T, parent: HTMLElement, context: DependentViewContext) => void;
    visibility: WatchableVisibilityPriority;
    element: HTMLDivElement;
    private generation;
    private currentViewDisposer;
    private debouncedUpdateView;
    private debouncedForceUpdateView;
    constructor(model: WatchableValueInterface<T>, render: (value: T, parent: HTMLElement, context: DependentViewContext) => void, visibility?: WatchableVisibilityPriority);
    get visible(): boolean;
    private updateView;
    private disposeCurrentView;
    disposed(): void;
}
