/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/widget/invlerp.css";
import type { DisplayContext } from "#src/display_context.js";
import { IndirectRenderedPanel } from "#src/display_context.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { ToolActivation } from "#src/ui/tool.js";
import type { DataType } from "#src/util/data_type.js";
import type { Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { DataTypeInterval } from "#src/util/lerp.js";
import type { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
import type { GL } from "#src/webgl/context.js";
import type { HistogramSpecifications } from "#src/webgl/empirical_cdf.js";
import type { InvlerpParameters } from "#src/webgl/shader_ui_controls.js";
import { AutoRangeFinder } from "#src/widget/invlerp_range_finder.js";
import type { LayerControlTool } from "#src/widget/layer_control.js";
import type { LegendShaderOptions } from "#src/widget/shader_controls.js";
import { Tab } from "#src/widget/tab_view.js";
export declare function createCDFLineShader(gl: GL, textureUnit: symbol): import("#src/webgl/shader.js").ShaderProgram;
export declare class CdfController<T extends RangeAndWindowIntervals> extends RefCounted {
    element: HTMLElement;
    dataType: DataType;
    getModel: () => T;
    setModel: (value: T) => void;
    constructor(element: HTMLElement, dataType: DataType, getModel: () => T, setModel: (value: T) => void);
    /**
     * Get fraction of distance in x along bounding rect for a MouseEvent.
     */
    getTargetFraction(event: MouseEvent): number;
    /**
     * Interpolate a value along the model interval.
     * @param relativeX Relative x coordinate within the interval.
     * @returns Interpolated value.
     */
    getWindowLerp(relativeX: number): number | bigint;
    getTargetValue(event: MouseEvent): number | bigint | undefined;
}
/**
 * An interval with coordinates `range` and endpoint values `window`.
 * Can be thought of representing associated intervals in x (range) and y (window).
 */
export interface RangeAndWindowIntervals {
    range: DataTypeInterval;
    window: DataTypeInterval;
}
/**
 * Update the value of one endpoint, and return new interval.
 * @param existingBounds Initial bounds.
 * @param boundType 'range' to update endpoint coordinates, 'window' to update endpoint values.
 * @param endpointIndex Index of bound to update.
 * @param newEndpoint New value of bound being updated.
 * @param fitRangeInWindow
 * @returns New bounds.
 */
export declare function getUpdatedRangeAndWindowParameters<T extends RangeAndWindowIntervals>(existingBounds: T, boundType: "range" | "window", endpointIndex: number, newEndpoint: number | bigint, fitRangeInWindow?: boolean): T;
export declare const NUM_CDF_LINES: number;
/**
 * Panel that shows Cumulative Distribution Function (CDF) of visible data.
 */
declare class CdfPanel extends IndirectRenderedPanel {
    parent: InvlerpWidget;
    get drawOrder(): number;
    controller: CdfController<InvlerpParameters>;
    constructor(parent: InvlerpWidget);
    private dataValuesBuffer;
    private lineShader;
    private regionCornersBuffer;
    private regionShader;
    drawIndirect(): void;
    isReady(): boolean;
}
export declare function updateInputBoundWidth(inputElement: HTMLInputElement): void;
export declare function updateInputBoundValue(inputElement: HTMLInputElement, bound: number | bigint): void;
export declare function invertInvlerpRange(trackable: WatchableValueInterface<InvlerpParameters>): void;
export declare function adjustInvlerpContrast(dataType: DataType, trackable: WatchableValueInterface<InvlerpParameters>, scaleFactor: number): void;
export declare function adjustInvlerpBrightnessContrast(dataType: DataType, trackable: WatchableValueInterface<InvlerpParameters>, baseRange: DataTypeInterval, brightnessAmount: number, contrastAmount: number): void;
export declare class InvlerpWidget extends Tab {
    display: DisplayContext;
    dataType: DataType;
    trackable: WatchableValueInterface<InvlerpParameters>;
    histogramSpecifications: HistogramSpecifications;
    histogramIndex: number;
    legendShaderOptions: LegendShaderOptions | undefined;
    cdfPanel: CdfPanel;
    boundElements: {
        range: {
            container: HTMLDivElement;
            inputs: [HTMLInputElement, HTMLInputElement];
            spacers: [HTMLElement, HTMLElement, HTMLElement] | undefined;
        };
        window: {
            container: HTMLDivElement;
            inputs: [HTMLInputElement, HTMLInputElement];
            spacers: [HTMLElement, HTMLElement, HTMLElement] | undefined;
        };
    };
    invertArrows: HTMLElement[];
    autoRangeFinder: AutoRangeFinder;
    get texture(): WebGLTexture | null;
    private invertRange;
    constructor(visibility: WatchableVisibilityPriority, display: DisplayContext, dataType: DataType, trackable: WatchableValueInterface<InvlerpParameters>, histogramSpecifications: HistogramSpecifications, histogramIndex: number, legendShaderOptions: LegendShaderOptions | undefined);
    updateView(): void;
}
export declare class VariableDataTypeInvlerpWidget extends Tab {
    display: DisplayContext;
    watchableDataType: WatchableValueInterface<DataType>;
    trackable: WatchableValueInterface<InvlerpParameters>;
    histogramSpecifications: HistogramSpecifications;
    histogramIndex: number;
    legendShaderOptions: LegendShaderOptions | undefined;
    invlerpWidget: Owned<InvlerpWidget>;
    constructor(visibility: WatchableVisibilityPriority, display: DisplayContext, watchableDataType: WatchableValueInterface<DataType>, trackable: WatchableValueInterface<InvlerpParameters>, histogramSpecifications: HistogramSpecifications, histogramIndex: number, legendShaderOptions: LegendShaderOptions | undefined);
    get dataType(): DataType;
    disposed(): void;
    private makeInvlerpWidget;
}
export declare function activateInvlerpTool(activation: ToolActivation<LayerControlTool>, control: InvlerpWidget | VariableDataTypeInvlerpWidget): void;
export {};
