/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
import type { KvStoreWithPath, ListResponse, ReadResponse, ReadOptions, ListOptions, StatOptions, StatResponse, FileHandle } from "#src/kvstore/index.js";
import type { UrlWithParsedScheme } from "#src/kvstore/url.js";
import type { BasicCompletionResult, CompletionWithDescription } from "#src/util/completion.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export type CompletionResult = BasicCompletionResult<CompletionWithDescription>;
export interface BaseKvStoreProvider {
    scheme: string;
    hidden?: boolean;
    description?: string;
    getKvStore(parsedUrl: UrlWithParsedScheme): KvStoreWithPath;
    completeUrl?: (options: BaseKvStoreCompleteUrlOptions) => Promise<CompletionResult | undefined>;
}
export interface BaseKvStoreCompleteUrlOptions extends Partial<ProgressOptions> {
    url: UrlWithParsedScheme;
}
export interface KvStoreAdapterProvider {
    scheme: string;
    hidden?: boolean;
    description?: string;
    getKvStore(parsedUrl: UrlWithParsedScheme, base: KvStoreWithPath): KvStoreWithPath;
    completeUrl?: (options: KvStoreAdapterCompleteUrlOptions) => Promise<CompletionResult | undefined>;
}
export interface KvStoreAdapterCompleteUrlOptions extends Partial<ProgressOptions> {
    url: UrlWithParsedScheme;
    base: KvStoreWithPath;
}
export declare class KvStoreContext {
    baseKvStoreProviders: Map<string, BaseKvStoreProvider>;
    kvStoreAdapterProviders: Map<string, KvStoreAdapterProvider>;
    autoDetectRegistry: AutoDetectRegistry;
    getKvStore(url: string): KvStoreWithPath;
    getFileHandle(url: string): FileHandle;
    getBaseKvStoreProvider(url: UrlWithParsedScheme): BaseKvStoreProvider;
    getKvStoreAdapterProvider(adapterUrl: UrlWithParsedScheme): KvStoreAdapterProvider;
    applyKvStoreAdapterUrl(base: KvStoreWithPath, adapterUrl: UrlWithParsedScheme): KvStoreWithPath;
    describeProtocolUsage(protocol: string): string | undefined;
    stat(url: string, options?: StatOptions): Promise<StatResponse | undefined>;
    read(url: string, options: ReadOptions & {
        throwIfMissing: true;
    }): Promise<ReadResponse>;
    read(url: string, options?: ReadOptions): Promise<ReadResponse | undefined>;
    list(urlPrefix: string, options?: ListOptions): Promise<ListResponse>;
    resolveRelativePath(baseUrl: string, relativePath: string): string;
}
