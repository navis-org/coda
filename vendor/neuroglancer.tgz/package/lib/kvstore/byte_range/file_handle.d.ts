/**
 * @license
 * Copyright 2023 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ByteRange, ByteRangeRequest, DriverReadOptions, FileHandle, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
export declare function composeByteRangeRequest(outer: ByteRange, inner: ByteRangeRequest | undefined): {
    outer: ByteRange;
    inner: ByteRange;
};
export declare function handleByteRangeRequestFromUint8Array(value: Uint8Array<ArrayBuffer>, byteRange: ByteRangeRequest | undefined): ReadResponse;
export declare class FileByteRangeHandle implements FileHandle {
    base: FileHandle;
    byteRange: ByteRange;
    constructor(base: FileHandle, byteRange: ByteRange);
    stat(options: StatOptions): Promise<StatResponse | undefined>;
    read(options: DriverReadOptions): Promise<ReadResponse>;
    getUrl(): string;
}
