/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { KvStore, DriverListOptions, ListResponse, DriverReadOptions, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
import type { KvStoreProviderRegistry, SharedKvStoreContextBase } from "#src/kvstore/register.js";
import type { FetchOk } from "#src/util/http_request.js";
export declare class ReadableS3KvStore<SharedKvStoreContext extends SharedKvStoreContextBase> implements KvStore {
    sharedKvStoreContext: SharedKvStoreContext;
    baseUrl: string;
    baseUrlForDisplay: string;
    protected knownToBeVirtualHostedStyle: boolean;
    protected fetchOkImpl: FetchOk;
    constructor(sharedKvStoreContext: SharedKvStoreContext, baseUrl: string, baseUrlForDisplay: string, knownToBeVirtualHostedStyle: boolean, fetchOkImpl?: FetchOk);
    stat(key: string, options: StatOptions): Promise<StatResponse | undefined>;
    read(key: string, options: DriverReadOptions): Promise<ReadResponse | undefined>;
    list(prefix: string, options: DriverListOptions): Promise<ListResponse>;
    getUrl(path: string): string;
    get supportsOffsetReads(): boolean;
    get supportsSuffixReads(): boolean;
}
export declare function registerProviders<SharedKvStoreContext extends SharedKvStoreContextBase>(registry: KvStoreProviderRegistry<SharedKvStoreContext>, s3KvStoreClass: typeof ReadableS3KvStore<SharedKvStoreContext>): void;
