/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CredentialsManager, CredentialsWithGeneration } from "#src/credentials_provider/index.js";
import { CredentialsProvider } from "#src/credentials_provider/index.js";
import type { OAuth2Credentials } from "#src/credentials_provider/oauth2.js";
import type { HttpError } from "#src/util/http_request.js";
export type MiddleAuthToken = {
    tokenType: string;
    accessToken: string;
    url: string;
    appUrls: string[];
};
export declare class MiddleAuthCredentialsProvider extends CredentialsProvider<MiddleAuthToken> {
    private serverUrl;
    alreadyTriedLocalStorage: boolean;
    constructor(serverUrl: string);
    get: (invalidCredentials?: CredentialsWithGeneration<MiddleAuthToken> | undefined, options?: Partial<import("#src/util/progress_listener.js").ProgressOptions>) => Promise<CredentialsWithGeneration<MiddleAuthToken>>;
}
export declare class UnverifiedApp extends Error {
    url: string;
    constructor(url: string);
}
export declare class MiddleAuthAppCredentialsProvider extends CredentialsProvider<MiddleAuthToken> {
    private serverUrl;
    private credentialsManager;
    private credentials;
    private agreedToTos;
    constructor(serverUrl: string, credentialsManager: CredentialsManager);
    get: (invalidCredentials?: CredentialsWithGeneration<MiddleAuthToken> | undefined, options?: Partial<import("#src/util/progress_listener.js").ProgressOptions>) => Promise<CredentialsWithGeneration<MiddleAuthToken>>;
    errorHandler: (error: HttpError, credentials: OAuth2Credentials) => Promise<"refresh">;
}
