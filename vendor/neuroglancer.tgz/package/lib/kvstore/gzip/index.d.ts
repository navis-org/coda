/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
import type { DriverReadOptions, KvStore, ReadResponse, StatOptions, StatResponse, FileHandle } from "#src/kvstore/index.js";
export declare class GzipKvStore implements KvStore {
    base: FileHandle;
    scheme: string;
    format: CompressionFormat;
    constructor(base: FileHandle, scheme: string, format: CompressionFormat);
    getUrl(key: string): string;
    private validatePath;
    stat(key: string, options: StatOptions): Promise<StatResponse | undefined>;
    read(key: string, options: DriverReadOptions): Promise<ReadResponse | undefined>;
    get supportsOffsetReads(): boolean;
    get supportsSuffixReads(): boolean;
    get singleKey(): boolean;
}
export declare function registerAutoDetect(registry: AutoDetectRegistry): void;
