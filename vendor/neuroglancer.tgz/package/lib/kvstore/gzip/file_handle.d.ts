/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DriverReadOptions, FileHandle, ReadableKvStore, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
export declare const EXPECTED_HEADER_OVERHEAD = 100;
export declare class GzipFileHandle<BaseHandle extends FileHandle = FileHandle> implements FileHandle {
    base: BaseHandle;
    format: CompressionFormat;
    constructor(base: BaseHandle, format: CompressionFormat);
    stat(options: StatOptions): Promise<StatResponse | undefined>;
    read(options: DriverReadOptions): Promise<ReadResponse | undefined>;
    getUrl(): string;
}
export declare function gzipRead<Key>(base: ReadableKvStore<Key>, baseKey: Key, format: CompressionFormat, options: DriverReadOptions): Promise<{
    response: Response;
    offset: number;
    length: undefined;
    totalSize: undefined;
} | {
    response: Response;
    offset: number;
    length: number;
    totalSize: undefined;
} | undefined>;
