/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { KvStoreContext } from "#src/kvstore/context.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export interface AutoDetectDirectoryOptions {
    url: string;
    fileNames: Set<string>;
    subDirectories: Set<string>;
    signal?: AbortSignal;
}
export interface AutoDetectMatch {
    suffix: string;
    description: string;
}
export interface AutoDetectDirectorySpec {
    fileNames?: Set<string>;
    subDirectories?: Set<string>;
    match: (options: AutoDetectDirectoryOptions) => Promise<AutoDetectMatch[]>;
}
export declare function simpleFilePresenceAutoDetectDirectorySpec(fileNames: Set<string>, match: AutoDetectMatch): AutoDetectDirectorySpec;
export interface AutoDetectFileOptions {
    url: string;
    prefix: Uint8Array<ArrayBuffer>;
    suffix?: Uint8Array<ArrayBuffer>;
    totalSize: number | undefined;
    signal?: AbortSignal;
}
export interface AutoDetectFileSpec {
    prefixLength: number;
    suffixLength: number;
    match: (options: AutoDetectFileOptions) => Promise<AutoDetectMatch[]>;
}
export declare function composeAutoDetectDirectorySpecs(specs: AutoDetectDirectorySpec[]): AutoDetectDirectorySpec;
export declare function composeAutoDetectFileSpecs(specs: AutoDetectFileSpec[]): AutoDetectFileSpec;
export declare class AutoDetectRegistry {
    directorySpecs: AutoDetectDirectorySpec[];
    fileSpecs: AutoDetectFileSpec[];
    private _directorySpec;
    private _fileSpec;
    registerDirectoryFormat(spec: AutoDetectDirectorySpec): void;
    registerFileFormat(spec: AutoDetectFileSpec): void;
    copyTo(registry: AutoDetectRegistry): void;
    get directorySpec(): AutoDetectDirectorySpec;
    private getDirectorySpec;
    get fileSpec(): AutoDetectFileSpec;
    private getFileSpec;
}
export interface AutoDetectFormatOptions extends Partial<ProgressOptions> {
    kvStoreContext: KvStoreContext;
    url: string;
    autoDetectDirectory: () => AutoDetectDirectorySpec;
    autoDetectFile: () => AutoDetectFileSpec;
}
export declare function autoDetectFormat(options: AutoDetectFormatOptions): Promise<{
    matches: AutoDetectMatch[];
    url: string;
}>;
