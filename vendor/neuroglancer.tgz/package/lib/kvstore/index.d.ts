/**
 * @license
 * Copyright 2023 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ProgressOptions } from "#src/util/progress_listener.js";
export interface ByteRange {
    offset: number;
    length: number;
}
export type ByteRangeRequest = ByteRange | {
    suffixLength: number;
};
export interface ReadResponse {
    response: Response;
    offset: number;
    length: number | undefined;
    totalSize: number | undefined;
}
export interface DriverReadOptions extends Partial<ProgressOptions> {
    byteRange?: ByteRangeRequest;
    throwIfMissing?: boolean;
}
export declare class NotFoundError extends Error {
    constructor(handle: FileHandle, options?: {
        cause: any;
    });
}
export interface ReadOptions extends DriverReadOptions {
    strictByteRange?: boolean;
}
export type DriverListOptions = Partial<ProgressOptions>;
export type ListResponseKeyKind = "path" | "suffix" | "url";
export interface ListOptions extends DriverListOptions {
    responseKeys?: ListResponseKeyKind;
}
export interface ListEntry {
    key: string;
}
export interface ListResponse {
    entries: ListEntry[];
    directories: string[];
}
export interface StatOptions extends Partial<ProgressOptions> {
    throwIfMissing?: boolean;
}
export interface StatResponse {
    totalSize: number | undefined;
}
export interface ReadableKvStore<Key = string> {
    stat(key: Key, options: StatOptions): Promise<StatResponse | undefined>;
    read(key: Key, options: DriverReadOptions): Promise<ReadResponse | undefined>;
    getUrl(key: Key): string;
    supportsOffsetReads: boolean;
    supportsSuffixReads: boolean;
}
export interface ListableKvStore {
    list?: (prefix: string, options: DriverListOptions) => Promise<ListResponse>;
}
export interface KvStore extends ReadableKvStore, ListableKvStore {
    singleKey?: boolean;
}
export interface KvStoreWithPath {
    store: KvStore;
    path: string;
}
export declare function getKvStoreUrl(kvstore: KvStoreWithPath): string;
export declare function readKvStore<Key>(store: ReadableKvStore<Key>, key: Key, options: ReadOptions & {
    throwIfMissing: true;
}): Promise<ReadResponse>;
export declare function readKvStore<Key>(store: ReadableKvStore<Key>, key: Key, options?: ReadOptions): Promise<ReadResponse | undefined>;
export declare function readFileHandle(handle: FileHandle, options: ReadOptions & {
    throwIfMissing: true;
}): Promise<ReadResponse>;
export declare function readFileHandle(handle: FileHandle, options?: ReadOptions): Promise<ReadResponse | undefined>;
export declare function listKvStore(kvStore: KvStore, prefix: string, options?: ListOptions): Promise<ListResponse>;
export declare function listKvStoreRecursively(kvStore: KvStore, prefix: string, options?: ListOptions): Promise<ListEntry[]>;
export declare function kvStoreAppendPath(kvstore: KvStoreWithPath, suffix: string): KvStoreWithPath;
export interface FileHandle {
    stat(options: StatOptions): Promise<StatResponse | undefined>;
    read(options: DriverReadOptions): Promise<ReadResponse | undefined>;
    getUrl(): string;
}
export declare class KvStoreFileHandle<Key> implements FileHandle {
    store: ReadableKvStore<Key>;
    key: Key;
    constructor(store: ReadableKvStore<Key>, key: Key);
    stat(options: StatOptions): Promise<StatResponse | undefined>;
    read(options: DriverReadOptions): Promise<ReadResponse | undefined>;
    getUrl(): string;
}
export declare function normalizeListResponse(response: ListResponse): ListResponse;
