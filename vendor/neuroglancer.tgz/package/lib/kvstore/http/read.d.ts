/**
 * @license
 * Copyright 2023 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DriverReadOptions, ReadableKvStore, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
import type { FetchOk } from "#src/util/http_request.js";
export declare function read<Key>(store: ReadableKvStore<Key>, key: Key, url: string, options: DriverReadOptions, fetchOkImpl?: FetchOk): Promise<ReadResponse | undefined>;
export declare function stat<Key>(store: ReadableKvStore<Key>, key: Key, url: string, options: StatOptions, fetchOkImpl?: FetchOk): Promise<StatResponse | undefined>;
