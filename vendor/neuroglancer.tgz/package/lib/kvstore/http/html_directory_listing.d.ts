/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { type DriverListOptions, type ListResponse } from "#src/kvstore/index.js";
import type { FetchOk } from "#src/util/http_request.js";
import { type ProgressOptions } from "#src/util/progress_listener.js";
/**
 * Obtains a directory listing from a server that supports HTML directory listings.
 */
export declare function getHtmlDirectoryListing(url: string, options?: {
    fetchOkImpl?: FetchOk;
} & Partial<ProgressOptions>): Promise<string[]>;
export declare function listFromHtmlDirectoryListing(baseUrl: string, prefix: string, fetchOkImpl: FetchOk, options: DriverListOptions): Promise<ListResponse>;
