/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { ChunkPayload } from "#src/kvstore/icechunk/manifest.js";
import type { NodeSnapshot, Snapshot } from "#src/kvstore/icechunk/snapshot.js";
import type { DriverReadOptions, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export interface ResolvedIcechunkPath {
    node: NodeSnapshot;
    chunk?: number[];
}
export declare function resolveIcechunkPath(snapshot: Snapshot, path: string): ResolvedIcechunkPath | undefined;
export declare function resolveChunkPayload(sharedKvStoreContext: SharedKvStoreContextCounterpart, baseUrl: string, node: NodeSnapshot, chunk: number[], options: Partial<ProgressOptions>): Promise<ChunkPayload | undefined>;
export declare function stat(sharedKvStoreContext: SharedKvStoreContextCounterpart, baseUrl: string, snapshot: Snapshot, path: string, options: StatOptions): Promise<StatResponse | undefined>;
export declare function read(sharedKvStoreContext: SharedKvStoreContextCounterpart, baseUrl: string, snapshot: Snapshot, path: string, options: DriverReadOptions): Promise<ReadResponse | undefined>;
