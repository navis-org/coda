/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as v from "valibot";
import { ManifestId } from "#src/kvstore/icechunk/decode_utils.js";
declare const ChunkPayload: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, Record<string, any>>, v.UnionSchema<[v.StrictObjectSchema<{
    readonly Inline: v.InstanceSchema<Uint8ArrayConstructor, undefined>;
}, undefined>, v.StrictObjectSchema<{
    readonly Virtual: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        location: v.StringSchema<undefined>;
        offset: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
        length: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
        chunksum: v.AnySchema;
    }, undefined>]>;
}, undefined>, v.StrictObjectSchema<{
    readonly Ref: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
        offset: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
        length: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
    }, undefined>]>;
}, undefined>], undefined>]>;
export type ChunkPayload = v.InferOutput<typeof ChunkPayload>;
declare const Manifest: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
    [k: string]: unknown;
}>, v.StrictObjectSchema<{
    id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
    chunks: v.MapSchema<v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 8, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>, v.MapSchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>, v.TransformAction<number[], string>]>, v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, Record<string, any>>, v.UnionSchema<[v.StrictObjectSchema<{
        readonly Inline: v.InstanceSchema<Uint8ArrayConstructor, undefined>;
    }, undefined>, v.StrictObjectSchema<{
        readonly Virtual: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
            [k: string]: unknown;
        }>, v.StrictObjectSchema<{
            location: v.StringSchema<undefined>;
            offset: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
            length: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
            chunksum: v.AnySchema;
        }, undefined>]>;
    }, undefined>, v.StrictObjectSchema<{
        readonly Ref: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
            [k: string]: unknown;
        }>, v.StrictObjectSchema<{
            id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
            offset: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
            length: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
        }, undefined>]>;
    }, undefined>], undefined>]>, undefined>, undefined>;
}, undefined>]>;
export type Manifest = v.InferOutput<typeof Manifest> & {
    estimatedSize: number;
};
export declare function decodeManifest(buffer: ArrayBuffer, signal: AbortSignal): Promise<Manifest>;
export declare function getManifestUrl(baseUrl: string, id: ManifestId): string;
export {};
