/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { ManifestId } from "#src/kvstore/icechunk/decode_utils.js";
import type { SnapshotId } from "#src/kvstore/icechunk/snapshot.js";
import type { RefSpec } from "#src/kvstore/icechunk/url.js";
import { type ProgressOptions } from "#src/util/progress_listener.js";
export declare function getSnapshot(sharedKvStoreContext: SharedKvStoreContextCounterpart, baseUrl: string, id: SnapshotId, options: Partial<ProgressOptions>): Promise<import("#src/kvstore/icechunk/snapshot.js").Snapshot>;
export declare function getManifest(sharedKvStoreContext: SharedKvStoreContextCounterpart, baseUrl: string, id: ManifestId, options: Partial<ProgressOptions>): Promise<import("#src/kvstore/icechunk/manifest.js").Manifest>;
export declare function getRef(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, options: Partial<ProgressOptions>): Promise<string>;
export declare function getBranch(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, options: Partial<ProgressOptions>): Promise<string>;
export declare function getTag(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, options: Partial<ProgressOptions>): Promise<string>;
export declare function resolveRefSpec(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, refSpec: RefSpec, options: Partial<ProgressOptions>): Promise<string>;
