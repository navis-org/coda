/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as v from "valibot";
declare const SnapshotId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
export type SnapshotId = v.InferOutput<typeof SnapshotId>;
declare const ZarrArrayMetadata: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
    [k: string]: unknown;
}>, v.StrictObjectSchema<{
    shape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
    dataType: v.StringSchema<undefined>;
    chunkShape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
    chunkKeyEncoding: v.PicklistSchema<["Slash", "Dot"], undefined>;
    fillValue: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, any>]>;
    codecs: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        name: v.StringSchema<undefined>;
        configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
    }, undefined>]>, undefined>;
    storageTransformers: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        name: v.StringSchema<undefined>;
        configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
    }, undefined>]>, undefined>;
    dimensionNames: v.NullableSchema<v.ArraySchema<v.NullableSchema<v.StringSchema<undefined>, undefined>, undefined>, undefined>;
}, undefined>]>;
export type ZarrArrayMetadata = v.InferOutput<typeof ZarrArrayMetadata>;
declare const ManifestExtents: v.StrictTupleSchema<[v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>, v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>], undefined>;
export type ManifestExtents = v.InferOutput<typeof ManifestExtents>;
declare const ManifestRef: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
    [k: string]: unknown;
}>, v.StrictObjectSchema<{
    objectId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
    extents: v.StrictTupleSchema<[v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>, v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>], undefined>;
}, undefined>]>;
export type ManifestRef = v.InferOutput<typeof ManifestRef>;
declare const NodeDataArray: v.StrictObjectSchema<{
    readonly Array: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        metadata: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
            [k: string]: unknown;
        }>, v.StrictObjectSchema<{
            shape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
            dataType: v.StringSchema<undefined>;
            chunkShape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
            chunkKeyEncoding: v.PicklistSchema<["Slash", "Dot"], undefined>;
            fillValue: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, any>]>;
            codecs: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                [k: string]: unknown;
            }>, v.StrictObjectSchema<{
                name: v.StringSchema<undefined>;
                configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
            }, undefined>]>, undefined>;
            storageTransformers: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                [k: string]: unknown;
            }>, v.StrictObjectSchema<{
                name: v.StringSchema<undefined>;
                configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
            }, undefined>]>, undefined>;
            dimensionNames: v.NullableSchema<v.ArraySchema<v.NullableSchema<v.StringSchema<undefined>, undefined>, undefined>, undefined>;
        }, undefined>]>;
        manifests: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
            [k: string]: unknown;
        }>, v.StrictObjectSchema<{
            objectId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
            extents: v.StrictTupleSchema<[v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>, v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>], undefined>;
        }, undefined>]>, undefined>;
    }, undefined>]>;
}, undefined>;
export type NodeDataArray = v.InferOutput<typeof NodeDataArray>;
declare const NodeSnapshot: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
    [k: string]: unknown;
}>, v.StrictObjectSchema<{
    id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 8, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
    path: v.SchemaWithPipe<readonly [v.StringSchema<undefined>, v.TransformAction<string, string>]>;
    userAttributes: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, Record<string, any>>, v.UnionSchema<[v.StrictObjectSchema<{
        readonly Inline: v.AnySchema;
    }, undefined>], undefined>]>;
    nodeData: v.UnionSchema<[v.PicklistSchema<["Group"], undefined>, v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, Record<string, any>>, v.StrictObjectSchema<{
        readonly Array: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
            [k: string]: unknown;
        }>, v.StrictObjectSchema<{
            metadata: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                [k: string]: unknown;
            }>, v.StrictObjectSchema<{
                shape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
                dataType: v.StringSchema<undefined>;
                chunkShape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
                chunkKeyEncoding: v.PicklistSchema<["Slash", "Dot"], undefined>;
                fillValue: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, any>]>;
                codecs: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                    [k: string]: unknown;
                }>, v.StrictObjectSchema<{
                    name: v.StringSchema<undefined>;
                    configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
                }, undefined>]>, undefined>;
                storageTransformers: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                    [k: string]: unknown;
                }>, v.StrictObjectSchema<{
                    name: v.StringSchema<undefined>;
                    configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
                }, undefined>]>, undefined>;
                dimensionNames: v.NullableSchema<v.ArraySchema<v.NullableSchema<v.StringSchema<undefined>, undefined>, undefined>, undefined>;
            }, undefined>]>;
            manifests: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                [k: string]: unknown;
            }>, v.StrictObjectSchema<{
                objectId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
                extents: v.StrictTupleSchema<[v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>, v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>], undefined>;
            }, undefined>]>, undefined>;
        }, undefined>]>;
    }, undefined>]>], undefined>;
}, undefined>]>;
export type NodeSnapshot = v.InferOutput<typeof NodeSnapshot>;
declare const Snapshot: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
    [k: string]: unknown;
}>, v.StrictObjectSchema<{
    id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
    parentId: v.NullableSchema<v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>, undefined>;
    flushedAt: v.StringSchema<undefined>;
    message: v.StringSchema<undefined>;
    metadata: v.RecordSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
    manifestFiles: v.SchemaWithPipe<readonly [v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
        sizeBytes: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
        numRows: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
    }, undefined>]>, undefined>, v.TransformAction<{
        id: string;
        sizeBytes: number;
        numRows: number;
    }[], Map<any, any>>]>;
    attributeFiles: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
    }, undefined>]>, undefined>;
    nodes: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
        [k: string]: unknown;
    }>, v.StrictObjectSchema<{
        id: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 8, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
        path: v.SchemaWithPipe<readonly [v.StringSchema<undefined>, v.TransformAction<string, string>]>;
        userAttributes: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, Record<string, any>>, v.UnionSchema<[v.StrictObjectSchema<{
            readonly Inline: v.AnySchema;
        }, undefined>], undefined>]>;
        nodeData: v.UnionSchema<[v.PicklistSchema<["Group"], undefined>, v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, Record<string, any>>, v.StrictObjectSchema<{
            readonly Array: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                [k: string]: unknown;
            }>, v.StrictObjectSchema<{
                metadata: v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                    [k: string]: unknown;
                }>, v.StrictObjectSchema<{
                    shape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
                    dataType: v.StringSchema<undefined>;
                    chunkShape: v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>;
                    chunkKeyEncoding: v.PicklistSchema<["Slash", "Dot"], undefined>;
                    fillValue: v.SchemaWithPipe<readonly [v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>, v.TransformAction<Map<string, any>, any>]>;
                    codecs: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                        [k: string]: unknown;
                    }>, v.StrictObjectSchema<{
                        name: v.StringSchema<undefined>;
                        configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
                    }, undefined>]>, undefined>;
                    storageTransformers: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                        [k: string]: unknown;
                    }>, v.StrictObjectSchema<{
                        name: v.StringSchema<undefined>;
                        configuration: v.MapSchema<v.StringSchema<undefined>, v.AnySchema, undefined>;
                    }, undefined>]>, undefined>;
                    dimensionNames: v.NullableSchema<v.ArraySchema<v.NullableSchema<v.StringSchema<undefined>, undefined>, undefined>, undefined>;
                }, undefined>]>;
                manifests: v.ArraySchema<v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
                    [k: string]: unknown;
                }>, v.StrictObjectSchema<{
                    objectId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
                    extents: v.StrictTupleSchema<[v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>, v.ArraySchema<v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>, undefined>], undefined>;
                }, undefined>]>, undefined>;
            }, undefined>]>;
        }, undefined>]>], undefined>;
    }, undefined>]>, undefined>, v.TransformAction<Map<string, {
        id: string;
        path: string;
        userAttributes: {
            Inline: any;
        };
        nodeData: "Group" | {
            Array: {
                metadata: {
                    shape: number[];
                    dataType: string;
                    chunkShape: number[];
                    chunkKeyEncoding: "Slash" | "Dot";
                    fillValue: any;
                    codecs: {
                        name: string;
                        configuration: Map<string, any>;
                    }[];
                    storageTransformers: {
                        name: string;
                        configuration: Map<string, any>;
                    }[];
                    dimensionNames: (string | null)[] | null;
                };
                manifests: {
                    objectId: string;
                    extents: [number[], number[]];
                }[];
            };
        };
    }>, {
        id: string;
        path: string;
        userAttributes: {
            Inline: any;
        };
        nodeData: "Group" | {
            Array: {
                metadata: {
                    shape: number[];
                    dataType: string;
                    chunkShape: number[];
                    chunkKeyEncoding: "Slash" | "Dot";
                    fillValue: any;
                    codecs: {
                        name: string;
                        configuration: Map<string, any>;
                    }[];
                    storageTransformers: {
                        name: string;
                        configuration: Map<string, any>;
                    }[];
                    dimensionNames: (string | null)[] | null;
                };
                manifests: {
                    objectId: string;
                    extents: [number[], number[]];
                }[];
            };
        };
    }[]>]>;
}, undefined>]>;
export type Snapshot = v.InferOutput<typeof Snapshot> & {
    estimatedSize: number;
};
export declare function decodeSnapshot(buffer: ArrayBuffer, signal: AbortSignal): Promise<Snapshot>;
export declare function encodeZarrJson(node: NodeSnapshot): string;
export declare function findNode(snapshot: Snapshot, path: string): {
    id: string;
    path: string;
    userAttributes: {
        Inline: any;
    };
    nodeData: "Group" | {
        Array: {
            metadata: {
                shape: number[];
                dataType: string;
                chunkShape: number[];
                chunkKeyEncoding: "Slash" | "Dot";
                fillValue: any;
                codecs: {
                    name: string;
                    configuration: Map<string, any>;
                }[];
                storageTransformers: {
                    name: string;
                    configuration: Map<string, any>;
                }[];
                dimensionNames: (string | null)[] | null;
            };
            manifests: {
                objectId: string;
                extents: [number[], number[]];
            }[];
        };
    };
};
export declare function getSnapshotUrl(baseUrl: string, id: SnapshotId): string;
export {};
