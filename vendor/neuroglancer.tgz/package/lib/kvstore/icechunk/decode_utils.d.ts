/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import * as v from "valibot";
export declare const LATEST_KNOWN_SPEC_VERSION = 1;
export declare enum CompressionMethod {
    UNCOMPRESSED = 0,
    ZSTD = 1
}
export declare function decodeEnvelope(buffer: ArrayBuffer, maxVersion: number, fileType: number, signal: AbortSignal): Promise<{
    content: Uint8Array;
    specVersion: number;
}>;
export interface DecodedIcechunkMessage {
    content: unknown;
    specVersion: number;
    estimatedSize: number;
}
export declare function decodeMsgpack(buffer: ArrayBuffer, maxVersion: number, fileType: number, signal: AbortSignal): Promise<DecodedIcechunkMessage>;
export declare const DataId12: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
export declare const DataId8: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 8, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
export declare const Integer: v.UnionSchema<[v.SchemaWithPipe<readonly [v.BigintSchema<undefined>, v.CheckAction<bigint, `Number outside supported range: [${number}, ${number}]`>, v.TransformAction<any, number>]>, v.SchemaWithPipe<readonly [v.NumberSchema<undefined>, v.IntegerAction<number, undefined>]>], undefined>;
export declare function tupleToObject<TEntries extends v.ObjectEntries>(entries: TEntries): v.SchemaWithPipe<readonly [v.ArraySchema<v.AnySchema, undefined>, v.LengthAction<any[], number, undefined>, v.TransformAction<unknown[], {
    [k: string]: unknown;
}>, v.StrictObjectSchema<TEntries, undefined>]>;
export declare const ManifestId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
export type ManifestId = v.InferOutput<typeof ManifestId>;
export declare const ChunkId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 12, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
export type ChunkId = v.InferOutput<typeof ChunkId>;
export declare const NodeId: v.SchemaWithPipe<readonly [v.SchemaWithPipe<readonly [v.TupleSchema<[v.InstanceSchema<Uint8ArrayConstructor, undefined>], undefined>, v.TransformAction<[Uint8Array<ArrayBuffer>], Uint8Array<ArrayBuffer>>]>, v.LengthAction<Uint8Array<ArrayBuffer>, 8, undefined>, v.TransformAction<Uint8Array<ArrayBuffer>, string>]>;
export type NodeId = v.InferOutput<typeof NodeId>;
export declare function parseDecodedMsgpack<TOutput, TIssue extends v.BaseIssue<unknown>>(schema: v.BaseSchema<unknown, TOutput, TIssue>, name: string, decoded: DecodedIcechunkMessage): TOutput & {
    estimatedSize: number;
};
