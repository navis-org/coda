/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Reader } from "#src/kvstore/ocdbt/decode_utils.js";
export interface IndirectDataReference {
    dataFile: DataFileId;
    offset: bigint;
    length: bigint;
}
export interface ReadIndirectDataReferenceOptions {
    allowMissing?: boolean;
    dataFileTable: DataFileTable;
}
export declare function readDataFileId(reader: Reader, options: {
    dataFileTable: DataFileTable;
}): DataFileId;
export declare const readIndirectDataReferences: import("#src/kvstore/ocdbt/decode_utils.js").ArrayReader<IndirectDataReference, ReadIndirectDataReferenceOptions>;
export declare function locationIsMissing(location: IndirectDataReference): boolean;
export interface DataFileId {
    baseUrl: string;
    relativePath: string;
}
export type DataFileTable = DataFileId[];
export declare function readDataFileTable(reader: Reader, transitiveBaseUrl: string): DataFileTable;
