/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { IndirectDataReference, ReadIndirectDataReferenceOptions } from "#src/kvstore/ocdbt/indirect_data_reference.js";
import type { Key } from "#src/kvstore/ocdbt/key.js";
export type BtreeLeafNodeValueReference = Uint8Array<ArrayBuffer> | IndirectDataReference;
export interface BtreeLeafNodeEntry {
    key: Uint8Array<ArrayBuffer>;
    value: BtreeLeafNodeValueReference;
}
export interface BtreeInteriorNodeEntry {
    key: Uint8Array<ArrayBuffer>;
    subtreeCommonPrefixLength: number;
    node: BtreeNodeReference;
}
export interface BtreeNode {
    height: BtreeNodeHeight;
    keyPrefix: Uint8Array<ArrayBuffer>;
    entries: BtreeLeafNodeEntry[] | BtreeInteriorNodeEntry[];
    estimatedSize: number;
}
export type BtreeNodeHeight = number;
export interface BtreeNodeReference {
    location: IndirectDataReference;
    statistics: BtreeNodeStatistics;
}
export interface BtreeNodeStatistics {
    numIndirectValueBytes: bigint;
    numTreeBytes: bigint;
    numKeys: bigint;
}
export declare function decodeBtreeNode(buffer: ArrayBuffer, baseUrl: string, signal: AbortSignal): Promise<BtreeNode>;
export declare const readBtreeNodeReferences: import("#src/kvstore/ocdbt/decode_utils.js").ArrayReader<BtreeNodeReference, ReadIndirectDataReferenceOptions>;
export declare function validateBtreeNodeReference(node: BtreeNode, height: BtreeNodeHeight, inclusiveMinKey: Key): void;
export declare function findBtreeInteriorEntryLowerBound(entries: BtreeInteriorNodeEntry[], inclusiveMin: Key): number;
export declare function findBtreeLeafEntryLowerBound(entries: BtreeNode["entries"], inclusiveMin: Key): number;
export declare function findBtreeInteriorEntryPrefixRange(entries: BtreeInteriorNodeEntry[], prefix: Key): [number, number];
export declare function findBtreeEntryPrefixUpperBound(entries: BtreeNode["entries"], lower: number, upper: number, prefix: Key): number;
export declare function findBtreeLeafEntryPrefixRange(entries: BtreeLeafNodeEntry[], prefix: Key): [number, number];
export declare function findBtreeLeafEntry(entries: BtreeLeafNodeEntry[], key: Key): BtreeLeafNodeEntry | undefined;
export declare function findBtreeInteriorEntry(entries: BtreeInteriorNodeEntry[], key: Key): BtreeInteriorNodeEntry | undefined;
