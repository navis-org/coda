/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/kvstore/proxy.js";
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { DriverListOptions, DriverReadOptions, KvStore, ListResponse, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
import { type VersionSpecifier } from "#src/kvstore/ocdbt/version_specifier.js";
export declare class OcdbtKvStore implements KvStore {
    sharedKvStoreContext: SharedKvStoreContextCounterpart;
    baseUrl: string;
    version: VersionSpecifier | undefined;
    constructor(sharedKvStoreContext: SharedKvStoreContextCounterpart, baseUrl: string, version: VersionSpecifier | undefined);
    private root;
    private getRoot;
    getUrl(key: string): string;
    stat(key: string, options: StatOptions): Promise<StatResponse | undefined>;
    read(key: string, options: DriverReadOptions): Promise<ReadResponse | undefined>;
    list(prefix: string, options: DriverListOptions): Promise<ListResponse>;
    get supportsOffsetReads(): boolean;
    get supportsSuffixReads(): boolean;
}
