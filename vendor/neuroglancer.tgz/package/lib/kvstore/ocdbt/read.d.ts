/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { DriverReadOptions, ReadResponse } from "#src/kvstore/index.js";
import type { BtreeLeafNodeEntry, BtreeNodeHeight, BtreeNodeReference } from "#src/kvstore/ocdbt/btree.js";
import type { Key } from "#src/kvstore/ocdbt/key.js";
import type { BtreeGenerationReference } from "#src/kvstore/ocdbt/version_tree.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare function findEntryInRoot(sharedKvStoreContext: SharedKvStoreContextCounterpart, root: BtreeGenerationReference, key: Key, options: Partial<ProgressOptions>): Promise<BtreeLeafNodeEntry | undefined>;
export declare function readFromRoot(sharedKvStoreContext: SharedKvStoreContextCounterpart, root: BtreeGenerationReference, key: Key, options: DriverReadOptions): Promise<ReadResponse | undefined>;
export declare function findEntryInSubtree(sharedKvStoreContext: SharedKvStoreContextCounterpart, nodeReference: BtreeNodeReference, nodeHeight: BtreeNodeHeight, inclusiveMinKey: Key, queryKey: Key, options: Partial<ProgressOptions>): Promise<BtreeLeafNodeEntry | undefined>;
export declare function readFromLeafNodeEntry(sharedKvStoreContext: SharedKvStoreContextCounterpart, entry: BtreeLeafNodeEntry, options: DriverReadOptions): Promise<ReadResponse | undefined>;
