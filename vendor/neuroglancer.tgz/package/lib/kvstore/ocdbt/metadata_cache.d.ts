/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { BtreeNode } from "#src/kvstore/ocdbt/btree.js";
import type { DataFileId, IndirectDataReference } from "#src/kvstore/ocdbt/indirect_data_reference.js";
import type { Manifest, ManifestWithVersionTree } from "#src/kvstore/ocdbt/manifest.js";
import type { VersionTreeNode } from "#src/kvstore/ocdbt/version_tree.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare function getManifest(sharedKvStoreContext: SharedKvStoreContextCounterpart, dataFile: DataFileId, options: Partial<ProgressOptions>): Promise<Manifest>;
export declare function getResolvedManifest(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, options: Partial<ProgressOptions>): Promise<ManifestWithVersionTree>;
export declare function getBtreeNode(sharedKvStoreContext: SharedKvStoreContextCounterpart, location: IndirectDataReference, options: Partial<ProgressOptions>): Promise<BtreeNode>;
export declare function getVersionTreeNode(sharedKvStoreContext: SharedKvStoreContextCounterpart, location: IndirectDataReference, options: Partial<ProgressOptions>): Promise<VersionTreeNode>;
