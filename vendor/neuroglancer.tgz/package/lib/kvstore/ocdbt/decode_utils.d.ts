/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare enum CompressionMethod {
    UNCOMPRESSED = 0,
    ZSTD = 1
}
export declare function decodeEnvelope(buffer: ArrayBuffer, expectedMagic: number, maxVersion: number, signal: AbortSignal): Promise<{
    reader: Reader;
    version: number;
}>;
export interface Reader {
    offset: number;
    data: DataView<ArrayBuffer>;
}
export declare function readBytes(reader: Reader, count: number): Uint8Array<ArrayBuffer>;
export declare function readLeb128(reader: Reader): number;
export declare function readLeb128Bigint(reader: Reader): bigint;
export declare function readLeb128Bounded(reader: Reader, maxValue: number): number;
export declare function readUint8(reader: Reader): number;
export declare function readInt32le(reader: Reader): number;
export declare function readUint64le(reader: Reader): bigint;
export declare function ensureEof(reader: Reader): void;
export type ArrayReader<T, Options> = (reader: Reader, count: number, options: Options) => T[];
export declare function readArrayOf<T, Options>(readElement: (reader: Reader, options: Options) => T): ArrayReader<T, Options>;
type StructOfArrays<T> = {
    [Property in keyof T]: ArrayLike<T[Property]>;
} & Record<keyof T, ArrayLike<unknown>>;
type StructOfArrayReaders<T, Options> = Record<string, ArrayReader<unknown, Options>> & {
    [Property in keyof T]: ArrayReader<T[Property], Options>;
};
export declare function toArrayOfStructs<T>(count: number, arrays: StructOfArrays<T>): T[];
export declare function readStructOfArrays<T, Options extends object = object>(members: StructOfArrayReaders<T, Options>, validate?: (value: T, options: Options) => void): ArrayReader<T, Options>;
export {};
