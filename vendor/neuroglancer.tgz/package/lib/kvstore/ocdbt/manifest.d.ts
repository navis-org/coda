/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CompressionMethod } from "#src/kvstore/ocdbt/decode_utils.js";
import type { BtreeGenerationReference, GenerationIndex, VersionNodeReference, VersionTreeArityLog2 } from "#src/kvstore/ocdbt/version_tree.js";
export interface ManifestVersionTree {
    inlineVersions: BtreeGenerationReference[];
    versionTreeNodes: VersionNodeReference[];
    numGenerations: GenerationIndex;
}
export declare enum ManifestKind {
    single = 0,
    numbered = 1
}
export interface Config {
    uuid: Uint8Array<ArrayBuffer>;
    manifestKind: ManifestKind;
    maxInlineValueBytes: number;
    maxDecodedNodeBytes: number;
    versionTreeArityLog2: VersionTreeArityLog2;
    compressionMethod: CompressionMethod;
    zstdLevel?: number;
}
export interface Manifest {
    config: Config;
    versionTree?: ManifestVersionTree;
    estimatedSize: number;
}
export interface ManifestWithVersionTree extends Manifest {
    versionTree: ManifestVersionTree;
}
export declare function decodeManifest(buffer: ArrayBuffer, baseUrl: string, signal: AbortSignal): Promise<Manifest>;
