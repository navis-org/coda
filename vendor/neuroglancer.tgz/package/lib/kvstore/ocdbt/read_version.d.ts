/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { ManifestWithVersionTree } from "#src/kvstore/ocdbt/manifest.js";
import type { VersionSpecifier } from "#src/kvstore/ocdbt/version_specifier.js";
import type { BtreeGenerationReference, GenerationIndex, VersionQuery } from "#src/kvstore/ocdbt/version_tree.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare function getRoot(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, version: VersionSpecifier | undefined, options: Partial<ProgressOptions>): Promise<BtreeGenerationReference>;
export declare function readVersion(sharedKvStoreContext: SharedKvStoreContextCounterpart, manifest: ManifestWithVersionTree, version: VersionQuery | undefined, options: Partial<ProgressOptions>): Promise<{
    ref: BtreeGenerationReference;
    generationIndex: GenerationIndex;
} | undefined>;
export declare function findVersionIndexByLowerBound(sharedKvStoreContext: SharedKvStoreContextCounterpart, manifest: ManifestWithVersionTree, version: VersionSpecifier, options: Partial<ProgressOptions>): Promise<GenerationIndex>;
export declare function findVersionIndexByUpperBound(sharedKvStoreContext: SharedKvStoreContextCounterpart, manifest: ManifestWithVersionTree, version: VersionSpecifier, options: Partial<ProgressOptions>): Promise<GenerationIndex>;
