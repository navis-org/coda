/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CompletionResult } from "#src/kvstore/context.js";
import type { DriverListOptions, DriverReadOptions, ListResponse, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
import type { SharedKvStoreContextBase } from "#src/kvstore/register.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare function proxyStat(sharedKvStoreContext: SharedKvStoreContextBase, url: string, options: StatOptions): Promise<StatResponse | undefined>;
export declare function proxyRead(sharedKvStoreContext: SharedKvStoreContextBase, url: string, options: DriverReadOptions): Promise<ReadResponse | undefined>;
export declare function proxyList(sharedKvStoreContext: SharedKvStoreContextBase, url: string, options: DriverListOptions): Promise<ListResponse>;
export declare function proxyCompleteUrl(sharedKvStoreContext: SharedKvStoreContextBase, url: string, options: Partial<ProgressOptions>): Promise<CompletionResult>;
export declare abstract class ProxyReadableKvStore<Key> {
    sharedKvStoreContext: SharedKvStoreContextBase;
    constructor(sharedKvStoreContext: SharedKvStoreContextBase);
    abstract getUrl(key: Key): string;
    stat(key: Key, options: StatOptions): Promise<StatResponse | undefined>;
    read(key: Key, options: DriverReadOptions): Promise<ReadResponse | undefined>;
}
export declare abstract class ProxyKvStore extends ProxyReadableKvStore<string> {
    list(prefix: string, options: DriverListOptions): Promise<ListResponse>;
}
