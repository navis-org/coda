/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { MouseSelectionState } from "#src/layer/index.js";
import type { RenderLayer } from "#src/renderlayer.js";
export declare class PickIDManager {
    /**
     * This specifies the render layer corresponding to each registered entry.
     */
    private renderLayers;
    private pickData;
    /**
     * This contains 3 consecutive values, specifying (startPickID, low, high), for each registered
     * entry.  startPickID specifies the first uint32 pick ID corresponding to the entry.  low and
     * high specify two additional numbers associated with the entry.
     */
    private values;
    private nextPickID;
    clear(): void;
    registerUint64(renderLayer: RenderLayer, x: bigint, count?: number, data?: any): number;
    register(renderLayer: RenderLayer, count?: number, x?: bigint, data?: any): number;
    /**
     * Set the object state according to the specified pick ID.
     */
    setMouseState(mouseState: MouseSelectionState, pickID: number): void;
}
