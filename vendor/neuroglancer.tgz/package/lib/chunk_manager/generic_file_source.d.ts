/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file
 * Provides a simple way to request a file on the backend with priority integration.
 */
import type { ChunkManager } from "#src/chunk_manager/backend.js";
import { Chunk, ChunkSourceBase } from "#src/chunk_manager/backend.js";
import type { SharedKvStoreContextCounterpart } from "#src/kvstore/backend.js";
import type { ReadResponse } from "#src/kvstore/index.js";
import type { Owned } from "#src/util/disposable.js";
import type { AsyncMemoize } from "#src/util/memoize.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
declare class AsyncCacheChunk<Data> extends Chunk {
    asyncMemoize: AsyncMemoize<Data> | undefined;
    initialize(key: string): void;
    freeSystemMemory(): void;
}
export interface SimpleAsyncCacheOptions<Key, Value> {
    encodeKey?: (key: Key) => string;
    get: (key: Key, progressOptions: ProgressOptions) => Promise<{
        size: number;
        data: Value;
    }>;
}
export declare class SimpleAsyncCache<Key, Value> extends ChunkSourceBase {
    chunks: Map<string, AsyncCacheChunk<Value>>;
    constructor(chunkManager: Owned<ChunkManager>, options: SimpleAsyncCacheOptions<Key, Value>);
    encodeKeyFunction: (key: Key) => string;
    downloadFunction: (key: Key, progressOptions: ProgressOptions) => Promise<{
        size: number;
        data: Value;
    }>;
    get(key: Key, options: Partial<ProgressOptions>): Promise<Value>;
}
export declare function makeSimpleAsyncCache<Key, Data>(chunkManager: ChunkManager, memoizeKey: string, options: SimpleAsyncCacheOptions<Key, Data>): SimpleAsyncCache<Key, Data>;
export declare function getCachedDecodedUrl<Data>(sharedKvStoreContext: SharedKvStoreContextCounterpart, url: string, decodeFunction: (readResponse: ReadResponse, options: ProgressOptions) => Promise<{
    size: number;
    data: Data;
}>, options: Partial<ProgressOptions>): Promise<Data>;
export {};
