/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare enum ChunkState {
    GPU_MEMORY = 0,
    SYSTEM_MEMORY = 1,
    SYSTEM_MEMORY_WORKER = 2,
    DOWNLOADING = 3,
    QUEUED = 4,
    NEW = 5,
    FAILED = 6,
    EXPIRED = 7
}
export declare const numChunkStates = 8;
export declare enum ChunkPriorityTier {
    FIRST_TIER = 0,
    FIRST_ORDERED_TIER = 0,
    VISIBLE = 0,
    PREFETCH = 1,
    LAST_ORDERED_TIER = 1,
    RECENT = 2,
    LAST_TIER = 2
}
export declare const numChunkPriorityTiers = 3;
export declare enum ChunkDownloadStatistics {
    totalTime = 0,
    totalChunks = 1
}
export declare enum ChunkMemoryStatistics {
    numChunks = 0,
    systemMemoryBytes = 1,
    gpuMemoryBytes = 2
}
export declare const numChunkMemoryStatistics = 3;
export declare const numChunkDownloadStatistics = 2;
export declare const numChunkStatistics: number;
export declare function getChunkStateStatisticIndex(state: ChunkState, priorityTier: ChunkPriorityTier): number;
export declare function getChunkDownloadStatisticIndex(statistic: ChunkDownloadStatistics): number;
export declare const PREFETCH_PRIORITY_MULTIPLIER = 10000000000000;
export declare const CHUNK_QUEUE_MANAGER_RPC_ID = "ChunkQueueManager";
export declare const CHUNK_MANAGER_RPC_ID = "ChunkManager";
export declare const CHUNK_SOURCE_INVALIDATE_RPC_ID = "ChunkSource.invalidate";
export declare const REQUEST_CHUNK_STATISTICS_RPC_ID = "ChunkQueueManager.requestChunkStatistics";
export declare const CHUNK_LAYER_STATISTICS_RPC_ID = "ChunkManager.chunkLayerStatistics";
export interface ChunkSourceParametersConstructor<T> {
    new (): T;
    RPC_ID: string;
}
export declare class LayerChunkProgressInfo {
    numVisibleChunksNeeded: number;
    numVisibleChunksAvailable: number;
    numPrefetchChunksNeeded: number;
    numPrefetchChunksAvailable: number;
}
