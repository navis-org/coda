/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ProjectionParameters } from "#src/projection_parameters.js";
import type { MultiscaleVolumetricDataRenderLayer, TransformedSource } from "#src/sliceview/base.js";
import type { VolumeChunkSource } from "#src/sliceview/volume/base.js";
import type { vec3 } from "#src/util/geom.js";
export declare const VOLUME_RENDERING_RENDER_LAYER_RPC_ID = "volume_rendering/VolumeRenderingRenderLayer";
export declare const VOLUME_RENDERING_RENDER_LAYER_UPDATE_SOURCES_RPC_ID = "volume_rendering/VolumeRenderingRenderLayer/update";
export interface HistogramInformation {
    spatialScales: Map<number, number>;
    activeIndex: number;
}
export declare function getVolumeRenderingNearFarBounds(clippingPlanes: Float32Array, displayLowerBound: Float32Array, displayUpperBound: Float32Array): {
    near: number;
    far: number;
    adjustedNear: number;
    adjustedFar: number;
};
export declare function forEachVisibleVolumeRenderingChunk<RLayer extends MultiscaleVolumetricDataRenderLayer, Source extends VolumeChunkSource, Transformed extends TransformedSource<RLayer, Source>>(projectionParameters: ProjectionParameters, localPosition: Float32Array, volumeRenderingDepthSamples: number, transformedSources: readonly Transformed[], beginScale: (source: Transformed, index: number, physicalSpacing: number, optimalSamples: number, clippingPlanes: Float32Array, histogramInformation: HistogramInformation) => void, callback: (source: Transformed, index: number, positionInChunks: vec3) => void): void;
