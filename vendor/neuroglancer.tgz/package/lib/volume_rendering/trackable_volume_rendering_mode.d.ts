import { TrackableEnum } from "#src/util/trackable_enum.js";
import type { VolumeRenderingRenderLayer } from "#src/volume_rendering/volume_render_layer.js";
export declare enum VolumeRenderingModes {
    OFF = 0,
    ON = 1,
    MAX = 2,
    MIN = 3
}
export type TrackableVolumeRenderingModeValue = TrackableEnum<VolumeRenderingModes>;
export declare function trackableShaderModeValue(initialValue?: VolumeRenderingModes): TrackableEnum<VolumeRenderingModes>;
export declare function isProjectionMode(mode: VolumeRenderingModes): boolean;
export declare function isProjectionLayer(layer: VolumeRenderingRenderLayer): boolean;
