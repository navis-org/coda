/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/noselect.css";
import "#src/perspective_view/panel.css";
import type { DisplayContext } from "#src/display_context.js";
import type { VisibleRenderLayerTracker } from "#src/layer/index.js";
import type { PerspectiveViewRenderContext } from "#src/perspective_view/render_layer.js";
import { PerspectiveViewRenderLayer } from "#src/perspective_view/render_layer.js";
import type { FramePickingData, RenderedDataViewerState } from "#src/rendered_data_panel.js";
import { RenderedDataPanel } from "#src/rendered_data_panel.js";
import { DerivedProjectionParameters } from "#src/renderlayer.js";
import type { SliceView } from "#src/sliceview/frontend.js";
import { SliceViewRenderHelper } from "#src/sliceview/frontend.js";
import type { TrackableBoolean } from "#src/trackable_boolean.js";
import type { TrackableValue, WatchableValueInterface } from "#src/trackable_value.js";
import type { TrackableRGB } from "#src/util/color.js";
import type { Owned } from "#src/util/disposable.js";
import { vec3 } from "#src/util/geom.js";
import { WatchableMap } from "#src/util/watchable_map.js";
import { DepthStencilRenderbuffer, FramebufferConfiguration, OffscreenCopyHelper, TextureBuffer } from "#src/webgl/offscreen.js";
import type { ShaderBuilder } from "#src/webgl/shader.js";
import type { ScaleBarOptions } from "#src/widget/scale_bar.js";
import type { RPC } from "#src/worker_rpc.js";
export interface PerspectiveViewerState extends RenderedDataViewerState {
    wireFrame: WatchableValueInterface<boolean>;
    enableAdaptiveDownsampling: WatchableValueInterface<boolean>;
    orthographicProjection: TrackableBoolean;
    showSliceViews: TrackableBoolean;
    showScaleBar: TrackableBoolean;
    scaleBarOptions: TrackableValue<ScaleBarOptions>;
    showSliceViewsCheckbox?: boolean;
    crossSectionBackgroundColor: TrackableRGB;
    perspectiveViewBackgroundColor: TrackableRGB;
    hideCrossSectionBackground3D: TrackableBoolean;
    rpc: RPC;
}
export declare enum OffscreenTextures {
    COLOR = 0,
    Z = 1,
    PICK = 2,
    NUM_TEXTURES = 3
}
export declare const glsl_perspectivePanelEmit = "\nvoid emit(vec4 color, highp uint pickId) {\n  out_color = color;\n  float zValue = 1.0 - gl_FragCoord.z;\n  out_z = vec4(zValue, zValue, zValue, 1.0);\n  float pickIdFloat = float(pickId);\n  out_pickId = vec4(pickIdFloat, pickIdFloat, pickIdFloat, 1.0);\n}\n";
/**
 * http://jcgt.org/published/0002/02/09/paper.pdf
 * http://casual-effects.blogspot.com/2015/03/implemented-weighted-blended-order.html
 */
export declare const glsl_computeOITWeight = "\nfloat computeOITWeight(float alpha, float depth) {\n  float a = min(1.0, alpha) * 8.0 + 0.01;\n  float b = -depth * 0.95 + 1.0;\n  return a * a * a * b * b * b;\n}\n";
export declare const glsl_perspectivePanelEmitOIT: string[];
export declare function perspectivePanelEmit(builder: ShaderBuilder): void;
export declare function perspectivePanelEmitOIT(builder: ShaderBuilder): void;
export declare function maxProjectionEmit(builder: ShaderBuilder): void;
export declare class PerspectivePanel extends RenderedDataPanel {
    viewer: PerspectiveViewerState;
    sliceViewRenderHelper: SliceViewRenderHelper;
    projectionParameters: Owned<DerivedProjectionParameters>;
    protected visibleLayerTracker: Owned<VisibleRenderLayerTracker<PerspectivePanel, PerspectiveViewRenderLayer>>;
    private hasVolumeRendering;
    get rpc(): RPC;
    get rpcId(): number;
    get displayDimensionRenderInfo(): import("../navigation_state").WatchableDisplayDimensionRenderInfo;
    private frameRateCalculator;
    private isContinuousCameraMotionInProgress;
    get shouldDownsample(): boolean;
    /**
     * If boolean value is true, sliceView is shown unconditionally, regardless of the value of
     * this.viewer.showSliceViews.value.
     */
    sliceViews: WatchableMap<SliceView, boolean>;
    private axesLineHelper;
    protected offscreenFramebuffer: FramebufferConfiguration<TextureBuffer, DepthStencilRenderbuffer>;
    protected transparentConfiguration_: FramebufferConfiguration<TextureBuffer> | undefined;
    protected volumeRenderingConfiguration_: FramebufferConfiguration<TextureBuffer> | undefined;
    protected maxProjectionConfiguration_: FramebufferConfiguration<TextureBuffer> | undefined;
    protected maxProjectionPickConfiguration_: FramebufferConfiguration<TextureBuffer> | undefined;
    protected offscreenCopyHelper: OffscreenCopyHelper;
    protected transparencyCopyHelper: OffscreenCopyHelper;
    protected transparentToTransparentCopyHelper: OffscreenCopyHelper;
    protected maxProjectionColorCopyHelper: OffscreenCopyHelper;
    protected maxProjectionPickCopyHelper: OffscreenCopyHelper;
    protected maxProjectionToPickCopyHelper: OffscreenCopyHelper;
    private sharedObject;
    private scaleBars;
    flushBackendProjectionParameters(): void;
    constructor(context: DisplayContext, element: HTMLElement, viewer: PerspectiveViewerState);
    translateByViewportPixels(deltaX: number, deltaY: number): void;
    get navigationState(): import("../navigation_state").NavigationState<import("../navigation_state").TrackableZoomInterface>;
    ensureBoundsUpdated(): void;
    isReady(): boolean;
    disposed(): void;
    getDepthArray(): Float32Array | undefined;
    issuePickRequest(glWindowX: number, glWindowY: number, pickRadius: number): void;
    completePickRequest(glWindowX: number, glWindowY: number, data: Float32Array, pickingData: FramePickingData, pickRadius: number): void;
    translateDataPointByViewportPixels(out: vec3, orig: vec3, deltaX: number, deltaY: number): vec3;
    private get transparentConfiguration();
    private get volumeRenderingConfiguration();
    private get maxProjectionConfiguration();
    private get maxProjectionPickConfiguration();
    drawWithPicking(pickingData: FramePickingData): boolean;
    protected drawSliceViews(renderContext: PerspectiveViewRenderContext): void;
    protected drawAxisLines(): void;
    zoomByMouse(factor: number): void;
}
