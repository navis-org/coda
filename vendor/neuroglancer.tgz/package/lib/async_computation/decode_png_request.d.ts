export interface DecodedImage {
    width: number;
    height: number;
    numComponents: number;
    uint8Array: Uint8Array<ArrayBuffer>;
}
export declare const decodePng: import("#src/async_computation/index.js").AsyncComputationSpec<(data: Uint8Array<ArrayBuffer>, width: number | undefined, height: number | undefined, area: number | undefined, numComponents: number | undefined, bytesPerPixel: number, convertToGrayscale: boolean) => DecodedImage>;
