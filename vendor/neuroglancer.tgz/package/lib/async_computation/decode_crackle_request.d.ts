export declare const decodeCrackle: import("#src/async_computation/index.js").AsyncComputationSpec<(data: Uint8Array<ArrayBuffer>) => Uint8Array<ArrayBuffer>>;
