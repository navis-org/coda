/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { vec3 } from "#src/util/geom.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
export declare function trackableVec3(defaultValue?: vec3): TrackableVec3;
export declare class TrackableVec3 implements Trackable {
    private value_;
    defaultValue: vec3;
    get value(): vec3;
    set value(newValue: vec3);
    changed: NullarySignal;
    constructor(value_: vec3, defaultValue: vec3);
    toJSON(): string | undefined;
    restoreState(x: any): void;
    reset(): void;
}
