/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { FrameNumberCounter } from "#src/chunk_manager/frontend.js";
import { ChunkManager, ChunkQueueManager } from "#src/chunk_manager/frontend.js";
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import { RPC } from "#src/worker_rpc.js";
export declare class DataManagementContext extends RefCounted {
    gl: GL;
    frameNumberCounter: FrameNumberCounter;
    worker: Worker;
    chunkQueueManager: ChunkQueueManager;
    chunkManager: ChunkManager;
    get rpc(): RPC;
    constructor(gl: GL, frameNumberCounter: FrameNumberCounter);
}
