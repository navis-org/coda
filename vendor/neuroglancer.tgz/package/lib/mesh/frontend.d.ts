/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import { Chunk, ChunkSource } from "#src/chunk_manager/frontend.js";
import type { VisibleLayerInfo } from "#src/layer/index.js";
import type { EncodedMeshData, MultiscaleFragmentFormat } from "#src/mesh/base.js";
import { VertexPositionFormat } from "#src/mesh/base.js";
import type { MultiscaleMeshManifest } from "#src/mesh/multiscale.js";
import type { PerspectivePanel } from "#src/perspective_view/panel.js";
import type { PerspectiveViewReadyRenderContext, PerspectiveViewRenderContext } from "#src/perspective_view/render_layer.js";
import { PerspectiveViewRenderLayer } from "#src/perspective_view/render_layer.js";
import type { ThreeDimensionalRenderLayerAttachmentState } from "#src/renderlayer.js";
import type { SegmentationDisplayState3D } from "#src/segmentation_display_state/frontend.js";
import { SegmentationLayerSharedObject } from "#src/segmentation_display_state/frontend.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { Borrowed, RefCounted } from "#src/util/disposable.js";
import type { vec4 } from "#src/util/geom.js";
import { mat4 } from "#src/util/geom.js";
import { GLBuffer } from "#src/webgl/buffer.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderProgram } from "#src/webgl/shader.js";
import type { RPC } from "#src/worker_rpc.js";
/**
 * Javascript implementation of normal decoding, for debugging.
 */
export declare function decodeNormalOctahedronSnorm8(normals: Uint8Array): Float32Array<ArrayBuffer>;
export declare class MeshShaderManager {
    fragmentRelativeVertices: boolean;
    vertexPositionFormat: VertexPositionFormat;
    private tempLightVec;
    private vertexPositionHandler;
    constructor(fragmentRelativeVertices: boolean, vertexPositionFormat: VertexPositionFormat);
    beginLayer(gl: GL, shader: ShaderProgram, renderContext: PerspectiveViewRenderContext, displayState: MeshDisplayState): void;
    setColor(gl: GL, shader: ShaderProgram, color: vec4): void;
    setPickID(gl: GL, shader: ShaderProgram, pickID: number): void;
    beginModel(gl: GL, shader: ShaderProgram, renderContext: PerspectiveViewRenderContext, modelMat: mat4): void;
    drawFragmentHelper(gl: GL, shader: ShaderProgram, fragmentChunk: FragmentChunk | MultiscaleFragmentChunk, indexBegin: number, indexEnd: number): void;
    drawFragment(gl: GL, shader: ShaderProgram, fragmentChunk: FragmentChunk): void;
    drawMultiscaleFragment(gl: GL, shader: ShaderProgram, fragmentChunk: MultiscaleFragmentChunk, subChunkBegin: number, subChunkEnd: number): void;
    endLayer(gl: GL, shader: ShaderProgram): void;
    makeGetter(layer: RefCounted & {
        gl: GL;
        displayState: MeshDisplayState;
    }): import("#src/webgl/dynamic_shader.js").ParameterizedEmitterDependentShaderGetter<boolean, undefined>;
}
export interface MeshDisplayState extends SegmentationDisplayState3D {
    silhouetteRendering: WatchableValueInterface<number>;
}
export declare class MeshLayer extends PerspectiveViewRenderLayer<ThreeDimensionalRenderLayerAttachmentState> {
    chunkManager: ChunkManager;
    source: MeshSource;
    displayState: MeshDisplayState;
    protected meshShaderManager: MeshShaderManager;
    private getShader;
    backend: SegmentationLayerSharedObject;
    constructor(chunkManager: ChunkManager, source: MeshSource, displayState: MeshDisplayState);
    get isTransparent(): boolean;
    get transparentPickEnabled(): boolean;
    get gl(): GL;
    draw(renderContext: PerspectiveViewRenderContext, attachment: VisibleLayerInfo<PerspectivePanel, ThreeDimensionalRenderLayerAttachmentState>): void;
    isReady(): boolean;
    getObjectPosition(id: bigint, nearestTo: Float32Array): Float32Array | undefined;
}
export declare class ManifestChunk extends Chunk {
    fragmentIds: string[];
    constructor(source: MeshSource, x: any);
}
export declare class FragmentChunk extends Chunk {
    source: FragmentSource;
    vertexBuffer: GLBuffer;
    indexBuffer: GLBuffer;
    normalBuffer: GLBuffer;
    meshData: EncodedMeshData;
    constructor(source: FragmentSource, x: any);
    copyToGPU(gl: GL): void;
    freeGPUMemory(gl: GL): void;
}
export type MeshSourceOptions = object;
export declare class MeshSource extends ChunkSource {
    fragmentSource: FragmentSource;
    chunks: Map<string, ManifestChunk>;
    initializeCounterpart(rpc: RPC, options: any): void;
    getChunk(x: any): ManifestChunk;
    getFragmentKey(objectKey: string, fragmentId: string): {
        key: string;
        fragmentId: string;
    };
}
export declare class FragmentSource extends ChunkSource {
    meshSource: MeshSource;
    chunks: Map<string, FragmentChunk>;
    get key(): any;
    constructor(chunkManager: ChunkManager, meshSource: MeshSource);
    getChunk(x: any): FragmentChunk;
}
export declare class MultiscaleMeshLayer extends PerspectiveViewRenderLayer<ThreeDimensionalRenderLayerAttachmentState> {
    chunkManager: ChunkManager;
    source: MultiscaleMeshSource;
    displayState: MeshDisplayState;
    protected meshShaderManager: MeshShaderManager;
    private getShader;
    backend: SegmentationLayerSharedObject;
    constructor(chunkManager: ChunkManager, source: MultiscaleMeshSource, displayState: MeshDisplayState);
    get isTransparent(): boolean;
    get transparentPickEnabled(): boolean;
    get gl(): GL;
    draw(renderContext: PerspectiveViewRenderContext, attachment: VisibleLayerInfo<PerspectivePanel, ThreeDimensionalRenderLayerAttachmentState>): void;
    isReady(renderContext: PerspectiveViewReadyRenderContext, attachment: VisibleLayerInfo<PerspectivePanel, ThreeDimensionalRenderLayerAttachmentState>): boolean;
    getObjectPosition(id: bigint): Float32Array | undefined;
}
export declare class MultiscaleManifestChunk extends Chunk {
    manifest: MultiscaleMeshManifest;
    source: MultiscaleMeshSource;
    constructor(source: MultiscaleMeshSource, x: any);
}
export declare class MultiscaleFragmentChunk extends Chunk {
    meshData: EncodedMeshData & {
        subChunkOffsets: Uint32Array;
    };
    source: MultiscaleFragmentSource;
    vertexBuffer: GLBuffer;
    indexBuffer: GLBuffer;
    normalBuffer: GLBuffer;
    constructor(source: MultiscaleFragmentSource, x: any);
    copyToGPU(gl: GL): void;
    freeGPUMemory(gl: GL): void;
}
export interface MultiscaleMeshSourceOptions extends MeshSourceOptions {
    format: MultiscaleFragmentFormat;
}
export declare class MultiscaleMeshSource extends ChunkSource {
    OPTIONS: MultiscaleMeshSourceOptions;
    fragmentSource: MultiscaleFragmentSource;
    chunks: Map<string, MultiscaleManifestChunk>;
    format: MultiscaleFragmentFormat;
    constructor(chunkManager: Borrowed<ChunkManager>, options: MultiscaleMeshSourceOptions);
    static encodeOptions(options: MultiscaleMeshSourceOptions): {
        format: MultiscaleFragmentFormat;
    };
    initializeCounterpart(rpc: RPC, options: any): void;
    getChunk(x: any): MultiscaleManifestChunk;
}
export declare class MultiscaleFragmentSource extends ChunkSource {
    meshSource: MultiscaleMeshSource;
    chunks: Map<string, MultiscaleFragmentChunk>;
    get key(): any;
    constructor(chunkManager: ChunkManager, meshSource: MultiscaleMeshSource);
    getChunk(x: any): MultiscaleFragmentChunk;
}
