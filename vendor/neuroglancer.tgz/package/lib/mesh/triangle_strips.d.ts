/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { MeshVertexIndices } from "#src/mesh/base.js";
/**
 * Computes the edge index and flipped state in a triangle strip for the next edge after the given
 * edge.
 *
 * @param edgeIndexAndFlipped Bits 0,1 specify the `edgeIndex` in the range `[0, 2]` corresponding
 *     to the last edge that was traversed.  Bit 2 specifies the `flipped` state.  If `flipped` is
 *     equal to 0, the last two emitted vertices are B and C relative to `edgeIndex`.  If `flipped`
 *     is equal to 1, the last two emitted vertices are A and C relative to `edgeIndex`.
 * @returns The next `edgeIndexAndFlipped` value specifying `nextEdgeIndex` and `nextFlipped`.  If
 *     `flipped == 0`, `nextEdgeIndex` corresponds to the B-C edge relative to `edgeIndex`; if
 *     `flipped == 1`, `nextEdgeIndex` correspond to the A-C edge relative to `edgeIndex`.  The
 *     `nextFlipped` value is equal to 1 iff `vertexCIndex(edgeIndex) ==
 *     vertexAIndex(nextEdgeIndex)`.
 */
export declare function getNextEdge(edgeIndexAndFlipped: number): number;
export declare function getBaseIndex(entry: number): number;
export declare function getEdgeIndex(entry: number): number;
/**
 * Computes the first vertex offset for the given edge.
 *
 * @returns `[0, 0, 1][edgeIndex]`
 */
export declare function vertexAIndex(edgeIndex: number): number;
/**
 * Computes the second vertex offset for the given edge.
 *
 * @returns `[1, 2, 2][edgeIndex]`
 */
export declare function vertexBIndex(edgeIndex: number): number;
/**
 * Computes the opposite vertex offset for the given edge.
 *
 * @returns `[2, 1, 0][edgeIndex]`
 */
export declare function vertexCIndex(edgeIndex: number): number;
export declare function getEdgeMapSize(numIndices: number): number;
export declare function computeTriangleStrips<T extends MeshVertexIndices>(indices: T, subChunkOffsets?: Uint32Array): MeshVertexIndices;
