/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { mat4, vec3 } from "#src/util/geom.js";
export interface MultiscaleMeshManifest {
    /**
     * Size of finest-resolution (base) chunk in object coordinates.
     */
    chunkShape: vec3;
    /**
     * Starting corner position of (0, 0, 0) chunk in object coordinates.
     */
    chunkGridSpatialOrigin: vec3;
    /**
     * Axis-aligned bounding box lower bound of object in object coordinates to use for clipping and
     * level-of-detail calculations.
     */
    clipLowerBound: vec3;
    /**
     * Axis-aligned bounding box upper bound of object in object coordinates to use for clipping and
     * level-of-detail calculations.
     */
    clipUpperBound: vec3;
    /**
     * Specifies the number of levels of detail (as `lodScales.length`), and the resolution in object
     * coordinates for each level of detail.  If `lodScales[lod] === 0`, then level-of-detail `lod`
     * does not exist.
     *
     * Level of detail `0` is the finest resolution.
     *
     * The non-zero values must be non-decreasing.
     *
     * For each chunk, the chosen `lod` is the largest value such that
     * `lodScales[lod] <= detailCutoff * pixelSize`, where `pixelSize` is the maximum spatial distance
     * spanned by a single viewport pixel within the projected image of the chunk.
     */
    lodScales: Float32Array;
    /**
     * C order `[numLods, 3]` array specifying the xyz vertex position offset in object coordinates
     * for each level of detail.
     */
    vertexOffsets: Float32Array;
    /**
     * Row-major `[n, 5]` array where each row is of the form `[x, y, z, start, end_and_empty]`, where
     * `x`, `y`, and `z` are the chunk grid coordinates of the entry at a particular level of detail.
     * Row `n-1` corresponds to level of detail `lodScales.length - 1`, the root of the octree.  Given
     * a row corresponding to an octree node at level of detail `lod`, bits `start` specifies the row
     * number of the first child octree node at level of detail `lod-1`, and bits `[0,30]` of
     * `end_and_empty` specify one past the row number of the last child octree node.  Bit `31` of
     * `end_and_empty` is set to `1` if the mesh for the octree node is empty and should not be
     * requested/rendered.
     */
    octree: Uint32Array;
}
/**
 * @param detailCutoff Factor by which the spatial resolution of the mesh may be worse than the
 *     spatial resolution of a single viewport pixel.  For example, a value of 10 means that if a
 *     given portion of the object will be rendered such that a pixel corresponds to 50 nm, then a
 *     mesh level of detail down to 500 nm will be requested for that portion of the object.
 */
export declare function getDesiredMultiscaleMeshChunks(manifest: MultiscaleMeshManifest, modelViewProjection: mat4, clippingPlanes: Float32Array, detailCutoff: number, viewportWidth: number, viewportHeight: number, callback: (lod: number, row: number, renderScale: number, empty: number) => void): void;
export declare function getMultiscaleChunksToDraw(manifest: MultiscaleMeshManifest, modelViewProjection: mat4, clippingPlanes: Float32Array, detailCutoff: number, viewportWidth: number, viewportHeight: number, hasChunk: (lod: number, row: number, renderScale: number) => boolean, callback: (lod: number, row: number, subChunkBegin: number, subChunkEnd: number, renderScale: number) => void): void;
export declare function validateOctree(octree: Uint32Array): void;
export declare function getMultiscaleFragmentKey(objectKey: string, lod: number, chunkIndex: number): string;
