/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Borrowed, Disposable, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { NullaryReadonlySignal } from "#src/util/signal.js";
import { NullarySignal, Signal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
export interface WatchableValueInterface<T> {
    value: T;
    changed: NullaryReadonlySignal;
}
export interface WatchableValueChangeInterface<T> {
    readonly value: T;
    readonly changed: Signal<(oldValue: T, newValue: T) => void>;
}
export declare class WatchableValue<T> implements WatchableValueInterface<T> {
    protected value_: T;
    get value(): T;
    set value(newValue: T);
    changed: NullarySignal;
    constructor(value_: T);
}
export declare class TrackableValue<T> extends WatchableValue<T> implements Trackable {
    validator: (value: any) => T;
    defaultValue: T;
    constructor(value: T, validator: (value: any) => T, defaultValue?: T);
    toJSON(): any;
    reset(): void;
    restoreState(x: any): void;
}
declare class DerivedWatchableValue<U> extends RefCounted implements WatchableValueInterface<U> {
    changed: NullarySignal;
    get value(): U;
    private f;
    private ws;
    constructor(f: (...v: any[]) => U, ws: WatchableValueInterface<any>[]);
}
export declare function makeDerivedWatchableValue<U, T extends any[]>(f: (...v: T) => U, ...ws: {
    [K in keyof T]: WatchableValueInterface<T[K]>;
}): DerivedWatchableValue<U>;
declare class CachedLazyDerivedWatchableValue<U> extends RefCounted implements WatchableValueInterface<U> {
    changed: NullarySignal;
    private value_;
    private valueGeneration;
    get value(): U;
    private f;
    private ws;
    constructor(f: (...v: any[]) => U, ws: WatchableValueInterface<any>[]);
}
export declare function makeCachedLazyDerivedWatchableValue<U, T extends any[]>(f: (...v: T) => U, ...ws: {
    [K in keyof T]: WatchableValueInterface<T[K]>;
}): CachedLazyDerivedWatchableValue<U>;
export declare class CachedWatchableValue<T> extends RefCounted implements WatchableValueInterface<T> {
    changed: Signal<() => void>;
    value: T;
    constructor(base: WatchableValueInterface<T>, isEqual?: (a: T, b: T) => boolean);
}
export declare function makeCachedDerivedWatchableValue<U, T extends any[]>(f: (...v: T) => U, ws: {
    [K in keyof T]: WatchableValueInterface<T[K]>;
}, isEqual?: (a: U, b: U) => boolean): CachedWatchableValue<U>;
export declare class AggregateWatchableValue<T> extends RefCounted implements WatchableValueInterface<T> {
    changed: NullarySignal;
    value: T;
    constructor(getWatchables: (self: RefCounted) => {
        [k in keyof T]: WatchableValueInterface<T[k]>;
    });
}
export declare class ComputedWatchableValue<U> extends RefCounted implements WatchableValueInterface<U> {
    f: () => U;
    get value(): U;
    changed: NullarySignal;
    constructor(f: () => U, ...signals: NullarySignal[]);
}
export declare class WatchableRefCounted<T extends RefCounted> extends RefCounted implements WatchableValueInterface<T | undefined> {
    changed: NullarySignal;
    private value_;
    private valueHandler;
    get value(): Borrowed<T> | undefined;
    set value(value: Owned<T> | undefined);
    reset(): void;
    disposed(): void;
}
export interface TrackableValueInterface<T> extends WatchableValueInterface<T>, Trackable {
}
export declare class TrackableRefCounted<T extends RefCounted> extends WatchableRefCounted<T> implements TrackableValueInterface<T | undefined> {
    validator: (value: any) => T | undefined;
    jsonConverter: (value: T) => any;
    constructor(validator: (value: any) => T | undefined, jsonConverter: (value: T) => any);
    toJSON(): any;
    restoreState(x: any): void;
}
export declare class WatchableSet<T> {
    changed: Signal<(x: T | null, add: boolean) => void>;
    values: Set<T>;
    constructor(values?: Iterable<T>);
    add(x: T): this;
    delete(x: T): boolean;
    has(x: T): boolean;
    get size(): number;
    [Symbol.iterator](): SetIterator<T>;
    clear(): void;
}
export interface NestedStateManager<T = undefined> extends Disposable {
    flush: () => void;
    value: T;
}
export declare function registerNested<U, T extends any[]>(f: (context: RefCounted, ...values: T) => U, ...watchables: {
    [K in keyof T]: WatchableValueInterface<T[K]>;
}): NestedStateManager<U>;
export declare function registerNestedSync<U, T extends any[]>(f: (context: RefCounted, ...values: T) => U, ...watchables: {
    [K in keyof T]: WatchableValueInterface<T[K]>;
}): {
    readonly value: U;
    dispose(): void;
};
export declare function constantWatchableValue<T>(value: T): WatchableValueInterface<T>;
export declare function observeWatchable<T>(callback: (value: T) => void, watchable: WatchableValueInterface<T>): () => void;
export declare function linkWatchableValue<T>(source: WatchableValueInterface<T>, target: WatchableValueInterface<T>): () => void;
export declare class IndirectWatchableValue<U, T> implements Disposable, WatchableValueInterface<T> {
    private outer;
    private getInner;
    protected inner: WatchableValueInterface<T>;
    changed: NullarySignal;
    disposer: (() => void) | undefined;
    private update;
    constructor(outer: WatchableValueInterface<U>, getInner: (outer: U) => WatchableValueInterface<T>);
    dispose(): void;
    get value(): T;
    set value(value: T);
}
export declare class IndirectTrackableValue<U, T> extends IndirectWatchableValue<U, T> implements Trackable {
    inner: TrackableValueInterface<T>;
    reset(): void;
    restoreState(obj: unknown): void;
    toJSON(): any;
}
/**
 * A WatchableValue that only updates its value and dispatches change notifications
 * when the enableWatchable is true. When the enableWatchable is false, the last
 * value is retained.
 * This essentially allows "pausing" of a WatchableValue.
 */
export declare class ConditionalWatchableValue<T> extends RefCounted implements WatchableValueInterface<T> {
    private valueWatchable;
    private enableWatchable;
    changed: NullarySignal;
    private lastValue;
    constructor(valueWatchable: WatchableValueInterface<T>, enableWatchable: WatchableValueInterface<boolean>);
    get value(): T;
}
export {};
