/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/help/input_event_bindings.css";
import type { LayerManager } from "#src/layer/index.js";
import type { SidePanelManager } from "#src/ui/side_panel.js";
import { SidePanel } from "#src/ui/side_panel.js";
import { TrackableSidePanelLocation } from "#src/ui/side_panel_location.js";
import type { GlobalToolBinder } from "#src/ui/tool.js";
import { type EventActionMap } from "#src/util/event_action_map.js";
export declare class HelpPanelState {
    location: TrackableSidePanelLocation;
    get changed(): import("../util/signal").Signal<() => void>;
    toJSON(): any;
    reset(): void;
    restoreState(obj: unknown): void;
}
export declare class InputEventBindingHelpDialog extends SidePanel {
    private bindings;
    private toolBinder;
    scroll: HTMLDivElement;
    constructor(sidePanelManager: SidePanelManager, state: HelpPanelState, bindings: Iterable<[string, EventActionMap]>, layerManager: LayerManager, toolBinder: GlobalToolBinder);
    private updateView;
}
