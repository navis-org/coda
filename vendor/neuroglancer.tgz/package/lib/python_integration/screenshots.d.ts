/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { TrackableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import { Signal } from "#src/util/signal.js";
import type { ResolutionMetadata } from "#src/util/viewer_resolution_stats.js";
import type { Viewer } from "#src/viewer.js";
export interface ScreenshotResult {
    id: string;
    image: string;
    imageType: string;
    depthData: string | undefined;
    width: number;
    height: number;
    resolutionMetadata: ResolutionMetadata;
}
export interface ScreenshotActionState {
    viewerState: any;
    selectedValues: any;
    screenshot: ScreenshotResult;
}
export interface ScreenshotChunkStatistics {
    downloadLatency: number;
    visibleChunksDownloading: number;
    visibleChunksFailed: number;
    visibleChunksGpuMemory: number;
    visibleChunksSystemMemory: number;
    visibleChunksTotal: number;
    visibleGpuMemory: number;
}
export interface StatisticsActionState {
    viewerState: any;
    selectedValues: any;
    screenshotStatistics: {
        id: string;
        chunkSources: any[];
        total: ScreenshotChunkStatistics;
    };
}
export declare class ScreenshotHandler extends RefCounted {
    viewer: Viewer;
    sendScreenshotRequested: Signal<(state: ScreenshotActionState) => void>;
    sendStatisticsRequested: Signal<(state: StatisticsActionState) => void>;
    requestState: TrackableValue<string | undefined>;
    /**
     * To reduce the risk of taking a screenshot while deferred code is still registering layers,
     * require that the viewer be in a ready state once, and still remain ready while all pending
     * events are handled, before a screenshot is taken.
     */
    private wasAlreadyVisible;
    private previousRequest;
    private debouncedMaybeSendScreenshot;
    private statisticsRequested;
    private throttledSendStatistics;
    constructor(viewer: Viewer);
    private maybeSendScreenshot;
}
