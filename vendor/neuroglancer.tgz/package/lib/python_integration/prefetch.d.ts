/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DataManagementContext } from "#src/data_management_context.js";
import type { DataSourceRegistry } from "#src/datasource/index.js";
import type { DisplayContext } from "#src/display_context.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal } from "#src/util/signal.js";
import type { ViewerUIConfiguration } from "#src/viewer.js";
import { Viewer } from "#src/viewer.js";
export declare class PrefetchManager extends RefCounted {
    display: Borrowed<DisplayContext>;
    dataSourceProvider: DataSourceRegistry;
    dataContext: Owned<DataManagementContext>;
    uiConfiguration: ViewerUIConfiguration;
    prefetchStates: Map<string, Viewer>;
    changed: NullarySignal;
    private specification;
    constructor(display: Borrowed<DisplayContext>, dataSourceProvider: DataSourceRegistry, dataContext: Owned<DataManagementContext>, uiConfiguration: ViewerUIConfiguration);
    private updatePrefetchStates;
    private makePrefetchState;
    reset(): void;
    restoreState(obj: any): void;
    toJSON(): {
        state: any;
        priority: number;
    }[] | undefined;
}
