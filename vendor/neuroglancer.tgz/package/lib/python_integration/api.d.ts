/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { StatusMessage } from "#src/status.js";
import { RefCounted } from "#src/util/disposable.js";
import type { Trackable } from "#src/util/trackable.js";
export declare class ClientStateSynchronizer extends RefCounted {
    client: Client;
    state: Trackable;
    clientGeneration: number;
    lastServerState: string;
    lastServerGeneration: string;
    private needUpdate;
    private updateInProgress;
    constructor(client: Client, state: Trackable, updateDelayMilliseconds: number | null);
    private handleStateChanged;
    setServerState(state: any, generation: string): void;
}
export declare class ClientStateReceiver extends RefCounted {
    client: Client;
    states: Map<string, ClientStateSynchronizer>;
    private numConnectionFailures;
    status: StatusMessage;
    waitingToReconnect: number;
    eventSource: EventSource | undefined;
    constructor(client: Client, states: Map<string, ClientStateSynchronizer>);
    disposed(): void;
    connect(): void;
}
export declare class Client {
    urls: {
        socket: string;
        action: string;
        volumeInfo: string;
        events: string;
        state: string;
        credentials: string;
    };
    clientId: string;
    sendActionNotification(action: string, state: any): void;
    sendVolumeInfoNotification(requestId: string, info: any): void;
    sendVolumeChunkNotification(requestId: string, info: any): void;
}
