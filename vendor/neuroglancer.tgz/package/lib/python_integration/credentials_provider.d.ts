/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Implementation of a CredentialsProvider based on an input and output TrackableValue.
 */
import type { CredentialsManager, CredentialsWithGeneration } from "#src/credentials_provider/index.js";
import { AnonymousFirstCredentialsProvider, CredentialsProvider } from "#src/credentials_provider/index.js";
import type { Client } from "#src/python_integration/api.js";
declare class PythonCredentialsProvider<Credentials> extends CredentialsProvider<Credentials> {
    private client;
    private key;
    private parameters;
    constructor(client: Client, key: string, parameters: any);
    get: (invalidCredentials?: CredentialsWithGeneration<Credentials> | undefined, options?: Partial<import("../util/progress_listener").ProgressOptions>) => Promise<CredentialsWithGeneration<Credentials>>;
}
declare class GcsCredentialsProvider extends AnonymousFirstCredentialsProvider<any> {
    constructor(baseProvider: CredentialsProvider<any>);
}
export declare class PythonCredentialsManager implements CredentialsManager {
    private client;
    constructor(client: Client);
    private memoize;
    getCredentialsProvider<Credentials>(key: string, parameters?: any): GcsCredentialsProvider | PythonCredentialsProvider<Credentials>;
}
export {};
