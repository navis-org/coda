/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facility for sharing arbitrary values that support structural cloning between threads.
 */
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { RPC } from "#src/worker_rpc.js";
import { SharedObjectCounterpart } from "#src/worker_rpc.js";
export declare class SharedWatchableValue<T> extends SharedObjectCounterpart implements WatchableValueInterface<T> {
    base: WatchableValueInterface<T>;
    /**
     * The value is being updated to reflect a remote change.
     * @internal
     */
    updatingValue_: boolean;
    constructor(rpc?: RPC, options?: any);
    initializeCounterpart(rpc: RPC, options?: any): void;
    private setupChangedHandler;
    static makeFromExisting<T>(rpc: RPC, base: WatchableValueInterface<T>): SharedWatchableValue<T>;
    static make<T>(rpc: RPC, value: T): SharedWatchableValue<T>;
    get value(): T;
    set value(value: T);
    get changed(): import("./util/signal").NullaryReadonlySignal;
}
