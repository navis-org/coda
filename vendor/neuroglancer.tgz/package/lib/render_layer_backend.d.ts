/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { ChunkRenderLayerBackend } from "#src/chunk_manager/backend.js";
import type { ProjectionParameters } from "#src/projection_parameters.js";
import type { WatchableValueChangeInterface, WatchableValueInterface } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import { Signal } from "#src/util/signal.js";
import type { RPC } from "#src/worker_rpc.js";
import { SharedObjectCounterpart } from "#src/worker_rpc.js";
export interface RenderedViewBackend {
    visibility: WatchableValueInterface<number>;
    projectionParameters: WatchableValueInterface<ProjectionParameters>;
}
export declare class RenderLayerBackendAttachment<ViewBackend extends RenderedViewBackend = RenderedViewBackend, AttachmentState = unknown> extends RefCounted {
    view: ViewBackend;
    state: AttachmentState | undefined;
    constructor(view: ViewBackend);
}
export declare class RenderLayerBackend<ViewBackend extends RenderedViewBackend = RenderedViewBackend, AttachmentState = unknown> extends ChunkRenderLayerBackend {
    attachments: Map<ViewBackend, RenderLayerBackendAttachment<RenderedViewBackend, unknown>>;
    attach(attachment: RenderLayerBackendAttachment<ViewBackend, AttachmentState>): void;
}
export declare class SharedProjectionParametersBackend<T extends ProjectionParameters = ProjectionParameters> extends SharedObjectCounterpart implements WatchableValueChangeInterface<T> {
    value: T;
    oldValue: T;
    changed: Signal<(oldValue: T, newValue: T) => void>;
    constructor(rpc: RPC, options: any);
}
