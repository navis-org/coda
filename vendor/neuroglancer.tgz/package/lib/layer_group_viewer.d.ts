/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Viewer for a group of layers.
 */
import "#src/layer_group_viewer.css";
import type { InputEventBindings as DataPanelInputEventBindings } from "#src/data_panel_layout.js";
import { DataPanelLayoutContainer } from "#src/data_panel_layout.js";
import type { DisplayContext } from "#src/display_context.js";
import type { LayerListSpecification, MouseSelectionState, SelectedLayerState } from "#src/layer/index.js";
import type { CoordinateSpacePlaybackVelocity, TrackableCrossSectionZoom, TrackableProjectionZoom } from "#src/navigation_state.js";
import { LinkedCoordinateSpacePlaybackVelocity, LinkedDepthRange, LinkedDisplayDimensions, LinkedOrientationState, LinkedPosition, LinkedRelativeDisplayScales, LinkedZoomState, NavigationState, WatchableDisplayDimensionRenderInfo } from "#src/navigation_state.js";
import type { RenderLayerRole } from "#src/renderlayer.js";
import { TrackableBoolean } from "#src/trackable_boolean.js";
import type { TrackableValue, WatchableSet, WatchableValueInterface } from "#src/trackable_value.js";
import { LayerBar } from "#src/ui/layer_bar.js";
import { LocalToolBinder } from "#src/ui/tool.js";
import type { TrackableRGB } from "#src/util/color.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import { CompoundTrackable } from "#src/util/trackable.js";
import type { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
import type { TrackableScaleBarOptions } from "#src/widget/scale_bar.js";
export interface LayerGroupViewerState {
    display: Borrowed<DisplayContext>;
    navigationState: Owned<NavigationState>;
    perspectiveNavigationState: Owned<NavigationState>;
    velocity: Owned<CoordinateSpacePlaybackVelocity>;
    mouseState: MouseSelectionState;
    showAxisLines: TrackableBoolean;
    wireFrame: TrackableBoolean;
    enableAdaptiveDownsampling: TrackableBoolean;
    showScaleBar: TrackableBoolean;
    scaleBarOptions: TrackableScaleBarOptions;
    showPerspectiveSliceViews: TrackableBoolean;
    layerSpecification: Owned<LayerListSpecification>;
    inputEventBindings: DataPanelInputEventBindings;
    visibility: WatchableVisibilityPriority;
    selectedLayer: SelectedLayerState;
    visibleLayerRoles: WatchableSet<RenderLayerRole>;
    crossSectionBackgroundColor: TrackableRGB;
    perspectiveViewBackgroundColor: TrackableRGB;
    hideCrossSectionBackground3D: TrackableBoolean;
    pickRadius: TrackableValue<number>;
}
export interface LayerGroupViewerOptions {
    showLayerPanel: WatchableValueInterface<boolean>;
    showViewerMenu: boolean;
    showLayerHoverValues: WatchableValueInterface<boolean>;
    showAllPlotBounds?: WatchableValueInterface<boolean>;
}
export declare const viewerDragType = "neuroglancer-layer-group-viewer";
export declare function hasViewerDrag(event: DragEvent): boolean;
export declare function getCompatibleViewerDragSource(manager: Borrowed<LayerListSpecification>): LayerGroupViewer | undefined;
export declare function getViewerDropEffect(event: DragEvent, manager: Borrowed<LayerListSpecification>): {
    dropEffect: "move" | "copy";
    dropEffectMessage: string;
};
export declare class LinkedViewerNavigationState extends RefCounted {
    position: LinkedPosition;
    velocity: LinkedCoordinateSpacePlaybackVelocity;
    relativeDisplayScales: LinkedRelativeDisplayScales;
    displayDimensions: LinkedDisplayDimensions;
    displayDimensionRenderInfo: WatchableDisplayDimensionRenderInfo;
    crossSectionOrientation: LinkedOrientationState;
    crossSectionScale: LinkedZoomState<TrackableCrossSectionZoom>;
    projectionOrientation: LinkedOrientationState;
    projectionScale: LinkedZoomState<TrackableProjectionZoom>;
    crossSectionDepthRange: LinkedDepthRange;
    projectionDepthRange: LinkedDepthRange;
    navigationState: NavigationState;
    projectionNavigationState: NavigationState;
    constructor(parent: {
        navigationState: Borrowed<NavigationState>;
        velocity: Borrowed<CoordinateSpacePlaybackVelocity>;
        perspectiveNavigationState: Borrowed<NavigationState>;
    });
    copyToParent(): void;
    register(state: CompoundTrackable): void;
}
export declare class LayerGroupViewer extends RefCounted {
    element: HTMLElement;
    viewerState: LayerGroupViewerState;
    layerSpecification: LayerListSpecification;
    viewerNavigationState: LinkedViewerNavigationState;
    get perspectiveNavigationState(): NavigationState<import("#src/navigation_state.js").TrackableZoomInterface>;
    get navigationState(): NavigationState<import("#src/navigation_state.js").TrackableZoomInterface>;
    get selectionDetailsState(): import("#src/layer/index.js").TrackableDataSelectionState;
    get display(): DisplayContext;
    get selectedLayer(): SelectedLayerState;
    get layerManager(): import("#src/layer/index.js").LayerManager;
    get chunkManager(): import("./chunk_manager/frontend").ChunkManager;
    get mouseState(): MouseSelectionState;
    get showAxisLines(): TrackableBoolean;
    get wireFrame(): TrackableBoolean;
    get enableAdaptiveDownsampling(): TrackableBoolean;
    get hideCrossSectionBackground3D(): TrackableBoolean;
    get showScaleBar(): TrackableBoolean;
    get showPerspectiveSliceViews(): TrackableBoolean;
    get inputEventBindings(): DataPanelInputEventBindings;
    get visibility(): WatchableVisibilityPriority;
    get pickRadius(): TrackableValue<number>;
    get visibleLayerRoles(): WatchableSet<RenderLayerRole>;
    get crossSectionBackgroundColor(): TrackableRGB;
    get perspectiveViewBackgroundColor(): TrackableRGB;
    get scaleBarOptions(): TrackableScaleBarOptions;
    layerPanel: LayerBar | undefined;
    layout: DataPanelLayoutContainer;
    toolBinder: LocalToolBinder<this>;
    options: LayerGroupViewerOptions;
    state: CompoundTrackable;
    get changed(): import("./util/signal").NullarySignal;
    constructor(element: HTMLElement, viewerState: LayerGroupViewerState, options?: Partial<LayerGroupViewerOptions>);
    bindAction(action: string, handler: () => void): void;
    private registerActionBindings;
    toJSON(): any;
    reset(): void;
    restoreState(obj: unknown): void;
    private makeUI;
    private updateUI;
    disposed(): void;
}
