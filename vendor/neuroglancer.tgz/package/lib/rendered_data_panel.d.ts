/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/rendered_data_panel.css";
import "#src/noselect.css";
import type { DisplayContext } from "#src/display_context.js";
import { RenderedPanel } from "#src/display_context.js";
import type { NavigationState } from "#src/navigation_state.js";
import { PickIDManager } from "#src/object_picking.js";
import type { TrackableValue } from "#src/trackable_value.js";
import type { Borrowed } from "#src/util/disposable.js";
import type { EventActionMap } from "#src/util/event_action_map.js";
import { mat4, vec3 } from "#src/util/geom.js";
import type { ViewerState } from "#src/viewer_state.js";
export interface RenderedDataViewerState extends ViewerState {
    inputEventMap: EventActionMap;
    pickRadius: TrackableValue<number>;
}
export declare class FramePickingData {
    pickIDs: PickIDManager;
    viewportWidth: number;
    viewportHeight: number;
    invTransform: mat4;
    frameNumber: number;
}
export declare class PickRequest {
    buffer: WebGLBuffer | null;
    glWindowX: number;
    glWindowY: number;
    frameNumber: number;
    sync: WebGLSync | null;
    pickRadius: number;
}
export declare abstract class RenderedDataPanel extends RenderedPanel {
    viewer: RenderedDataViewerState;
    /**
     * Current mouse position within the viewport, or -1 if the mouse is not in the viewport.
     */
    mouseX: number;
    mouseY: number;
    /**
     * If `false`, either the mouse is not within the viewport, or a picking request was already
     * issued for the current mouseX and mouseY after the most recent frame was rendered; when the
     * current pick requests complete, no additional pick requests will be issued.
     *
     * If `true`, a picking request was not issued for the current mouseX and mouseY due to all pick
     * buffers being in use; when a pick buffer becomes available, an additional pick request will be
     * issued.
     */
    pickRequestPending: boolean;
    private mouseStateForcer;
    protected isMovingToMousePosition: boolean;
    inputEventMap: EventActionMap;
    abstract navigationState: NavigationState;
    pickingData: FramePickingData[];
    pickRequests: PickRequest[];
    pickBufferContents: Float32Array | undefined;
    /**
     * Reads pick data for the current mouse position into the currently-bound pixel pack buffer.
     */
    abstract issuePickRequest(glWindowX: number, glWindowY: number, pickRadius: number): void;
    /**
     * Timer id for checking if outstanding pick requests have completed.
     */
    private pickTimerId;
    private cancelPickRequests;
    private issuePickRequestInternal;
    abstract completePickRequest(glWindowX: number, glWindowY: number, data: Float32Array, pickingData: FramePickingData, pickRadius: number): void;
    private completePickInternal;
    private scheduleCheckForPickRequestCompletion;
    private checkForPickRequestCompletion;
    private blockOnPickRequest;
    draw(): void;
    abstract drawWithPicking(pickingData: FramePickingData): boolean;
    private nextPickRequestTime;
    private pendingPickRequestTimerId;
    private pendingPickRequestTimerExpired;
    private canIssuePickRequest;
    private attemptToIssuePickRequest;
    /**
     * Called each time the mouse position relative to the top level of the rendered viewport changes.
     */
    private updateMousePosition;
    protected isMovingToMousePositionOnPick: boolean;
    constructor(context: Borrowed<DisplayContext>, element: HTMLElement, viewer: RenderedDataViewerState);
    abstract translateDataPointByViewportPixels(out: vec3, orig: vec3, deltaX: number, deltaY: number): vec3;
    onMouseout(): void;
    abstract translateByViewportPixels(deltaX: number, deltaY: number): void;
    handleMouseMove(clientX: number, clientY: number): void;
    onMousemove(event: MouseEvent, atOnly?: boolean): void;
    onTouchstart(event: TouchEvent): void;
    disposed(): void;
    abstract zoomByMouse(factor: number): void;
}
