/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Facilities for endianness detection and swapping.
 */
export declare enum Endianness {
    LITTLE = 0,
    BIG = 1
}
export declare function determineEndianness(): Endianness;
/**
 * The native endianness of the runtime.
 */
export declare const ENDIANNESS: Endianness;
/**
 * Swaps the endianness of an array assumed to contain 16-bit values.
 */
export declare function swapEndian16(array: ArrayBufferView): void;
/**
 * Swaps the endianness of an array assumed to contain 32-bit values.
 */
export declare function swapEndian32(array: ArrayBufferView): void;
export declare function swapEndian64(array: ArrayBufferView): void;
/**
 * Converts the endianness of an array assumed to contain 16-bit values from source to target.
 *
 * This does nothing if source === target.
 */
export declare function convertEndian16(array: ArrayBufferView, source: Endianness, target?: Endianness): void;
/**
 * Converts the endianness of an array assumed to contain 32-bit values from source to target.
 *
 * This does nothing if source === target.
 */
export declare function convertEndian32(array: ArrayBufferView, source: Endianness, target?: Endianness): void;
/**
 * Converts the endianness of an array assumed to contain 64-bit values from source to target.
 *
 * This does nothing if source === target.
 */
export declare function convertEndian64(array: ArrayBufferView, source: Endianness, target?: Endianness): void;
export declare function convertEndian(array: ArrayBufferView, source: Endianness, elementBytes: number, target?: Endianness): void;
