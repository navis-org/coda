/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { mat3, mat4, quat, vec3, vec4 } from "gl-matrix";
import type { TypedNumberArray } from "#src/util/array.js";
export { mat2, mat3, mat4, quat, vec2, vec3, vec4 } from "gl-matrix";
export declare const identityMat4: mat4;
export declare const AXES_NAMES: string[];
export declare const kAxes: vec3[];
export declare const kZeroVec: vec3;
export declare const kZeroVec4: vec4;
export declare const kOneVec: vec3;
export declare const kInfinityVec: vec3;
export declare const kIdentityQuat: quat;
export interface OrientedSliceScales {
    width: {
        scale: number;
        unit: string;
    };
    height: {
        scale: number;
        unit: string;
    };
}
export declare function prod3(x: ArrayLike<number>): number;
export declare function prod4(x: ArrayLike<number>): number;
/**
 * Implements a one-to-one conversion from Vec3 to string, suitable for use a Map key.
 *
 * Specifically, returns the string representation of the 3 values separated by commas.
 */
export declare function vec3Key(x: ArrayLike<number>): string;
/**
 * Transforms `a` by a 180-degree rotation about X, stores result in `out`.
 */
export declare function quatRotateX180(out: quat, a: quat): void;
/**
 * Transforms `a` by a 180-degree rotation about Y, stores result in `out`.
 */
export declare function quatRotateY180(out: quat, a: quat): void;
/**
 * Transforms `a` by a 180-degree rotation about Z, stores result in `out`.
 */
export declare function quatRotateZ180(out: quat, a: quat): void;
/**
 * Transforms a vector `a` by a homogenous transformation matrix `m`.  The translation component of
 * `m` is ignored.
 */
export declare function transformVectorByMat4(out: vec3, a: vec3, m: mat4): vec3;
/**
 * Transforms a vector `a` by the transpose of a homogenous transformation matrix `m`.  The
 * translation component of `m` is ignored.
 */
export declare function transformVectorByMat4Transpose(out: vec3, a: vec3, m: mat4): vec3;
export declare function translationRotationScaleZReflectionToMat4(out: mat4, translation: vec3, rotation: quat, scale: vec3, zReflection: number): mat4;
/**
 * Returns the value of `t` that minimizes `(p - (a + t * (b - a)))`.
 */
export declare function findClosestParameterizedLinePosition(a: Float32Array, b: Float32Array, p: Float32Array): number;
/**
 * Sets `out` to the position on the line segment `[a, b]` closest to `p`.
 */
export declare function projectPointToLineSegment(out: Float32Array, a: Float32Array, b: Float32Array, p: Float32Array): Float32Array<ArrayBufferLike>;
export declare function mat3FromMat4(out: mat3, m: mat4): mat3;
/**
 * Extracts the left, right, bottom, top, near, far clipping planes from `projectionMat`.
 * @param out Row-major array of shape `(6, 4)` specifying for each of the left, right, bottom, top,
 *     near, far clipping planes the `a`, `b`, `c`, `d` coefficients such that
 *     `0 < a * x + b * y + c * z + d` if the point `x, y, z` is inside the half-space of the
 * clipping plane.
 * @param m Projection matrix
 */
export declare function getFrustumPlanes(out: Float32Array, m: mat4): Float32Array;
/**
 * Checks whether the specified axis-aligned bounding box (AABB) intersects the view frustum.
 *
 * @param clippingPlanes Array of length 24 specifying the clipping planes of the view frustum, as
 *     computed by `getFrustumPlanes`
 */
export declare function isAABBVisible(xLower: number, yLower: number, zLower: number, xUpper: number, yUpper: number, zUpper: number, clippingPlanes: Float32Array): boolean;
export declare function isAABBIntersectingPlane(xLower: number, yLower: number, zLower: number, xUpper: number, yUpper: number, zUpper: number, clippingPlanes: Float32Array): boolean;
/**
 * Returns the list (in sorted order) of input dimensions that depend on any of the specified output
 * dimensions.
 */
export declare function getDependentTransformInputDimensions(transform: Float32Array | Float64Array, rank: number, outputDimensions: readonly number[], transpose?: boolean): number[];
export declare function scaleMat3Input(out: mat3, input: mat3, scales: TypedNumberArray): mat3;
export declare function scaleMat3Output(out: mat3, input: mat3, scales: TypedNumberArray): mat3;
export declare function getViewFrustumVolume(projectionMat: mat4): number;
export declare function getViewFrustumDepthRange(projectionMat: mat4): number;
export declare function disableZProjection(mat: mat4): mat4;
export declare function getViewFrustumWorldBounds(invViewProjectionMat: mat4, bounds: Float32Array): void;
export declare function calculateOrientedSliceScales(orientation: quat | undefined, scales: vec3, units: readonly string[], tolerance?: number): OrientedSliceScales | null;
