/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export type ProgressSpanId = number;
export interface ProgressSpanOptions {
    message: string;
    startTime?: number;
    id?: ProgressSpanId;
}
export declare class ProgressSpan implements Disposable {
    listener: ProgressListener;
    id: ProgressSpanId;
    startTime: number;
    message: string;
    constructor(listener: ProgressListener, options: ProgressSpanOptions);
    [Symbol.dispose](): void;
}
export interface ProgressListener {
    addSpan(span: ProgressSpan): void;
    removeSpan(spanId: ProgressSpanId): void;
}
export declare class MultiSet<T> {
    private items;
    add(item: T): number;
    delete(item: T): number;
    has(item: T): boolean;
    keys(): MapIterator<T>;
    entries(): MapIterator<[T, number]>;
    [Symbol.iterator](): MapIterator<T>;
}
export declare class KeyedMultiSet<T, Key> {
    private getKey;
    private items;
    constructor(getKey: (value: T) => Key);
    add(item: T): number;
    delete(item: T): number;
    deleteKey(key: Key): number;
    has(item: T): boolean;
    [Symbol.iterator](): Generator<T, void, unknown>;
}
export declare class ProgressSpanSet extends KeyedMultiSet<ProgressSpan, number> {
    constructor();
}
export declare class MultiConsumerProgressListener implements ProgressListener {
    private spans;
    private listeners;
    addSpan(span: ProgressSpan): void;
    removeSpan(spanId: ProgressSpanId): void;
    addListener(listener: ProgressListener | undefined): void;
    removeListener(listener: ProgressListener | undefined): void;
}
export interface ProgressOptions {
    signal: AbortSignal;
    progressListener: ProgressListener;
}
