/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facilities for converting between strings and RGB/RGBA colors.
 */
import { WatchableValue } from "#src/trackable_value.js";
import { vec3, vec4 } from "#src/util/geom.js";
/**
 * Parse the serialization of a color.
 *
 * This is based on the definition here:
 * https://html.spec.whatwg.org/multipage/canvas.html#serialisation-of-a-color
 */
export declare function parseColorSerialization(x: string): number[];
export declare function parseRGBAColorSpecification(x: any): vec4;
export declare function parseRGBColorSpecification(x: any): vec3;
/**
 * Returns an integer formed by concatenating the channels of the input color vector.
 * Each channel is clamped to the range [0.0, 1.0] before being converted to 8 bits.
 * An RGB color is packed into 24 bits, and a RGBA into 32 bits.
 * Packed colors are stored in (AA)GGBBRR order.
 */
export declare function packColor(x: vec3 | vec4): number;
/**
 * Extend a packed RGB color to a packed RGBA color with full opacity.
 */
export declare function extendPackedRGB(value: number): number;
export declare function unpackRGB(value: number): vec3;
export declare function unpackRGBA(value: number): vec4;
export declare function serializeColor(x: vec3 | vec4): string;
export declare function srgbGammaExpand(value: number): number;
export declare function getRelativeLuminance(color: vec3 | vec4): number;
export declare function useWhiteBackground(foregroundColor: vec3 | vec4): boolean;
export declare class TrackableRGB extends WatchableValue<vec3> {
    defaultValue: vec3;
    constructor(defaultValue: vec3);
    toString(): string;
    toJSON(): string | undefined;
    reset(): void;
    restoreState(x: any): void;
}
export declare class TrackableOptionalRGB extends WatchableValue<vec3 | undefined> {
    constructor();
    toJSON(): string | undefined;
    reset(): void;
    restoreState(x: any): void;
}
export declare function createSteppedCssGradient(colors: string[], conic?: boolean): string;
