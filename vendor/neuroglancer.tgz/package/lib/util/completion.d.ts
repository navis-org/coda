/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface Completion {
    value: string;
}
export interface CompletionWithDescription extends Completion {
    description?: string;
}
export interface BasicCompletionResult<C extends Completion = Completion> {
    completions: C[];
    defaultCompletion?: string;
    offset: number;
}
export declare const emptyCompletionResult: {
    offset: number;
    completions: never[];
};
export declare function applyCompletionOffset<T extends {
    offset: number;
} | undefined>(offset: number, completionResult: T): T;
export declare function getPrefixMatches(prefix: string, options: Iterable<string>): Completion[];
export declare function getPrefixMatchesWithDescriptions<T>(prefix: string, options: Iterable<T>, getValue: (x: T) => string, getDescription: (x: T) => string | undefined): CompletionWithDescription[];
export declare function completeQueryStringParameters<T extends Completion>(queryString: string, keyCompleter: (value: string) => Promise<BasicCompletionResult<T>>, valueCompleter: (key: string, value: string) => Promise<BasicCompletionResult<T>>): Promise<BasicCompletionResult<T>>;
export interface QueryStringCompletionTableEntry<C extends Completion = Completion> {
    readonly key: C;
    readonly values: readonly C[];
}
export type QueryStringCompletionTable<C extends Completion = Completion> = readonly QueryStringCompletionTableEntry<C>[];
export declare function completeQueryStringParametersFromTable<C extends Completion>(queryString: string, table: QueryStringCompletionTable<C>): Promise<BasicCompletionResult<C>>;
export declare function concatCompletions<C extends Completion>(url: string, inputs: (undefined | BasicCompletionResult<C> | Promise<BasicCompletionResult<C> | undefined>)[]): Promise<BasicCompletionResult<C>>;
