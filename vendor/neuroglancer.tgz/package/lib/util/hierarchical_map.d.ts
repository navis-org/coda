/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Hierarchical mapping from keys to values.
 */
export interface HierarchicalMapInterface<Key, Value> {
    get(key: Key): Value | undefined;
    entries(): IterableIterator<[Key, Value]>;
}
/**
 * Maps string event identifiers to string action identifiers.
 *
 * When an event identifier is looked up in a given HierarchicalMap, it is resolved to a
 * corresponding action identifier in one of two ways:
 *
 * 1. via mappings defined directly on the HierarchicalMap.
 *
 * 2. via a recursive lookup on a "parent" HierarchicalMap that has been specified for the root
 *    HierarchicalMap on which the lookup was initiated.
 *
 * HierarchicalMap objects may be specified as "parents" of another HierarchicalMap along with a
 * specified numerical priority value, such that there is a directed graph of HierarchicalMap
 * objects.  Cycles in this graph may lead to infinite looping.
 *
 * Recursive lookups in parent HierarchicalMap objects are performed in order of decreasing
 * priority. The lookup stops as soon as a mapping is found.  Direct bindings have a priority of 0.
 * Therefore, parent maps with a priority higher than 0 take precedence over direct bindings.
 */
export declare class HierarchicalMap<Key, Value, Parent extends HierarchicalMapInterface<Key, Value> = HierarchicalMapInterface<Key, Value>> implements HierarchicalMapInterface<Key, Value> {
    parents: Parent[];
    private parentPriorities;
    bindings: Map<Key, Value>;
    /**
     * If an existing HierarchicalMap is specified, a shallow copy is made.
     *
     * @param existing Existing map to make a shallow copy of.
     */
    constructor(existing?: HierarchicalMap<Key, Value, Parent>);
    /**
     * Register `parent` as a parent map.  If `priority > 0`, this map will take precedence over
     * direct bindings.
     *
     * @returns A nullary function that unregisters the parent (and may be called at most once).
     */
    addParent(parent: Parent, priority: number): () => void;
    /**
     * Unregisters `parent` as a parent.
     */
    removeParent(parent: Parent): void;
    /**
     * Register a direct binding.
     */
    set(key: Key, value: Value): void;
    /**
     * Unregister a direct binding.
     */
    delete(key: Key): void;
    /**
     * Deletes all bindings, including parents.
     */
    clear(): void;
    /**
     * Lookup the highest priority value to which the specified key is mapped.
     */
    get(key: Key): Value | undefined;
    /**
     * Find all values to which the specified key is mapped.
     */
    getAll(key: Key): IterableIterator<Value>;
    entries(): IterableIterator<[Key, Value]>;
}
