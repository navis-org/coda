/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ProgressListener } from "#src/util/progress_listener.js";
export declare class HttpError extends Error {
    url: string;
    status: number;
    statusText: string;
    response?: Response;
    constructor(url: string, status: number, statusText: string, response?: Response, options?: {
        cause: any;
    });
    static fromResponse(response: Response): HttpError;
    static fromRequestError(input: RequestInfo, error: unknown): unknown;
}
export declare function pickDelay(attemptNumber: number): number;
/**
 * Issues a `fetch` request.
 *
 * If the request fails due to an HTTP status outside `[200, 300)`, throws an `HttpError`.  If the
 * request fails due to a network or CORS restriction, throws an `HttpError` with a `status` of `0`.
 *
 * If the request fails due to a transient error (429, 503, 504), retry.
 */
export declare function fetchOk(input: RequestInfo, init?: RequestInitWithProgress): Promise<Response>;
export interface RequestInitWithProgress extends RequestInit {
    progressListener?: ProgressListener;
}
export type FetchOk = (input: RequestInfo, init?: RequestInitWithProgress) => Promise<Response>;
export declare function isNotFoundError(e: any): boolean;
