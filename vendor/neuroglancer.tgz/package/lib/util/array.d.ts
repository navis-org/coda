/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface WritableArrayLike<T> {
    length: number;
    [n: number]: T;
}
/**
 * Partitions array[start:end] such that all elements for which predicate
 * returns true are before the elements for which predicate returns false.
 *
 * predicate will be called exactly once for each element in array[start:end],
 * in order.
 *
 * @returns {number} The index of the first element for which predicate returns
 * false, or end if there is no such element.
 */
export declare function partitionArray<T>(array: T[], start: number, end: number, predicate: (x: T) => boolean): number;
export declare function filterArrayInplace<T>(array: T[], predicate: (x: T, index: number, array: T[]) => boolean): void;
export type TypedNumberArrayConstructor<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike> = (typeof Int8Array<TArrayBuffer> | typeof Uint8Array<TArrayBuffer> | typeof Int16Array<TArrayBuffer> | typeof Uint16Array<TArrayBuffer> | typeof Int32Array<TArrayBuffer> | typeof Uint32Array<TArrayBuffer> | typeof Float32Array<TArrayBuffer> | typeof Float64Array<TArrayBuffer>) & (TArrayBuffer extends ArrayBuffer ? {
    new (count: number): TypedNumberArray<ArrayBuffer>;
} : Record<string, never>);
export type TypedBigIntArrayConstructor<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike> = (typeof BigUint64Array<TArrayBuffer> | typeof BigInt64Array<TArrayBuffer>) & (TArrayBuffer extends ArrayBuffer ? {
    new (count: number): TypedBigIntArray<ArrayBuffer>;
} : Record<string, never>);
export type TypedArrayConstructor<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike> = TypedNumberArrayConstructor<TArrayBuffer> | TypedBigIntArrayConstructor<TArrayBuffer>;
export type TypedNumberArray<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike> = Int8Array<TArrayBuffer> | Uint8Array<TArrayBuffer> | Int16Array<TArrayBuffer> | Uint16Array<TArrayBuffer> | Int32Array<TArrayBuffer> | Uint32Array<TArrayBuffer> | Float32Array<TArrayBuffer> | Float64Array<TArrayBuffer>;
export type TypedBigIntArray<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike> = BigInt64Array<TArrayBuffer> | BigUint64Array<TArrayBuffer>;
export type TypedArray<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike> = TypedNumberArray<TArrayBuffer> | TypedBigIntArray<TArrayBuffer>;
/**
 * Returns an array of size newSize that starts with the contents of array.
 * Either returns array if it has the correct size, or a new array with zero
 * padding at the end.
 */
export declare function maybePadArray<TArrayBuffer extends ArrayBufferLike, T extends TypedNumberArray<TArrayBuffer>>(array: T, newSize: number): T;
export declare function getFortranOrderStrides(size: ArrayLike<number>, baseStride?: number): number[];
/**
 * Converts an array of shape [majorSize, minorSize] to
 * [minorSize, majorSize].
 */
export declare function transposeArray2d<T extends TypedNumberArray>(array: T, majorSize: number, minorSize: number): T;
export declare function tile2dArray<T extends TypedNumberArray>(array: T, majorDimension: number, minorTiles: number, majorTiles: number): T;
export declare function binarySearch<Hay, Needle>(haystack: ArrayLike<Hay>, needle: Needle, compare: (a: Needle, b: Hay) => number, low?: number, high?: number): number;
/**
 * Returns the index of the element in `haystack` that is closest to `needle`, according to
 * `compare`.  If there are multiple elements that are equally close, the index of the first such
 * element encountered is returned.  If `haystack` is empty, returns -1.
 */
export declare function findClosestMatchInSortedArray<T>(haystack: ArrayLike<T>, needle: T, compare: (a: T, b: T) => number, low?: number, high?: number): number;
/**
 * Performs a directional binary search to find the index of the first element in `haystack`
 * that satisfies the given `predicate`.
 *
 * @param direction - 'asc' to find the lowest qualifying index (default),
 *                    'desc' to find the highest qualifying index.
 * @returns The index of the matching element, or -1 if none found.
 */
export declare function findFirstInSortedArray<T>(haystack: ArrayLike<T>, predicate: (item: T) => boolean, direction?: "asc" | "desc", low?: number, high?: number): number;
/**
 * Returns the first index in `[begin, end)` for which `predicate` is `true`, or returns `end` if no
 * such index exists.
 *
 * For any index `i` in `(begin, end)`, it must be the case that `predicate(i) >= predicate(i - 1)`.
 */
export declare function binarySearchLowerBound(begin: number, end: number, predicate: (index: number) => boolean): number;
/**
 * Returns an array of indices into `input` that equal (under `===`) `value`.
 */
export declare function findMatchingIndices<T>(input: T[], value: T): number[];
/**
 * Returns an array of the indices in `[0, ..., max)` not in `indices`.
 */
export declare function getIndicesComplement(indices: number[], max: number): number[];
export declare function arraysEqual<T>(a: ArrayLike<T>, b: ArrayLike<T>): boolean;
export declare function arraysEqualWithPredicate<T>(a: ArrayLike<T>, b: ArrayLike<T>, elementsEqual?: (a: T, b: T) => boolean): boolean;
export declare function getInsertPermutation(n: number, sourceIndex: number, targetIndex: number): number[];
export declare function scatterUpdate<T, Dest extends {
    [index: number]: T;
}, Source extends {
    readonly [index: number]: T;
}>(dest: Dest, source: Source, indices: ArrayLike<number>): Dest;
export declare function gatherUpdate<T, Dest extends {
    [index: number]: T;
}, Source extends {
    readonly [index: number]: T;
}>(dest: Dest, source: Source, indices: ArrayLike<number>): Dest;
export declare function transposeNestedArrays<T>(x: T[][]): T[][];
export interface ArraySpliceOp {
    retainCount: number;
    deleteCount: number;
    insertCount: number;
}
export declare function spliceArray<T>(array: T[], splices: readonly Readonly<ArraySpliceOp>[]): any[];
export declare function getMergeSplices<T>(oldArray: readonly T[], newArray: readonly T[], compare: (a: T, b: T) => number): ArraySpliceOp[];
export declare function getFixedOrderMergeSplices<T>(oldArray: readonly T[], newArray: readonly T[], equal: (a: T, b: T) => boolean): ArraySpliceOp[];
export declare function mergeSequences(aCount: number, bCount: number, compare: (a: number, b: number) => number, aCallback: (a: number) => void, bCallback: (b: number) => void, abCallback: (a: number, b: number) => void): void;
export declare class TypedArrayBuilder<T extends TypedArray<ArrayBuffer>> {
    data: T;
    length: number;
    constructor(cls: {
        new (count: number): T;
    }, initialCapacity?: number);
    resize(newLength: number): void;
    get view(): T;
    shrinkToFit(): void;
    clear(): void;
    appendArray(other: ArrayLike<T extends TypedBigIntArray ? bigint : number>): void;
    eraseRange(start: number, end: number): void;
}
