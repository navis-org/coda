/**
 * @license
 * Copyright 2018 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { RefCounted } from "#src/util/disposable.js";
import type { ActionEvent, EventActionMapInterface } from "#src/util/event_action_map.js";
import { EventActionMap, registerActionListener } from "#src/util/event_action_map.js";
export interface TouchTapInfo {
    event: TouchEvent;
    centerX: number;
    centerY: number;
}
export interface TouchTranslateInfo {
    event: TouchEvent;
    centerX: number;
    centerY: number;
    deltaX: number;
    deltaY: number;
}
export interface TouchPinchInfo {
    event: TouchEvent;
    centerX: number;
    centerY: number;
    distance: number;
    prevDistance: number;
}
export interface TouchRotateInfo {
    event: TouchEvent;
    centerX: number;
    centerY: number;
    angle: number;
    prevAngle: number;
}
export interface TouchHoldInfo {
    event: TouchEvent;
    centerX: number;
    centerY: number;
}
export declare class TouchEventBinder<EventMap extends EventActionMapInterface> extends RefCounted {
    target: HTMLElement;
    eventMap: EventMap;
    private dispatch;
    private prevTouches;
    private prevEvent?;
    private moved;
    /**
     * Initial angle for two-finger touch.  Once the difference between this ange the current angle
     * exceeds `rotateThreshold`, `touchrotate` events are dispatched.
     **/
    private prevAngle;
    private rotated;
    /**
     * Initial distance for two-finger touch.  Once the difference between this ange the current
     * distance exceeds `pinchThreshold`, `touchpinich` events are dispatched.
     **/
    private prevDistance;
    private pinched;
    private prevCenterX;
    private prevCenterY;
    private translated;
    private startHold;
    private numPriorTaps;
    private priorTapNumTouches;
    private tapStartTime;
    private tapEndTime;
    private curTapNumTouches;
    private handleTouchEvent;
    constructor(target: HTMLElement, eventMap: EventMap);
}
export { EventActionMap, registerActionListener };
export type { EventActionMapInterface, ActionEvent };
