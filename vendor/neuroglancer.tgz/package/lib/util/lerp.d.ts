/**
 * @license
 * Copyright 2021 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { DataType } from "#src/util/data_type.js";
export type DataTypeInterval = [number, number] | [bigint, bigint];
export type UnknownDataTypeInterval = [number | bigint, number | bigint];
export declare const defaultDataTypeRange: Record<DataType, DataTypeInterval>;
/**
 * Compute inverse linear interpolation on the interval [0, 1].
 * @param range Values at start and end of interval.
 * @param value Value to interpolate at.
 * @returns Coordinate of interpolated point.
 */
export declare function computeInvlerp(range: DataTypeInterval, value: number | bigint): number;
/**
 * Compute linear interpolation on the interval [0, 1].
 * @param range Values at start and end of interval.
 * @param dataType
 * @param value Coordinate to interpolate at.
 * @returns Interpolated value.
 */
export declare function computeLerp(range: DataTypeInterval, dataType: DataType, value: number): number | bigint;
export declare function clampToInterval(range: DataTypeInterval, value: number | bigint): number | bigint;
export declare function getClampedInterval(bounds: DataTypeInterval, range: DataTypeInterval): DataTypeInterval;
export declare function validateDataTypeInterval(interval: DataTypeInterval): DataTypeInterval;
export declare function normalizeDataTypeInterval(interval: DataTypeInterval): DataTypeInterval;
export declare function dataTypeCompare(a: number | bigint, b: number | bigint): 0 | 1 | -1;
export declare function getClosestEndpoint(range: DataTypeInterval, value: number | bigint): number;
export declare function parseDataTypeValue(dataType: DataType, x: unknown): number | bigint;
export declare function parseUnknownDataTypeValue(x: unknown): number | bigint;
export declare function parseDataTypeInterval(obj: unknown, dataType: DataType): DataTypeInterval;
export declare function parseUnknownDataTypeInterval(obj: unknown): UnknownDataTypeInterval;
export declare function dataTypeIntervalEqual(a: DataTypeInterval, b: DataTypeInterval): boolean;
export declare function dataTypeIntervalToJson(range: DataTypeInterval, dataType: DataType, defaultRange?: DataTypeInterval): string[] | [number, number] | [bigint, bigint] | undefined;
export declare function dataTypeValueNextAfter(dataType: DataType, value: number | bigint, sign: 1 | -1): number | bigint;
export declare function getIntervalBoundsEffectiveOffset(dataType: DataType, interval: DataTypeInterval): number;
export declare function getIntervalBoundsEffectiveFraction(dataType: DataType, interval: DataTypeInterval): number;
export declare function convertDataTypeInterval(interval: UnknownDataTypeInterval | undefined, dataType: DataType): DataTypeInterval;
