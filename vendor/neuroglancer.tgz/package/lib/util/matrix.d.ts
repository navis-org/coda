/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { TypedNumberArray } from "#src/util/array.js";
/**
 * Sets the `m * k` matrix `c` to the product of `m * n` matrix `a` and `n * k` matrix `b`.
 *
 * `a`, `b` and `c` are column-major with column strides of `lda`, `ldb`, and `ldc`, respectively.
 * `c` must not overlap `a` or `b`.
 */
export declare function multiply<T extends TypedNumberArray>(c: T, ldc: number, a: T, lda: number, b: T, ldb: number, m: number, n: number, k: number): T;
export declare function identity<T extends TypedNumberArray>(a: T, lda: number, n: number): T;
export declare function createIdentity<T extends TypedNumberArray>(c: {
    new (n: number): T;
}, rows: number, cols?: number): T;
export declare function createHomogeneousScaleMatrix<T extends TypedNumberArray>(c: {
    new (length: number): T;
}, scales: ArrayLike<number>, square?: boolean): T;
export declare function createHomogeneousTranslationMatrix<T extends TypedNumberArray>(c: {
    new (length: number): T;
}, translation: ArrayLike<number>, square?: boolean): T;
export declare function isIdentity<T extends TypedNumberArray>(a: T, lda: number, n: number): boolean;
export declare function copy<T extends TypedNumberArray>(b: T, ldb: number, a: T, lda: number, m: number, n: number): T;
export declare function extendHomogeneousTransform<T extends TypedNumberArray>(b: T, bRank: number, a: T, aRank: number): T;
/**
 * Computes the inverse of a square matrix in place, and returns the determinant.
 */
export declare function inverseInplace<T extends TypedNumberArray>(a: T, lda: number, n: number): number;
/**
 * Computes the inverse and returns the determinant.
 */
export declare function inverse<T extends TypedNumberArray>(b: T, ldb: number, a: T, lda: number, n: number): number;
export declare function equal<T extends TypedNumberArray>(a: T, lda: number, b: T, ldb: number, m: number, n: number): boolean;
export declare function transpose<T extends TypedNumberArray>(b: T, ldb: number, a: T, lda: number, m: number, n: number): T;
export declare function transformPoint<Out extends TypedNumberArray, Matrix extends TypedNumberArray, Vector extends TypedNumberArray>(out: Out, mat: Matrix, matrixStride: number, vec: Vector, rank: number): Out;
export declare function transformVector<Out extends TypedNumberArray, Matrix extends TypedNumberArray, Vector extends TypedNumberArray>(out: Out, mat: Matrix, matrixStride: number, vec: Vector, rank: number): Out;
export declare function permuteRows<Output extends TypedNumberArray, Input extends TypedNumberArray>(output: Output, outputStride: number, input: Input, inputStride: number, outputToInputRow: ReadonlyArray<number>, cols: number): Output;
export declare function permuteCols<Output extends TypedNumberArray, Input extends TypedNumberArray>(output: Output, outputStride: number, input: Input, inputStride: number, outputToInputCol: ReadonlyArray<number>, rows: number): Output;
