/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facility for triggering named actions in response to mouse events.
 */
import { RefCounted } from "#src/util/disposable.js";
import type { ActionEvent, EventActionMapInterface } from "#src/util/event_action_map.js";
import { EventActionMap, registerActionListener } from "#src/util/event_action_map.js";
export declare class MouseEventBinder<EventMap extends EventActionMapInterface> extends RefCounted {
    target: EventTarget;
    eventMap: EventMap;
    private dispatch;
    shouldIgnore: ((event: MouseEvent) => boolean) | undefined;
    constructor(target: EventTarget, eventMap: EventMap, commonHandler?: (event: MouseEvent) => void);
}
export { EventActionMap, registerActionListener };
export type { EventActionMapInterface, ActionEvent };
