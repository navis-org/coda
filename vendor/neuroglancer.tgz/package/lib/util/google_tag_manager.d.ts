declare const NEUROGLANCER_GOOGLE_TAG_MANAGER: string | undefined;
