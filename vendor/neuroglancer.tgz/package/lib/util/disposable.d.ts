/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface Disposable {
    dispose: () => void;
}
export type Disposer = Disposable | (() => void);
export declare function invokeDisposer(disposer: Disposer): void;
export declare function invokeDisposers(disposers: Disposer[]): void;
export declare function registerEventListener(target: EventTarget, type: string, listener: EventListenerOrEventListenerObject, options?: boolean | AddEventListenerOptions): () => void;
export declare class RefCounted implements Disposable {
    refCount: number;
    wasDisposed: boolean | undefined;
    private disposers;
    addRef(): this;
    disposedStacks: any;
    dispose(): void;
    [Symbol.dispose](): void;
    protected refCountReachedZero(): void;
    disposed(): void;
    registerDisposer<T extends Disposer>(f: T): T;
    unregisterDisposer<T extends Disposer>(f: T): T;
    registerEventListener(target: EventTarget, type: string, listener: EventListenerOrEventListenerObject, options?: boolean | AddEventListenerOptions): void;
    registerCancellable<T extends {
        cancel: () => void;
    }>(cancellable: T): T;
}
export declare class RefCountedValue<T> extends RefCounted {
    value: T;
    constructor(value: T);
}
/**
 * A variable of this type is associated with an increment of the reference count.  If a function
 * parameter is declared with this type, then callers must donate a reference count.
 */
export type Owned<T extends Disposable> = T;
/**
 * A variable of this type is not associated with an increment of the reference count.
 */
export type Borrowed<T extends Disposable> = T;
export declare function disposableOnce(value: Disposer | undefined): () => void;
