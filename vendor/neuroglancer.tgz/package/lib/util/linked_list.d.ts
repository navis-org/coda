/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export type Node<T, Next extends string | symbol, Prev extends string | symbol> = Record<Next | Prev, T | null>;
export interface LinkedListOperations<T> {
    insertAfter: (head: T, x: T) => void;
    pop: (head: T) => T;
    insertBefore: (head: T, x: T) => void;
    front: (head: T) => T | null;
    back: (head: T) => T | null;
    iterator: (head: T) => Iterator<T>;
    reverseIterator: (head: T) => Iterator<T>;
    initializeHead: (head: T) => void;
}
export default function linkedListOperations<Next extends string | symbol, Prev extends string | symbol>(options: {
    next: Next;
    prev: Prev;
}): {
    insertAfter<T extends Node<T, Next, Prev>>(head: T, x: T): void;
    insertBefore<T extends Node<T, Next, Prev>>(head: T, x: T): void;
    front<T extends Node<T, Next, Prev>>(head: T): T[Next] | null;
    back<T extends Node<T, Next, Prev>>(head: T): T | null;
    pop<T extends Node<T, Next, Prev>>(x: T): T;
    iterator<T extends Node<T, Next, Prev>>(head: T): Generator<T, void, unknown>;
    reverseIterator<T extends Node<T, Next, Prev>>(head: T): Generator<T, void, unknown>;
    initializeHead<T extends Node<T, Next, Prev>>(head: T): void;
};
