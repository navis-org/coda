/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare enum FrameTimingMethod {
    MEDIAN = 0,
    MEAN = 1,
    MAX = 2
}
interface QueryInfo {
    glQuery: WebGLQuery;
    frameNumber: number;
    wasStarted: boolean;
    wasEnded: boolean;
}
export declare class FramerateMonitor {
    private numStoredTimes;
    private queryPoolSize;
    private timeElapsedQueries;
    private warnedAboutMissingExtension;
    private storedTimeDeltas;
    constructor(numStoredTimes?: number, queryPoolSize?: number);
    getTimingExtension(gl: WebGL2RenderingContext): any;
    getOldestQueryIndexByFrameNumber(): number | undefined;
    startFrameTimeQuery(gl: WebGL2RenderingContext, ext: any, frameNumber: number): WebGLQuery | null;
    endLastTimeQuery(gl: WebGL2RenderingContext, ext: any): void;
    grabAnyFinishedQueryResults(gl: WebGL2RenderingContext): void;
    getLastFrameTimesInMs(numberOfFrames?: number): number[];
    getQueries(): QueryInfo[];
}
export declare class DownsamplingBasedOnFrameRateCalculator {
    numberOfStoredFrameDeltas: number;
    private maxDownsamplingFactor;
    private desiredFrameTimingMs;
    private downsamplingPersistenceDurationInFrames;
    private lastFrameTime;
    private frameDeltas;
    private downsamplingRates;
    private frameCount;
    /** Cache of last logged applied factor to avoid noisy logs when DEBUG_ADAPTIVE_FRAMERATE */
    private lastLoggedFactor;
    /**
     * @param numberOfStoredFrameDeltas The number of frame deltas to store. Oldest frame deltas are removed. Must be at least 1.
     * @param maxDownsamplingFactor The maximum factor for downsampling. Must be at least 2.
     * @param desiredFrameTimingMs The desired frame timing in milliseconds. The downsampling rate is based on a comparison of the actual frame timing to this value.
     * @param downsamplingPersistenceDurationInFrames The max number of frames over which a high downsampling rate persists.
     */
    constructor(numberOfStoredFrameDeltas?: number, maxDownsamplingFactor?: number, desiredFrameTimingMs?: number, downsamplingPersistenceDurationInFrames?: number);
    private validateConstructorArguments;
    private storeFrameDelta;
    private calculateMeanFrameTime;
    private calculateMedianFrameTime;
    private calculateMaxFrameTime;
    private updateMaxTrackedDownsamplingRate;
    resetForNewFrameSet(): void;
    addFrame(timestamp?: number): void;
    calculateFrameTimeInMs(method?: FrameTimingMethod): number;
    /** Should be called once per frame for proper downsampling persistence */
    calculateDownsamplingRate(method?: FrameTimingMethod): number;
    getFrameDeltas(): number[];
    getFrameCount(): number;
    getDownsamplingRates(): Map<number, number>;
    setFrameDeltas(frameDeltas: number[], incrementFrameCount?: boolean): void;
}
export {};
