/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare function scopedAbortCallback(signal: AbortSignal | undefined, callback: (reason: any) => void): Disposable | undefined;
export declare class SharedAbortController {
    private consumers;
    private controller;
    private retainCount;
    get signal(): AbortSignal;
    addConsumer(signal: AbortSignal | undefined): void;
    [Symbol.dispose](): void;
    start(): void;
}
export declare function promiseWithResolversAndAbortCallback<T>(signal: AbortSignal, abortCallback: (reason: any) => void): {
    promise: Promise<T>;
    resolve: (value: T) => void;
    reject: (reason: any) => void;
};
export declare function raceWithAbort<T>(promise: Promise<T>, signal: AbortSignal | undefined): Promise<T>;
export declare function abortPromise(signal: AbortSignal): Promise<unknown>;
