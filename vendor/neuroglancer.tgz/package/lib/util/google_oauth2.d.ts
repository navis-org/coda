/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CredentialsProvider } from "#src/credentials_provider/index.js";
export declare const EMAIL_SCOPE = "email";
export declare const OPENID_SCOPE = "openid";
export declare const AUTH_SERVER = "https://accounts.google.com/o/oauth2/v2/auth";
/**
 * OAuth2 Token
 */
export interface OAuth2Token {
    accessToken: string;
    expiresIn: string;
    tokenType: string;
    scope: string;
    email: string | undefined;
}
/**
 * Obtain a Google OAuth2 authentication token.
 * @return A Promise that resolves to an authentication token.
 */
export declare function authenticateGoogleOAuth2(options: {
    clientId: string;
    scopes: string[];
    approvalPrompt?: "force" | "auto";
    loginHint?: string;
    immediate?: boolean;
    authUser?: number;
}, signal: AbortSignal): Promise<OAuth2Token>;
export declare class GoogleOAuth2CredentialsProvider extends CredentialsProvider<OAuth2Token> {
    options: {
        clientId: string;
        scopes: string[];
        description: string;
    };
    constructor(options: {
        clientId: string;
        scopes: string[];
        description: string;
    });
    get: (invalidCredentials?: import("#src/credentials_provider/index.js").CredentialsWithGeneration<OAuth2Token> | undefined, options?: Partial<import("#src/util/progress_listener.js").ProgressOptions>) => Promise<import("#src/credentials_provider/index.js").CredentialsWithGeneration<OAuth2Token>>;
}
