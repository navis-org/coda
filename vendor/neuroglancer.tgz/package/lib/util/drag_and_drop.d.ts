/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare function encodeStringAsDragType(s: string): any;
export declare function decodeStringFromDragType(s: string): string;
export declare function encodeDragType(prefix: string, parameters: any): string;
export declare function decodeParametersFromDragType(dragType: string, prefix: string): any;
export declare function encodeParametersAsDragType(prefix: string, parameters: any): string;
export interface DragInfo {
    dragType: string;
    parameters: any;
}
export declare function decodeParametersFromDragTypeList(dragTypes: ReadonlyArray<string>, prefix: string): DragInfo | undefined;
/**
 * Declares the drop effects this drag source supports.
 *
 * macOS intersects this mask with the operation its own drag modifiers request,
 * and reports "none" when the two do not overlap, which rejects the drop. A
 * source that leaves the mask unset can therefore never be moved with Command.
 */
export declare function declareAllowedDropEffects(event: DragEvent, allowed: DataTransfer["effectAllowed"]): void;
/**
 * On Chrome 62, the dataTransfer.dropEffect property is reset to 'none' when the 'drop' event is
 * dispatched.  As a workaround, we store it in a global variable.
 *
 * The alternative workaround of recomputing it in the 'drop' event handler is problematic for a
 * different reason: the computation may depend on the modifier key states, and on Firefox 52, these
 * key states are not set in the 'drop' event.
 */
export declare function setDropEffect<T extends DataTransfer["dropEffect"]>(event: DragEvent, dropEffect: T): T;
export declare function getDropEffect(): "link" | "copy" | "none" | "move" | undefined;
export declare function preventDrag(element: HTMLElement): () => void;
export declare function getDropEffectFromModifiers<DropEffect extends string>(event: DragEvent, defaultDropEffect: DropEffect, moveAllowed: boolean): {
    dropEffect: DropEffect | "move" | "copy";
    dropEffectMessage: string;
};
