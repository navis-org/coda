/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface SiPrefix {
    readonly prefix: string;
    readonly exponent: number;
    readonly longPrefix?: string;
}
export declare const preferredSiPrefixes: readonly SiPrefix[];
export declare const allSiPrefixes: readonly SiPrefix[];
export declare const supportedUnits: Map<string, {
    unit: string;
    exponent: number;
}>;
export declare const exponentToPrefix: Map<number, string>;
export declare function pickSiPrefix(x: number): SiPrefix;
interface FormatScaleWithUnitOptions {
    precision?: number;
    elide1?: boolean;
}
export declare function formatScaleWithUnit(scale: number, unit: string, options?: FormatScaleWithUnitOptions): {
    scale: string;
    prefix: string;
    unit: string;
};
export declare function formatScaleWithUnitAsString(scale: number, unit: string, options?: FormatScaleWithUnitOptions): string;
export declare function parseScale(s: string): {
    scale: number;
    unit: string;
} | undefined;
export declare function unitFromJson(x: unknown): {
    unit: string;
    exponent: number;
};
/**
 * Returns `scale * 10**exponent`, but uses division for negative exponents to reduce loss of
 * precision.
 */
export declare function scaleByExp10(scale: number, exponent: number): number;
export {};
