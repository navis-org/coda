/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file
 * Utilities for positioning dropdown menus.
 */
export declare function positionDropdown(dropdownElement: HTMLElement, associatedElement: HTMLElement, { horizontal, vertical, topMargin, bottomMargin, leftMargin, rightMargin, maxHeight, maxWidth, }?: {
    horizontal?: boolean | undefined;
    vertical?: boolean | undefined;
    topMargin?: number | undefined;
    bottomMargin?: number | undefined;
    leftMargin?: number | undefined;
    rightMargin?: number | undefined;
    maxHeight?: boolean | undefined;
    maxWidth?: boolean | undefined;
}): void;
export declare function positionRelativeDropdown(dropdown: HTMLElement, parent: HTMLElement): void;
