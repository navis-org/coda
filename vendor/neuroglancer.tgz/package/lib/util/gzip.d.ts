/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Detects gzip format based on the 3 magic bytes at the start.
 */
export declare function isGzipFormat(data: ArrayBufferView): boolean;
export declare function decodeGzip(data: ArrayBuffer | ArrayBufferView<ArrayBuffer> | Response, format: CompressionFormat, signal?: AbortSignal): Promise<ArrayBuffer>;
export declare function decodeGzipStream(response: Response, format: CompressionFormat, signal?: AbortSignal): ReadableStream<Uint8Array>;
/**
 * Decompress `data` if it is in gzip format, otherwise just return it.
 */
export declare function maybeDecompressGzip(data: ArrayBuffer | ArrayBufferView<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>>;
