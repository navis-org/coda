/**
 * @license
 * Copyright 2025 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare function bigintCompare(a: bigint, b: bigint): 0 | 1 | -1;
export declare function uint64FromLowHigh(low: number, high: number): bigint;
export declare function randomUint64(): bigint;
export declare function wrapSigned32BitIntegerToUint64(value: number): bigint;
export declare function bigintMin(a: bigint, b: bigint): bigint;
export declare function bigintMax(a: bigint, b: bigint): bigint;
export declare const UINT64_MAX = 18446744073709551615n;
export declare function clampToUint64(x: bigint): bigint;
export declare function bigintAbs(x: bigint): bigint;
export declare function roundToUint64(x: number | bigint): bigint;
