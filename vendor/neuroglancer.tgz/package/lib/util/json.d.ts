/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { WritableArrayLike } from "#src/util/array.js";
import { vec3 } from "#src/util/geom.js";
export declare function verifyFloat(obj: any): number;
export declare function verifyFiniteFloat(obj: any): number;
export declare function verifyFiniteNonNegativeFloat(obj: any): number;
export declare function verifyFinitePositiveFloat(obj: any): number;
export declare function makeVerifyNumberInInterval(minValue: number, maxValue: number): (obj: any) => number;
export declare function parseXYZ<A extends WritableArrayLike<number>>(out: A, obj: any, validator?: (x: any) => number): A;
export declare function parseFiniteVec<U extends WritableArrayLike<number>>(out: U, obj: any[]): U;
export declare function parseIntVec<U extends WritableArrayLike<number>>(out: U, obj: any): U;
/**
 * Returns a JSON representation of x, with object keys sorted to ensure a
 * consistent result.
 */
export declare function stableStringify(x: any): string;
export declare function urlSafeStringifyString(x: string): string;
export declare function urlSafeStringify(x: any): string;
/**
 * Converts a string literal delimited by either single or double quotes into a string literal
 * delimited by double quotes.
 */
export declare function normalizeStringLiteral(x: string): string;
export declare function urlSafeToJSON(x: string): string;
export declare function jsonToUrlSafe(x: string): string;
export declare function urlSafeParse(x: string): any;
export declare function pythonLiteralToJSON(x: string): string;
export declare function pythonLiteralParse(x: string): any;
export declare function expectArray(x: unknown, length?: number): any[];
export declare function parseArray<T>(x: any, parseElement: (x: any, index: number) => T): T[];
export declare function parseFixedLengthArray<T, U extends WritableArrayLike<T>>(out: U, obj: any, parseElement: (x: any, index: number) => T): U;
export declare function verifyObject(obj: any): any;
export declare function verifyInt(obj: any): number;
export declare function verifyPositiveInt(obj: any): number;
export declare function verifyNonnegativeInt(obj: any): number;
export declare function verifyMapKey<U>(obj: any, map: Map<string, U>): U & ({} | null);
export declare function verifyString(obj: any): string;
export declare function verifyOptionalString(obj: any): string | undefined;
export declare function verifyOptionalInt(obj: any): number | undefined;
export declare function verifyOptionalBoolean(obj: any): boolean | undefined;
export declare function valueOr<T>(value: T | undefined, defaultValue: T): T;
export declare function verifyObjectProperty<T>(obj: any, propertyName: string, validator: (value: any) => T): T;
export declare function verifyOptionalObjectProperty<T>(obj: any, propertyName: string, validator: (value: any) => T): T | undefined;
export declare function verifyOptionalObjectProperty<T>(obj: any, propertyName: string, validator: (value: any) => T, defaultValue: T): T;
export declare function verifyObjectAsMap<T>(obj: any, validator: (value: any) => T): Map<string, T>;
export declare function verifyFloat01(obj: any): number;
/**
 * The query string parameters may either be specified in the usual
 * 'name=value&otherName=otherValue' form or as (optionally urlSafe) JSON: '{"name":"value"}`.
 */
export declare function parseQueryStringParameters(queryString: string): any;
export declare function unparseQueryStringParameters(parameters: any): string;
/**
 * Verifies that `obj' is a string that, when converted to uppercase, matches a string property of
 * `enumType`.
 *
 * @returns The corresponding numerical value.
 */
export declare function verifyEnumString<T extends number>(obj: any, enumType: {
    [x: string]: T | string;
}, pattern?: RegExp): T;
export declare function verify3dVec(obj: any): vec3;
export declare function verify3dScale(obj: any): vec3;
export declare function verify3dDimensions(obj: any): vec3;
export declare function verifyStringArray(a: any): string[];
export declare function verifyIntegerArray(a: unknown): number[];
export declare function verifyFloatArray(a: unknown): number[];
export declare function verifyBoolean(x: any): x is true;
export declare function emptyToUndefined(x: any): any;
export declare function verifyConstant<T>(actual: unknown, expected: T): T;
export declare function verifyOptionalFixedLengthArrayOfStringOrNull(obj: unknown, rank: number): (string | null)[];
export declare function parseUint64(obj: unknown): bigint;
export declare function bigintToStringJsonReplacer(_key: unknown, value: unknown): unknown;
