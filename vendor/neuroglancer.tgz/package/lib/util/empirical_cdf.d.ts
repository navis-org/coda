/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.

 * @file Defines facilities for manipulation of empirical cumulative distribution functions.
 */
import { DataType } from "#src/util/data_type.js";
import { type DataTypeInterval } from "#src/util/lerp.js";
interface AutoRangeResult {
    range: DataTypeInterval;
    /** The window is set a bit larger than the range */
    window: DataTypeInterval;
}
export declare function expandRange(range: DataTypeInterval, inputDataType: DataType, expansionAmount?: number): DataTypeInterval;
export declare function computePercentilesFromEmpiricalHistogram(histogram: Float32Array, lowerPercentile: number | undefined, upperPercentile: number | undefined, histogramRange: DataTypeInterval, inputDataType: DataType): AutoRangeResult;
export {};
