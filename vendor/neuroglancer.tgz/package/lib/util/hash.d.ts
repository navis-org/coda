/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * This is a very simple string hash function.  It isn't secure, but
 * is suitable for sharding of requests.
 */
export declare function simpleStringHash(s: string): number;
/**
 * MurmurHash3_x86_32 mixing function
 */
export declare function murmurHash3_x86_32Mix(h: number, k: number): number;
/**
 * MurmurHash3_x86_32 finalization function
 */
export declare function murmurHash3_x86_32Finalize(h: number, len: number): number;
/**
 * MurmurHash3_x86_32, specialized for 8 bytes of input.
 */
export declare function murmurHash3_x86_32Hash64Bits(seed: number, low: number, high: number): number;
export declare function murmurHash3_x86_32Hash64Bits_Bigint(seed: number, x: bigint): number;
/**
 * MurmurHash3_x86_128, specialized for 8 bytes of input.
 *
 * Only the low 8 bytes of output are returned.
 */
export declare function murmurHash3_x86_128Hash64Bits_Bigint(seed: number, input: bigint): bigint;
