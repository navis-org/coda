/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { TypedArrayConstructor } from "#src/util/array.js";
/**
 * If this is updated, DATA_TYPE_BYTES must also be updated.
 */
export declare enum DataType {
    UINT8 = 0,
    INT8 = 1,
    UINT16 = 2,
    INT16 = 3,
    UINT32 = 4,
    INT32 = 5,
    UINT64 = 6,
    FLOAT32 = 7
}
export declare const DATA_TYPE_SIGNED: Record<DataType, boolean | undefined>;
export declare const DATA_TYPE_BYTES: Record<DataType, number>;
export declare const DATA_TYPE_ARRAY_CONSTRUCTOR: Record<DataType, TypedArrayConstructor>;
export declare function makeDataTypeArrayView<TArrayBuffer extends ArrayBufferLike>(dataType: DataType, buffer: TArrayBuffer, byteOffset?: number, byteLength?: number): ArrayBufferView<TArrayBuffer>;
