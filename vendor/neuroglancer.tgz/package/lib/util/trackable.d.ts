/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Defines a generic interface for a simple state tracking mechanism.
 */
import { RefCounted } from "#src/util/disposable.js";
import type { NullaryReadonlySignal } from "#src/util/signal.js";
import { NullarySignal } from "#src/util/signal.js";
export interface JsonRestorable {
    restoreState: (x: any) => void;
}
export declare function optionallyRestoreFromJsonMember(obj: any, member: string, restorable: JsonRestorable): void;
export interface Trackable extends JsonRestorable {
    restoreState: (x: any) => void;
    reset: () => void;
    changed: NullaryReadonlySignal;
    toJSON: () => any;
}
export declare class CompoundTrackable extends RefCounted implements Trackable {
    children: Map<string, Trackable>;
    changed: NullarySignal;
    add(key: string, value: Trackable): () => void;
    remove(key: string): void;
    disposed(): void;
    toJSON(): {
        [key: string]: any;
    };
    baseJSON(): {
        [key: string]: any;
    };
    reset(): void;
    restoreState(x: any): void;
}
export declare class PersistentCompoundTrackable extends CompoundTrackable {
    lastState: {
        [key: string]: any;
    };
    restoreState(x: any): void;
    reset(): void;
    baseJSON(): {
        [key: string]: any;
    } & {
        [key: string]: any;
    };
    toJSON(): {
        [key: string]: any;
    };
    add(key: string, value: Trackable): () => void;
}
/**
 * Returns a JSON representation of a Trackable object.
 *
 * Recursively caches the result, such that it is only necessary to traverse the changed portions of
 * the object.
 *
 * The returned value must not be modified.
 */
export declare function getCachedJson(root: Trackable): {
    value: any;
    generation: number;
};
