/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facility for triggering named actions in response to keyboard events.
 */
import { WatchableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import type { ActionEvent, EventActionMapInterface } from "#src/util/event_action_map.js";
import { EventActionMap, registerActionListener } from "#src/util/event_action_map.js";
export declare const globalModifiers: WatchableValue<number>;
export declare class KeyboardEventBinder<EventMap extends EventActionMapInterface> extends RefCounted {
    target: EventTarget;
    eventMap: EventMap;
    modifierShortcutsAreGlobal: boolean;
    allShortcutsAreGlobal: boolean;
    allowSpaceKeyOnButtons: boolean;
    shouldIgnore: ((event: KeyboardEvent) => boolean) | undefined;
    constructor(target: EventTarget, eventMap: EventMap);
    private shouldIgnoreEvent;
    private handleKeyDown;
}
export declare function getEventKeyName(event: KeyboardEvent): string;
export { EventActionMap, registerActionListener };
export type { EventActionMapInterface, ActionEvent };
