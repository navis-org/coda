/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { RefCounted } from "#src/util/disposable.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare class Memoize<Key, Value extends RefCounted> {
    private map;
    /**
     * If getter throws an exception, no value is added.
     */
    get<T extends Value>(key: Key, getter: () => T): T;
}
export declare class StringMemoize extends Memoize<string, RefCounted> {
    get<T extends RefCounted>(x: any, getter: () => T): T;
    getUncounted<T>(x: any, getter: () => T): T;
    getAsync<T>(x: any, options: Partial<ProgressOptions>, getter: (options: ProgressOptions) => Promise<T>): Promise<T>;
}
export interface AsyncMemoize<T> {
    (options: {
        signal?: AbortSignal;
    }): Promise<T>;
}
export interface AsyncMemoizeWithProgress<T> {
    (options: Partial<ProgressOptions>): Promise<T>;
}
export declare function asyncMemoize<T>(getter: (options: {
    signal: AbortSignal;
}) => Promise<T>): AsyncMemoize<T>;
export declare function asyncMemoizeWithProgress<T>(getter: (options: ProgressOptions) => Promise<T>): AsyncMemoizeWithProgress<T>;
