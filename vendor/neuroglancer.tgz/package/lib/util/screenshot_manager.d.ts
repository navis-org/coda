/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use viewer file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @file Builds upon the Python screenshot tool to allow viewer screenshots to be taken and saved.
 */
import type { ScreenshotChunkStatistics } from "#src/python_integration/screenshots.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal, Signal } from "#src/util/signal.js";
import { ScreenshotMode } from "#src/util/trackable_screenshot_mode.js";
import type { Viewer } from "#src/viewer.js";
export declare const MAX_RENDER_AREA_PIXELS: number;
export interface ScreenshotLoadStatistics extends ScreenshotChunkStatistics {
    timestamp: number;
    gpuMemoryCapacity: number;
}
/**
 * Manages the screenshot functionality from the viewer viewer.
 *
 * Responsible for linking up the Python screenshot tool with the viewer, and handling the screenshot process.
 * The screenshot manager provides information about updates in the screenshot process, and allows for the screenshot to be taken and saved.
 * The screenshot UI menu listens to the signals emitted by the screenshot manager to update the UI.
 */
export declare class ScreenshotManager extends RefCounted {
    viewer: Viewer;
    screenshotId: number;
    screenshotLoadStats: ScreenshotLoadStatistics | null;
    screenshotStartTime: number;
    screenshotMode: ScreenshotMode;
    statisticsUpdated: Signal<(state: ScreenshotLoadStatistics) => void>;
    screenshotFinished: NullarySignal;
    zoomMaybeChanged: NullarySignal;
    private _shouldKeepSliceViewFOVFixed;
    private _screenshotScale;
    private filename;
    private lastUpdateTimestamp;
    private gpuMemoryChangeTimestamp;
    throttledSendStatistics: import("lodash").DebouncedFunc<() => Promise<void>>;
    constructor(viewer: Viewer);
    get screenshotScale(): number;
    set screenshotScale(scale: number);
    get shouldKeepSliceViewFOVFixed(): boolean;
    set shouldKeepSliceViewFOVFixed(enableFixedFOV: boolean);
    previewScreenshot(): void;
    takeScreenshot(filename?: string): void;
    forceScreenshot(): void;
    cancelScreenshot(shouldStayInPreview?: boolean): void;
    calculatedClippedViewportSize(): {
        width: number;
        height: number;
    };
    private handleScreenshotStarted;
    private resizeCanvasIfNeeded;
    private handleScreenshotModeChange;
    /**
     * Handles the zooming of the screenshot in fixed FOV mode.
     * This supports:
     * 1. Updating the zoom level of the viewer to match the screenshot scale.
     * 2. Resetting the zoom level of the slice views to the original level.
     * 3. Resizing the canvas to match the new scale.
     * @param scale - The scale factor to apply to the screenshot.
     * @param resetZoom - If true, the zoom resets to the original level.
     */
    private handleScreenshotZoomAndResize;
    /**
     * Check if the screenshot is stuck by comparing the number of visible chunks
     * in the GPU with the previous number of visible chunks. If the number of
     * visible chunks has not changed after a certain timeout, and the display has not updated, force a screenshot.
     */
    private checkAndHandleStalledScreenshot;
    private saveScreenshot;
    private resetCanvasSize;
    private resetStatistics;
    private generateFilename;
}
