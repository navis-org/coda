/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Message list framework for messages to be displayed in the UI.
 */
import { NullarySignal } from "#src/util/signal.js";
export declare enum MessageSeverity {
    info = 0,
    warning = 1,
    error = 2
}
export declare class Message {
    severity: MessageSeverity;
    message: string;
}
export declare class MessageList {
    changed: NullarySignal;
    private messages;
    private children;
    addMessage(message: Message): void;
    clearMessages(): void;
    isEmpty(): boolean;
    addChild(list: MessageList): () => void;
    [Symbol.iterator](): Iterator<Message>;
}
