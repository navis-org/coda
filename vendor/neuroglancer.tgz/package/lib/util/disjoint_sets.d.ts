/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { VisibleSegmentEquivalencePolicy } from "#src/segmentation_graph/segment_id.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
/**
 * Represents a collection of disjoint sets of uint64 values.
 *
 * Supports merging sets, retrieving the minimum uint64 value contained in a set (the representative
 * value), and iterating over the elements contained in a set.
 */
export declare class DisjointUint64Sets {
    private map;
    visibleSegmentEquivalencePolicy: WatchableValueInterface<VisibleSegmentEquivalencePolicy>;
    generation: number;
    has(x: bigint): boolean;
    get(x: bigint): bigint;
    isMinElement(x: bigint): boolean;
    private makeSet;
    /**
     * Union the sets containing `a` and `b`.
     * @returns `false` if `a` and `b` are already in the same set, otherwise `true`.
     */
    link(a: bigint, b: bigint): boolean;
    linkAll(ids: bigint[]): void;
    /**
     * Unlinks all members of the specified set.
     */
    deleteSet(x: bigint): boolean;
    setElements(a: bigint): IterableIterator<bigint>;
    clear(): boolean;
    get size(): number;
    mappings(): IterableIterator<[bigint, bigint]>;
    roots(): IterableIterator<bigint>;
    [Symbol.iterator](): IterableIterator<[bigint, bigint]>;
    /**
     * Returns an array of arrays of strings, where the arrays contained in the outer array correspond
     * to the disjoint sets, and the strings are the base-10 string representations of the members of
     * each set.  The members are sorted in numerical order, and the sets are sorted in numerical
     * order of their smallest elements.
     */
    toJSON(): string[][];
}
