/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { HierarchicalMapInterface } from "#src/util/hierarchical_map.js";
import { HierarchicalMap } from "#src/util/hierarchical_map.js";
/**
 * @file Facilities for dispatching user-defined actions in response to input events.
 */
/**
 * Specifies a unique string representation of an input event, used for matching an input event to a
 * corresponding action with which it has been associated.
 *
 * The EventIdentifier combines several pieces of information using the following syntax:
 *
 *   NormalizedEventIdentifier ::= phase ':' ( modifier '+' )* base-event-identifier
 *
 *   - The event `phase` name, corresponding to the phase of DOM event processing at which the event was
 *     received, which may be 'at', 'bubble', or 'capture'.  (Currently, 'capture' is not supported.)
 *
 *   - The set of `modifier` keys ('control', 'alt', 'meta', and/or 'shift') active when the event occurred.
 *
 *   - The `base-event-identifier`, which in the case of keyboard events is the lowercase KeyboardEvent
 *     `code`, and in the case of mouse events is one of:
 *
 *       - 'mousedown' + n
 *       - 'mouseup' + n
 *       - 'click' + n
 *       - 'dblclick' + n
 *       - 'wheel'
 *
 *     where `n` is the index of the mouse button, starting from 0.
 *
 * In the normalized form used for matching events, the set of modifiers must be specified in
 * exactly the order: 'control', 'alt', 'meta', 'shift'.  Consequently, there is exactly one
 * NormalizedEventIdentifier representation for a given input event.
 */
export type NormalizedEventIdentifier = string;
/**
 * An EventIdentifier specifies a criteria for matching input events using a relaxed form of the
 * NormalizedEventIdentifier syntax.  Each EventIdentifier corresponds to one or more
 * NormalizedEventIdentifier values.
 *
 *   EventIdentifier ::= [ phase ':' ] ( modifier '+' )* base-event-identifier
 *
 * In addition to the phase being optional, the modifiers may be specified in any order.  If the
 * phase is not specified, then the EventIdentifier matches both the 'at' and 'bubble' phases.
 */
export type EventIdentifier = string;
/**
 * Identifies a user-defined action name.  Actions are dispatched as DOM events, using 'action:'
 * prepended to the ActionIdentifier as the event type.
 */
export type ActionIdentifier = string;
/**
 * Specifies how to handle an event.
 */
export interface EventAction {
    /**
     * Identifier of action to dispatch.
     */
    action: ActionIdentifier;
    /**
     * Whether to call `stopPropagation()` on the triggering event.  Defaults to true.
     */
    stopPropagation?: boolean;
    /**
     * Whether to call `preventDefault()` on the triggering event.  Defaults to true.  Additionally,
     * if `preventDefault()` is called on the dispatched ActionEvent, `preventDefault()` will also be
     * called on the triggering event regardless of the value of `preventDefault`.
     */
    preventDefault?: boolean;
    originalEventIdentifier?: string;
}
export type EventActionMapInterface = HierarchicalMapInterface<NormalizedEventIdentifier, EventAction>;
export declare enum Modifiers {
    CONTROL = 1,
    ALT = 2,
    META = 4,
    SHIFT = 8
}
export type ModifierMask = number;
export interface EventModifierKeyState {
    ctrlKey: boolean;
    altKey: boolean;
    metaKey: boolean;
    shiftKey: boolean;
}
export declare function getEventModifierMask(event: EventModifierKeyState): ModifierMask;
export declare function getStrokeIdentifier(keyName: string, modifiers: ModifierMask): string;
interface ParsedEventIdentifier {
    phase: undefined | "at" | "bubble";
    keyName: string;
    modifiers: ModifierMask;
    optionalModifiers: ModifierMask;
}
/**
 * Specifies either an EventAction or a bare ActionIdentifier.
 */
type ActionOrEventAction = EventAction | ActionIdentifier;
/**
 * Normalizes an ActionOrEventAction into an EventAction.
 */
export declare function normalizeEventAction(parsed: ParsedEventIdentifier, action: ActionOrEventAction): EventAction;
export declare function friendlyEventIdentifier(identifier: string): string;
/**
 * Hierarchical map of `EventIdentifier` specifications to `EventAction` specifications.  These maps
 * are used by KeyboardEventBinder and MouseEventBinder to dispatch an ActionEvent in response to an
 * input event.
 */
export declare class EventActionMap extends HierarchicalMap<NormalizedEventIdentifier, EventAction, EventActionMap> implements EventActionMapInterface {
    label: string | undefined;
    /**
     * Returns a new EventActionMap with the specified bindings.
     *
     * The keys of the `bindings` object specify unnormalized event identifiers to be mapped to their
     * corresponding `ActionOrEventAction` values.
     */
    static fromObject(bindings: {
        [key: string]: ActionOrEventAction;
    }, options?: {
        label?: string;
        parents?: Iterable<[EventActionMap, number]>;
    }): EventActionMap;
    setFromObject(bindings: {
        [key: string]: ActionOrEventAction;
    }): void;
    /**
     * Maps the specified event `identifier` to the specified `action`.
     *
     * The `identifier` may be unnormalized; the actual mapping is created for each corresponding
     * normalized identifier.
     */
    set(identifier: EventIdentifier, action: ActionOrEventAction): void;
    /**
     * Deletes the mapping for the specified `identifier`.
     *
     * The `identifier` may be unnormalized; the mapping is deleted for each corresponding normalized
     * identifier.
     */
    delete(identifier: EventIdentifier): void;
    describe(): string;
}
export declare function dispatchEventAction(originalEvent: Event, detail: any, eventAction: EventAction | undefined): void;
export declare const eventPhaseNames: string[];
export declare function dispatchEvent(baseIdentifier: EventIdentifier, originalEvent: Event, eventPhase: number, detail: any, eventMap: EventActionMapInterface): void;
/**
 * The stroke a user presses for a binding, without phase or optional
 * modifiers. On Mac, Command reaches a `control+` binding that has no `meta+`
 * binding of its own.
 */
export declare function pressedEventIdentifier(eventMap: EventActionMapInterface, normalizedIdentifier: NormalizedEventIdentifier, eventAction: EventAction): string;
export declare function dispatchEventWithModifiers(baseIdentifier: EventIdentifier, originalEvent: Event & EventModifierKeyState, detail: any, eventMap: EventActionMapInterface): void;
/**
 * DOM Event type used for dispatching actions.
 *
 * Additional information relevant to the action is specified as the `detail` property.
 */
export interface ActionEvent<Info> extends CustomEvent {
    detail: Info;
}
/**
 * Register an event listener for the specified `action`.
 *
 * There is no checking that the `TriggerEvent` type is suitable for use with the specified
 * `action`.
 *
 * @returns A nullary disposer function that unregisters the listener when called.
 */
export declare function registerActionListener<Info>(target: EventTarget, action: ActionIdentifier, listener: (event: ActionEvent<Info>) => void, options?: boolean | AddEventListenerOptions): () => void;
export {};
