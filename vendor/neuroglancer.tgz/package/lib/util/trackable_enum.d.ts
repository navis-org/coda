/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
export declare class TrackableEnum<T extends number> implements Trackable {
    enumType: {
        [x: string]: any;
    };
    private value_;
    private defaultValue;
    changed: NullarySignal;
    constructor(enumType: {
        [x: string]: any;
    }, value_: T, defaultValue?: T);
    set value(value: T);
    get value(): T;
    reset(): void;
    restoreState(obj: any): void;
    toJSON(): string | undefined;
}
