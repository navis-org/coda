/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file
 * Support for decompressing uint32 and uint64 segment label chunks.
 */
/**
 * Determines the offset of the value at the specified dataPosition in a single-channel compressed
 * segmentation.
 *
 * @param baseOffset The base offset into `data' at which the compressed data for this channel
 * starts.
 * @param chunkDataSize A 3-element array specifying the size of the volume,
 * @param blockSize A 3-element array specifying the block size ued for compression.
 * @param dataPosition A 3-element array specifying the position within the volume from which to
 * read.
 * @returns The offset into `data', relative to baseOffset, at which the value is located.
 */
export declare function decodeValueOffset(data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>, dataPosition: ArrayLike<number>, uint32sPerElement: number): number;
/**
 * Reads the single value at the specified dataPosition in a single-channel compressed segmentation.
 *
 * @param baseOffset The base offset into `data' at which the compressed data for this channel
 * starts.
 * @param chunkDataSize A 3-element array specifying the size of the volume.
 * @param blockSize A 3-element array specifying the block size ued for compression.
 * @param dataPosition A 3-element array specifying the position within the volume from which to
 * read.
 *
 * Stores the result in `out'.
 */
export declare function readSingleChannelValueUint32(data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>, dataPosition: ArrayLike<number>): number;
export declare function readSingleChannelValueUint64(data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>, dataPosition: ArrayLike<number>): bigint;
/**
 * Reads the single value (of a single channel) at the specified dataPosition in a multi-channel
 * compressed segmentation.
 *
 * @param dataPosition A 4-element [x, y, z, channel] array specifying the position to read.
 */
export declare function readValueUint32(data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>, dataPosition: ArrayLike<number>): number;
export declare function readValueUint64(data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>, dataPosition: ArrayLike<number>): bigint;
/**
 * Decodes a single channel of a compressed segmentation.
 *
 * This is not particularly efficient, because it is intended for testing purposes only.
 */
export declare function decodeChannel<T extends number | bigint>(out: {
    length: number;
    [index: number]: T;
}, data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>): {
    [index: number]: T;
    length: number;
};
/**
 * Decodes a multi-channel compressed segmentation.
 *
 * This is not particularly efficient, because it is intended for testing purposes only.
 */
export declare function decodeChannels<T extends Uint32Array | BigUint64Array>(out: T, data: Uint32Array, baseOffset: number, chunkDataSize: ArrayLike<number>, blockSize: ArrayLike<number>): T;
