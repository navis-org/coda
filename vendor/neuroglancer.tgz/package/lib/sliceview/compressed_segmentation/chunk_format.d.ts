/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { SingleTextureChunkFormat, SingleTextureVolumeChunk } from "#src/sliceview/single_texture_chunk_format.js";
import type { VolumeChunkSpecification } from "#src/sliceview/volume/base.js";
import { DataType } from "#src/sliceview/volume/base.js";
import type { ChunkFormatHandler, VolumeChunkSource } from "#src/sliceview/volume/frontend.js";
import { RefCounted } from "#src/util/disposable.js";
import { vec3 } from "#src/util/geom.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram, ShaderSamplerType } from "#src/webgl/shader.js";
declare class TextureLayout extends RefCounted {
    subchunkGridSize: vec3;
    singleton: boolean;
    constructor(chunkDataSize: Uint32Array, subchunkSize: vec3);
    static get(gl: GL, chunkDataSize: Uint32Array, subchunkSize: vec3): TextureLayout;
}
export declare class ChunkFormat extends SingleTextureChunkFormat<TextureLayout> {
    subchunkSize: vec3;
    numChannels: number;
    static get(gl: GL, dataType: DataType, subchunkSize: vec3, numChannels: number): ChunkFormat;
    private textureAccessHelper;
    get shaderSamplerType(): ShaderSamplerType;
    constructor(dataType: DataType, subchunkSize: vec3, numChannels: number, key: string);
    defineShader(builder: ShaderBuilder, numChannelDimensions: number): void;
    /**
     * Called each time textureLayout changes while drawing chunks.
     *
     * @param channelDimensions The user-specified channel dimensions, independent of the compressed
     * segmentation channels.
     */
    setupTextureLayout(gl: GL, shader: ShaderProgram, textureLayout: TextureLayout, fixedChunkPosition: Uint32Array, chunkDisplaySubspaceDimensions: readonly number[], channelDimensions: readonly number[]): void;
    setTextureData(gl: GL, textureLayout: TextureLayout, data: Uint32Array): void;
    getTextureLayout(gl: GL, chunkDataSize: Uint32Array): TextureLayout;
    beginSource(gl: GL, shader: ShaderProgram): void;
}
export declare class CompressedSegmentationVolumeChunk extends SingleTextureVolumeChunk<Uint32Array, TextureLayout> {
    CHUNK_FORMAT_TYPE: ChunkFormat;
    setTextureData(gl: GL): void;
    getValueAt(dataPosition: Uint32Array): bigint | number;
}
declare class FillValueChunk extends RefCounted {
    textureLayout: TextureLayout;
    texture: WebGLTexture | null;
}
export declare class CompressedSegmentationChunkFormatHandler extends RefCounted implements ChunkFormatHandler {
    chunkFormat: ChunkFormat;
    fillValueChunk: FillValueChunk;
    constructor(gl: GL, spec: VolumeChunkSpecification);
    getChunk(source: VolumeChunkSource, x: any): CompressedSegmentationVolumeChunk;
}
export {};
