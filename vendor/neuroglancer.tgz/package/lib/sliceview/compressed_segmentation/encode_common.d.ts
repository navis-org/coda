/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { TypedArrayBuilder } from "#src/util/array.js";
export declare const BLOCK_HEADER_SIZE = 2;
export declare function newCache(): Map<string, number>;
type ValueTableCache = Map<string, number>;
export declare function writeBlock(output: TypedArrayBuilder<Uint32Array<ArrayBuffer>>, baseOffset: number, cache: ValueTableCache, numBlockElements: number, numUniqueValues: number, valuesBuffer2: Uint32Array, encodingBuffer: Uint32Array, indexBuffer2: Uint32Array, uint32sPerElement: number): [number, number];
export declare function encodeChannel<T extends number | bigint>(output: TypedArrayBuilder<Uint32Array<ArrayBuffer>>, blockSize: ArrayLike<number>, rawData: {
    length: number;
    [index: number]: T;
}, volumeSize: ArrayLike<number>, baseInputOffset?: number, inputStrides?: ArrayLike<number>): void;
export declare function encodeChannels<T extends number | bigint>(output: TypedArrayBuilder<Uint32Array<ArrayBuffer>>, blockSize: ArrayLike<number>, rawData: {
    length: number;
    [index: number]: T;
}, volumeSize: ArrayLike<number>, baseInputOffset?: number, inputStrides?: ArrayLike<number>): void;
export declare function encodeBlock<T extends number | bigint>(rawData: {
    length: number;
    [index: number]: T;
}, inputOffset: number, inputStrides: ArrayLike<number>, blockSize: ArrayLike<number>, actualSize: ArrayLike<number>, baseOffset: number, cache: Map<string, number>, output: TypedArrayBuilder<Uint32Array<ArrayBuffer>>): [number, number];
export {};
