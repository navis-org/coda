/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DisplayContext } from "#src/display_context.js";
import type { FramePickingData, RenderedDataViewerState } from "#src/rendered_data_panel.js";
import { RenderedDataPanel } from "#src/rendered_data_panel.js";
import type { SliceView } from "#src/sliceview/frontend.js";
import type { TrackableBoolean } from "#src/trackable_boolean.js";
import type { TrackableRGB } from "#src/util/color.js";
import type { Borrowed, Owned } from "#src/util/disposable.js";
import { vec3 } from "#src/util/geom.js";
import type { TrackableScaleBarOptions } from "#src/widget/scale_bar.js";
export interface SliceViewerState extends RenderedDataViewerState {
    showScaleBar: TrackableBoolean;
    wireFrame: TrackableBoolean;
    scaleBarOptions: TrackableScaleBarOptions;
    crossSectionBackgroundColor: TrackableRGB;
    hideCrossSectionBackground3D: TrackableBoolean;
}
export declare enum OffscreenTextures {
    COLOR = 0,
    PICK = 1,
    NUM_TEXTURES = 2
}
export declare class SliceViewPanel extends RenderedDataPanel {
    sliceView: Owned<SliceView>;
    viewer: SliceViewerState;
    private sliceViewRenderHelper;
    private axesLineHelper;
    private colorFactor;
    private pickIDs;
    flushBackendProjectionParameters(): void;
    private visibleLayerTracker;
    get displayDimensionRenderInfo(): import("../navigation_state").WatchableDisplayDimensionRenderInfo;
    get rpc(): import("../worker_rpc").RPC;
    get rpcId(): number;
    private offscreenFramebuffer;
    private offscreenCopyHelper;
    private scaleBars;
    get navigationState(): import("../navigation_state").NavigationState<import("../navigation_state").TrackableZoomInterface>;
    constructor(context: Borrowed<DisplayContext>, element: HTMLElement, sliceView: Owned<SliceView>, viewer: SliceViewerState);
    translateByViewportPixels(deltaX: number, deltaY: number): void;
    translateDataPointByViewportPixels(out: vec3, orig: vec3, deltaX: number, deltaY: number): vec3;
    isReady(): boolean;
    drawWithPicking(pickingData: FramePickingData): boolean;
    ensureBoundsUpdated(): void;
    issuePickRequest(glWindowX: number, glWindowY: number, pickRadius: number): void;
    completePickRequest(glWindowX: number, glWindowY: number, data: Float32Array, pickingData: FramePickingData, pickRadius: number): void;
    /**
     * Zooms by the specified factor, maintaining the data position that projects to the current mouse
     * position.
     */
    zoomByMouse(factor: number): void;
}
