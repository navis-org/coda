/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facilities for computing the intersection points between an axis-aligned bounding box and a
 * plane in a vertex shader.
 *
 * We use the approach described in the following paper to determine the
 * intersection between the
 * viewport plane and a given 3-D chunk inside of a WebGL vertex shader:
 *
 * A Vertex Program for Efficient Box-Plane Intersection
 * Christof Rezk Salama and Adreas Kolb
 * VMV 2005.
 * http://www.cg.informatik.uni-siegen.de/data/Publications/2005/rezksalamaVMV2005.pdf
 *
 */
import type { mat4 } from "#src/util/geom.js";
import { vec3 } from "#src/util/geom.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare const vertexBasePositions: Float32Array<ArrayBuffer>;
export declare const boundingBoxCrossSectionVertexIndices: Int32Array<ArrayBuffer>;
export declare function defineBoundingBoxCrossSectionShader(builder: ShaderBuilder): void;
export declare function computeVertexPositionDebug(chunkSize: vec3, uLowerClipBound: vec3, uUpperClipBound: vec3, uPlaneDistance: number, uPlaneNormal: vec3, uTranslation: vec3, vertexIndex: number, print?: boolean): vec3 | undefined;
export declare function computeVertexPositionsDebug(chunkSize: vec3, uLowerClipBound: vec3, uUpperClipBound: vec3, uPlaneDistance: number, uPlaneNormal: vec3, uTranslation: vec3): vec3[];
export declare function setBoundingBoxCrossSectionShaderPlane(shader: ShaderProgram, planeNormal: vec3, planeDistanceToOrigin: number): void;
export declare function setBoundingBoxCrossSectionShaderViewportPlane(shader: ShaderProgram, viewportNormalInGlobalCoordinates: vec3, viewportCenterPosition: vec3, modelMatrix: mat4, invModelMatrix: mat4): void;
