/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { type DisplayDimensionRenderInfo } from "#src/navigation_state.js";
import { ProjectionParameters } from "#src/projection_parameters.js";
import { ChunkLayout } from "#src/sliceview/chunk_layout.js";
import type { WatchableValueChangeInterface, WatchableValueInterface } from "#src/trackable_value.js";
import { DATA_TYPE_BYTES, DataType } from "#src/util/data_type.js";
import type { Disposable } from "#src/util/disposable.js";
import { mat4, vec3 } from "#src/util/geom.js";
import { SharedObject } from "#src/worker_rpc.js";
export { DATA_TYPE_BYTES, DataType };
/**
 * Average cross-sectional area contained within a chunk of the specified size and rotation.
 *
 * This is estimated by taking the total volume of the chunk and dividing it by the total length of
 * the chunk along the z axis.
 */
export declare function estimateSliceAreaPerChunk(chunkLayout: ChunkLayout, viewMatrix: mat4): number;
export interface MultiscaleVolumetricDataRenderLayer {
    localPosition: WatchableValueInterface<Float32Array>;
    renderScaleTarget: WatchableValueInterface<number>;
}
export interface TransformedSource<RLayer extends MultiscaleVolumetricDataRenderLayer = SliceViewRenderLayer, Source extends SliceViewChunkSource = SliceViewChunkSource> {
    renderLayer: RLayer;
    source: Source;
    /**
     * Approximate voxel size in each of the display dimensions.
     */
    effectiveVoxelSize: vec3;
    chunkLayout: ChunkLayout;
    /**
     * Arrays of length `rank` specifying the clip bounds (in voxels) for dimensions not in
     * `chunkDisplayDimensionIndices` and not channel dimensions.  The values for display/channel
     * dimensions are set to -/+infinity.
     */
    nonDisplayLowerClipBound: Float32Array;
    nonDisplayUpperClipBound: Float32Array;
    /**
     * Arrays of length `rank` specifying the clip bounds (in voxels) for all dimensions.
     */
    lowerClipBound: Float32Array;
    upperClipBound: Float32Array;
    lowerClipDisplayBound: vec3;
    upperClipDisplayBound: vec3;
    lowerChunkDisplayBound: vec3;
    upperChunkDisplayBound: vec3;
    /**
     * Dimensions of the chunk corresponding to the 3 display dimensions of the slice view.
     */
    chunkDisplayDimensionIndices: number[];
    /**
     * Rank of "layer" space and the "chunk clip" space, which is >= rank of chunk space.
     */
    layerRank: number;
    /**
     * Transform from dimensions of layer space to dimensions of chunk space.
     *
     * Matrix has dimensions `(globalRank + localRank + 1) * layerRank`.
     *
     * Input space is `[global dimensions, local dimensions]`.  Output space is the "chunk clip"
     * coordinate space, in units of voxels.
     *
     */
    combinedGlobalLocalToChunkTransform: Float32Array;
    /**
     * Transform from non-display dimensions of layer space to non-display dimensions of chunk space.
     *
     * Same as `combinedGlobalLocalToChunkTransform`, except that rows corresponding to "display"
     * chunk dimensions are all 0.
     *
     * Matrix has dimensions `(globalRank + localRank + 1) * layerRank`.
     *
     * Input space is `[global dimensions, local dimensions]`.  Output space is the "chunk clip"
     * coordinate space, in units of voxels.
     */
    fixedLayerToChunkTransform: Float32Array;
    /**
     * When `computeVisibleChunks` invokes the `addChunk` callback, this is set to the position of the
     * chunk.
     */
    curPositionInChunks: Float32Array;
    fixedPositionWithinChunk: Uint32Array;
}
export interface SliceViewRenderLayer {
    /**
     * Current position of non-global layer dimensions.
     */
    localPosition: WatchableValueInterface<Float32Array>;
    renderScaleTarget: WatchableValueInterface<number>;
    filterVisibleSources(sliceView: SliceViewBase<SliceViewChunkSource, SliceViewRenderLayer>, sources: readonly TransformedSource[]): Iterable<TransformedSource>;
}
export interface VisibleLayerSources<RLayer extends MultiscaleVolumetricDataRenderLayer, Source extends SliceViewChunkSource, Transformed extends TransformedSource<RLayer, Source>> {
    allSources: Transformed[][];
    visibleSources: Transformed[];
    displayDimensionRenderInfo: DisplayDimensionRenderInfo;
}
export declare class SliceViewProjectionParameters extends ProjectionParameters {
    /**
     * Normal vector of cross section in (non-isotropic) global voxel coordinates.
     */
    viewportNormalInGlobalCoordinates: vec3;
    /**
     * Normal vector of cross section in isotropic global canonical voxel coordinates.
     */
    viewportNormalInCanonicalCoordinates: vec3;
    centerDataPosition: vec3;
    /**
     * Size in physical units of a single pixel.
     */
    pixelSize: number;
}
export declare class SliceViewBase<Source extends SliceViewChunkSource = SliceViewChunkSource, RLayer extends SliceViewRenderLayer = SliceViewRenderLayer, Transformed extends TransformedSource<RLayer, Source> = TransformedSource<RLayer, Source>> extends SharedObject {
    projectionParameters: WatchableValueChangeInterface<SliceViewProjectionParameters>;
    visibleLayers: Map<RLayer, VisibleLayerSources<RLayer, Source, Transformed>>;
    visibleSourcesStale: boolean;
    constructor(projectionParameters: WatchableValueChangeInterface<SliceViewProjectionParameters>);
    invalidateVisibleSources(): void;
    invalidateVisibleChunks(): void;
    /**
     * Computes the list of sources to use for each visible layer, based on the
     * current pixelSize.
     */
    updateVisibleSources(): void;
}
/**
 * By default, choose a chunk size with at most 2^18 = 262144 voxels.
 */
export declare const DEFAULT_MAX_VOXELS_PER_CHUNK_LOG2 = 18;
/**
 * Specifies common options for getNearIsotropicBlockSize and getTwoDimensionalBlockSize.
 */
export interface BaseChunkLayoutOptions {
    /**
     * Number of chunk dimensions.
     */
    rank: number;
    /**
     * This, together with upperVoxelBound, specifies the total volume dimensions, which serves as a
     * bound on the maximum chunk size.  If not specified, defaults to a zero vector.
     */
    lowerVoxelBound?: Float32Array;
    /**
     * Upper voxel bound.  If not specified, the total volume dimensions are not used to bound the
     * chunk size.
     */
    upperVoxelBound?: Float32Array;
    /**
     * Base 2 logarithm of the maximum number of voxels per chunk.  Defaults to
     * DEFAULT_MAX_VOXELS_PER_CHUNK_LOG2.
     */
    maxVoxelsPerChunkLog2?: number;
    /**
     * Linear (not affine) transformation matrix with `rank` columns and `displayRank` rows in
     * column-major order.  Specifies the transformation from chunk space to an isotropic "camera view
     * space".  Note that only relative scales of input dimensions are relevant, any rotations applied
     * are irrelevant.
     */
    chunkToViewTransform: Float32Array;
    displayRank: number;
    minBlockSize?: Uint32Array;
    maxBlockSize?: Uint32Array;
}
export type GetNearIsotropicBlockSizeOptions = BaseChunkLayoutOptions;
/**
 * Determines a near-isotropic (in camera view space) block size.  All dimensions will be
 * powers of 2, and will not exceed upperVoxelBound - lowerVoxelBound.  The total number of voxels
 * will not exceed maxVoxelsPerChunkLog2.
 */
export declare function getNearIsotropicBlockSize(options: GetNearIsotropicBlockSizeOptions): Uint32Array;
/**
 * Returns an array of [xy, yz, xz] 2-dimensional block sizes, where [x, y, z] refer to the view
 * dimensions.
 */
export declare function getTwoDimensionalBlockSizes(options: BaseChunkLayoutOptions): Uint32Array<ArrayBufferLike>[];
export declare enum ChunkLayoutPreference {
    /**
     * Indicates that isotropic chunks are desired.
     */
    ISOTROPIC = 0,
    /**
     * Indicates that 2-D chunks are desired.
     */
    FLAT = 1
}
export interface SliceViewSourceOptions {
    /**
     * Transform from the multiscale source coordinate space to a "view" coordinate space that
     * reflects the relative scales.  This is a *linear* (not affine) transformation matrix with
     * `rank` columns and `displayRank` rows in column-major order, where `rank` is the rank of the
     * multiscale source.
     */
    multiscaleToViewTransform: Float32Array;
    displayRank: number;
    modelChannelDimensionIndices: readonly number[];
}
export declare function getCombinedTransform(rank: number, bToC: Float32Array, aToB: Float32Array | undefined): Float32Array<ArrayBufferLike>;
/**
 * Specifies parameters for getChunkDataSizes.
 */
export interface ChunkLayoutOptions {
    /**
     * Chunk sizes in voxels.
     */
    chunkDataSizes?: Uint32Array[];
    /**
     * Preferred chunk layout, which determines chunk sizes to use if chunkDataSizes is not
     * specified.
     */
    chunkLayoutPreference?: ChunkLayoutPreference;
}
export declare function getChunkDataSizes(options: ChunkLayoutOptions & BaseChunkLayoutOptions): Uint32Array<ArrayBufferLike>[];
/**
 * Generic specification for SliceView chunks specifying a layout and voxel size.
 */
export interface SliceViewChunkSpecification<ChunkDataSize extends Uint32Array | Float32Array = Uint32Array | Float32Array> {
    rank: number;
    /**
     * Size of chunk in voxels.
     */
    chunkDataSize: ChunkDataSize;
    /**
     * All valid chunks are in the range [lowerChunkBound, upperChunkBound).
     *
     * These are specified in units of chunks (not voxels).
     */
    lowerChunkBound: Float32Array;
    upperChunkBound: Float32Array;
    lowerVoxelBound: Float32Array;
    upperVoxelBound: Float32Array;
}
export declare function makeSliceViewChunkSpecification<ChunkDataSize extends Uint32Array | Float32Array>(options: SliceViewChunkSpecificationOptions<ChunkDataSize>): SliceViewChunkSpecification<ChunkDataSize>;
export declare function filterVisibleSources(sliceView: SliceViewBase, renderLayer: SliceViewRenderLayer, sources: readonly TransformedSource[]): Iterable<TransformedSource>;
/**
 * Common parameters for SliceView Chunks.
 */
export interface SliceViewChunkSpecificationBaseOptions {
    rank: number;
    /**
     * If not specified, defaults to an all-zero vector.  This determines lowerChunkBound.  If this is
     * not a multiple of chunkDataSize, then voxels at lower positions may still be requested.
     */
    lowerVoxelBound?: Float32Array;
    /**
     * Exclusive upper bound in "chunk" coordinate space, in voxels.  This determines upperChunkBound.
     */
    upperVoxelBound: Float32Array;
}
export interface SliceViewChunkSpecificationOptions<ChunkDataSize extends Uint32Array | Float32Array = Uint32Array | Float32Array> extends SliceViewChunkSpecificationBaseOptions {
    chunkDataSize: ChunkDataSize;
}
export interface SliceViewChunkSource<Spec extends SliceViewChunkSpecification = SliceViewChunkSpecification> extends Disposable {
    spec: Spec;
}
export declare const SLICEVIEW_RPC_ID = "SliceView";
export declare const SLICEVIEW_RENDERLAYER_RPC_ID = "sliceview/RenderLayer";
export declare const SLICEVIEW_ADD_VISIBLE_LAYER_RPC_ID = "SliceView.addVisibleLayer";
export declare const SLICEVIEW_REMOVE_VISIBLE_LAYER_RPC_ID = "SliceView.removeVisibleLayer";
export declare const SLICEVIEW_REQUEST_CHUNK_RPC_ID = "ChunkManager.requestChunk";
export declare function forEachVisibleVolumetricChunk<RLayer extends MultiscaleVolumetricDataRenderLayer>(projectionParameters: ProjectionParameters, localPosition: Float32Array, transformedSource: TransformedSource<RLayer>, callback: (positionInChunks: vec3, clippingPlanes: Float32Array) => void): void;
export declare function forEachPlaneIntersectingVolumetricChunk<RLayer extends MultiscaleVolumetricDataRenderLayer>(projectionParameters: ProjectionParameters, localPosition: Float32Array, transformedSource: TransformedSource<RLayer>, chunkLayout: ChunkLayout, callback: (positionInChunks: vec3) => void): void;
/**
 * For chunk layouts with finiteRank < 3, returns an adjusted chunk layout where chunk 0 in each
 * non-finite dimension is guaranteed to cover the viewport.
 */
export declare function getNormalizedChunkLayout(projectionParameters: ProjectionParameters, chunkLayout: ChunkLayout): ChunkLayout;
