/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { mat4, vec3 } from "#src/util/geom.js";
export declare class ChunkLayout {
    /**
     * Size of each chunk in "chunk" coordinates.
     */
    size: vec3;
    /**
     * Transform from local "chunk" coordinates to global voxel coordinates.
     */
    transform: mat4;
    /**
     * Inverse of transform.  Transform from global voxel coordinates to "chunk" coordinates.
     */
    invTransform: mat4;
    /**
     * Determinant of `transform`.
     */
    detTransform: number;
    finiteRank: number;
    constructor(size: vec3, transform: mat4, finiteRank: number);
    toObject(): {
        size: vec3;
        transform: mat4;
        finiteRank: number;
    };
    static fromObject(msg: any): ChunkLayout;
    /**
     * Transform global spatial coordinates to local spatial coordinates.
     */
    globalToLocalSpatial(out: vec3, globalSpatial: vec3): vec3;
    localSpatialVectorToGlobal(out: vec3, localVector: vec3): vec3;
    /**
     * Returns the unnormalized normal vector.
     */
    globalToLocalNormal(globalNormal: vec3, localNormal: vec3): vec3;
}
