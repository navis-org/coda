/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { VolumeChunkSource, ChunkFormat } from "#src/sliceview/volume/frontend.js";
import { VolumeChunk } from "#src/sliceview/volume/frontend.js";
import type { TypedArray } from "#src/util/array.js";
import type { DataType } from "#src/util/data_type.js";
import type { Disposable } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram, ShaderSamplerType } from "#src/webgl/shader.js";
export declare abstract class SingleTextureChunkFormat<TextureLayout extends Disposable> extends RefCounted implements ChunkFormat {
    shaderKey: string;
    dataType: DataType;
    constructor(shaderKey: string, dataType: DataType);
    defineShader(builder: ShaderBuilder, numChannelDimensions: number): void;
    abstract get shaderSamplerType(): ShaderSamplerType;
    beginDrawing(gl: GL, shader: ShaderProgram): void;
    endDrawing(gl: GL, shader: ShaderProgram): void;
    /**
     * Called each time textureLayout changes while drawing chunks.
     */
    abstract setupTextureLayout(gl: GL, shader: ShaderProgram, textureLayout: TextureLayout, fixedChunkPosition: Uint32Array, chunkDisplaySubspaceDimensions: readonly number[], channelDimensions: readonly number[]): void;
    bindChunk<Data>(gl: GL, shader: ShaderProgram, chunk: SingleTextureVolumeChunk<Data, TextureLayout>, fixedChunkPosition: Uint32Array, chunkDisplaySubspaceDimensions: readonly number[], channelDimensions: readonly number[], newSource: boolean): void;
    abstract setTextureData(gl: GL, textureLayout: TextureLayout, data: TypedArray): void;
    /**
     * Does nothing, but may be overridden by subclass.
     */
    beginSource(_gl: GL, _shader: ShaderProgram): void;
}
export declare abstract class SingleTextureVolumeChunk<Data, TextureLayout extends Disposable> extends VolumeChunk {
    texture: WebGLTexture | null;
    data: Data | null;
    textureLayout: TextureLayout | null;
    CHUNK_FORMAT_TYPE: SingleTextureChunkFormat<TextureLayout>;
    constructor(source: VolumeChunkSource, x: any);
    abstract setTextureData(gl: GL): void;
    copyToGPU(gl: GL): void;
    freeGPUMemory(gl: GL): void;
}
