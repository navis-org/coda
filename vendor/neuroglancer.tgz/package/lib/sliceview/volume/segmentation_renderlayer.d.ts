/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { HashMapUint64 } from "#src/gpu_hash/hash_table.js";
import { SegmentColorShaderManager, SegmentStatedColorShaderManager } from "#src/segment_color.js";
import type { SegmentationDisplayState, SegmentationGroupState } from "#src/segmentation_display_state/frontend.js";
import type { SliceViewSourceOptions } from "#src/sliceview/base.js";
import type { SliceView, SliceViewSingleResolutionSource } from "#src/sliceview/frontend.js";
import type { MultiscaleVolumeChunkSource, VolumeChunkSource } from "#src/sliceview/volume/frontend.js";
import type { RenderLayerBaseOptions } from "#src/sliceview/volume/renderlayer.js";
import { SliceViewVolumeRenderLayer } from "#src/sliceview/volume/renderlayer.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { DisjointUint64Sets } from "#src/util/disjoint_sets.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare class EquivalencesHashMap {
    disjointSets: DisjointUint64Sets;
    generation: number;
    hashMap: HashMapUint64;
    constructor(disjointSets: DisjointUint64Sets);
    update(): void;
}
export interface SliceViewSegmentationDisplayState extends SegmentationDisplayState, RenderLayerBaseOptions {
    selectedAlpha: WatchableValueInterface<number>;
    notSelectedAlpha: WatchableValueInterface<number>;
    hideSegmentZero: WatchableValueInterface<boolean>;
    ignoreNullVisibleSet: WatchableValueInterface<boolean>;
}
interface ShaderParameters {
    hasEquivalences: boolean;
    baseSegmentColoring: boolean;
    baseSegmentHighlighting: boolean;
    hasSegmentStatedColors: boolean;
    hideSegmentZero: boolean;
    hasSegmentDefaultColor: boolean;
    hasHighlightColor: boolean;
}
export declare class SegmentationRenderLayer extends SliceViewVolumeRenderLayer<ShaderParameters> {
    displayState: SliceViewSegmentationDisplayState;
    readonly segmentationGroupState: SegmentationGroupState;
    protected segmentColorShaderManager: SegmentColorShaderManager;
    protected segmentStatedColorShaderManager: SegmentStatedColorShaderManager;
    private gpuSegmentStatedColorHashTable;
    private hashTableManager;
    private gpuHashTable;
    private gpuTemporaryHashTable;
    private equivalencesShaderManager;
    private equivalencesHashMap;
    private temporaryEquivalencesHashMap;
    private gpuEquivalencesHashTable;
    private gpuTemporaryEquivalencesHashTable;
    constructor(multiscaleSource: MultiscaleVolumeChunkSource, displayState: SliceViewSegmentationDisplayState);
    disposed(): void;
    getSources(options: SliceViewSourceOptions): SliceViewSingleResolutionSource<VolumeChunkSource>[][];
    defineShader(builder: ShaderBuilder, parameters: ShaderParameters): void;
    initializeShader(_sliceView: SliceView, shader: ShaderProgram, parameters: ShaderParameters): void;
    endSlice(sliceView: SliceView, shader: ShaderProgram, parameters: ShaderParameters): void;
}
export {};
