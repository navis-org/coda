/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkLayoutOptions, SliceViewChunkSource, SliceViewChunkSpecification, SliceViewChunkSpecificationBaseOptions, SliceViewChunkSpecificationOptions, SliceViewSourceOptions } from "#src/sliceview/base.js";
import { DATA_TYPE_BYTES, DataType } from "#src/util/data_type.js";
import type { vec3 } from "#src/util/geom.js";
export { DATA_TYPE_BYTES, DataType };
export interface RenderLayer {
    sources: VolumeChunkSource[][] | null;
}
/**
 * Specifies the interpretation of volumetric data.
 */
export declare enum VolumeType {
    UNKNOWN = 0,
    IMAGE = 1,
    SEGMENTATION = 2
}
/**
 * By default, choose a chunk size with at most 2^18 = 262144 voxels.
 */
export declare const DEFAULT_MAX_VOXELS_PER_CHUNK_LOG2 = 18;
export interface VolumeSourceOptions extends SliceViewSourceOptions {
    discreteValues?: boolean;
}
/**
 * Common parameters for the VolumeChunkSpecification constructor and
 * VolumeChunkSpecification.getDefaults.
 */
/**
 * Specifies constructor parameters for VolumeChunkSpecification.
 */
export interface VolumeChunkSpecificationBaseOptions extends SliceViewChunkSpecificationBaseOptions {
    /**
     * Specifies offset for use by backend.ts:GenericVolumeChunkSource.computeChunkBounds in
     * calculating chunk voxel coordinates.  The calculated chunk coordinates will be equal to the
     * voxel position (in chunkLayout coordinates) plus this value.
     *
     * Defaults to kZeroVec if not specified.
     */
    baseVoxelOffset?: Float32Array;
    dataType: DataType;
    fillValue?: number | bigint;
    /**
     * If set, indicates that the chunk is in compressed segmentation format with the specified block
     * size.
     */
    compressedSegmentationBlockSize?: vec3;
}
export interface VolumeChunkSpecificationOptions extends VolumeChunkSpecificationBaseOptions, SliceViewChunkSpecificationOptions<Uint32Array> {
}
export interface VolumeChunkSpecificationVolumeSourceOptions {
    volumeSourceOptions: VolumeSourceOptions;
}
/**
 * Specifies additional parameters for VolumeChunkSpecification.withDefaultCompression.
 */
export interface VolumeChunkSpecificationDefaultCompressionOptions {
    /**
     * Volume type.
     */
    volumeType: VolumeType;
    maxCompressedSegmentationBlockSize?: vec3;
    minBlockSize?: Uint32Array;
    maxBlockSize?: Uint32Array;
    /**
     * Transform from chunk space to the multiscale volume space.
     * Homogeneous `(rank + 1) * (rank + 1)` matrix in column-major order.
     */
    chunkToMultiscaleTransform: Float32Array;
    /**
     * If specified, must be equal to the product of `chunkToMultiscaleTransform` and
     * `multiscaleToViewTransform`.
     */
    chunkToViewTransform?: Float32Array;
}
/**
 * Specifies parameters for `makeDefaultVolumeChunkSpecifications`.
 */
export interface VolumeChunkSpecificationGetDefaultsOptions extends VolumeChunkSpecificationBaseOptions, VolumeChunkSpecificationDefaultCompressionOptions, ChunkLayoutOptions, VolumeChunkSpecificationVolumeSourceOptions {
}
export interface VolumeChunkSpecification extends SliceViewChunkSpecification<Uint32Array> {
    baseVoxelOffset: Float32Array;
    dataType: DataType;
    compressedSegmentationBlockSize: vec3 | undefined;
    fillValue: number | bigint;
}
export declare function makeVolumeChunkSpecification(options: VolumeChunkSpecificationOptions): VolumeChunkSpecification;
/**
 * Returns a VolumeChunkSpecification with default compression specified if suitable for the
 * volumeType.
 */
export declare function makeVolumeChunkSpecificationWithDefaultCompression(options: VolumeChunkSpecificationDefaultCompressionOptions & VolumeChunkSpecificationOptions & VolumeChunkSpecificationVolumeSourceOptions): VolumeChunkSpecification;
export declare function makeDefaultVolumeChunkSpecifications(options: VolumeChunkSpecificationGetDefaultsOptions): VolumeChunkSpecification[];
export interface VolumeChunkSource extends SliceViewChunkSource {
    spec: VolumeChunkSpecification;
}
export declare const VOLUME_RPC_ID = "volume";
