/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SliceView } from "#src/sliceview/frontend.js";
import type { MultiscaleVolumeChunkSource } from "#src/sliceview/volume/frontend.js";
import type { RenderLayerBaseOptions } from "#src/sliceview/volume/renderlayer.js";
import { SliceViewVolumeRenderLayer } from "#src/sliceview/volume/renderlayer.js";
import type { TrackableAlphaValue } from "#src/trackable_alpha.js";
import type { TrackableBlendModeValue } from "#src/trackable_blend.js";
import type { WatchableShaderError } from "#src/webgl/dynamic_shader.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
import type { ShaderControlsBuilderState, ShaderControlState } from "#src/webgl/shader_ui_controls.js";
export declare function getTrackableFragmentMain(value?: string): import("#src/trackable_value.js").TrackableValue<string>;
export interface ImageRenderLayerOptions extends RenderLayerBaseOptions {
    shaderError: WatchableShaderError;
    opacity: TrackableAlphaValue;
    blendMode: TrackableBlendModeValue;
    shaderControlState: ShaderControlState;
}
export declare function defineImageLayerShader(builder: ShaderBuilder, shaderBuilderState: ShaderControlsBuilderState): void;
export declare class ImageRenderLayer extends SliceViewVolumeRenderLayer<ShaderControlsBuilderState> {
    opacity: TrackableAlphaValue;
    blendMode: TrackableBlendModeValue;
    shaderControlState: ShaderControlState;
    constructor(multiscaleSource: MultiscaleVolumeChunkSource, options: ImageRenderLayerOptions);
    defineShader(builder: ShaderBuilder, shaderBuilderState: ShaderControlsBuilderState): void;
    initializeShader(_sliceView: SliceView, shader: ShaderProgram, parameters: ShaderControlsBuilderState): void;
    setGLBlendMode(gl: WebGL2RenderingContext, renderLayerNum: number): void;
}
