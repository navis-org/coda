/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { Chunk } from "#src/chunk_manager/backend.js";
import { SliceViewChunk, SliceViewChunkSourceBackend } from "#src/sliceview/backend.js";
import type { DataType, SliceViewChunkSpecification } from "#src/sliceview/base.js";
import type { VolumeChunkSource as VolumeChunkSourceInterface, VolumeChunkSpecification } from "#src/sliceview/volume/base.js";
import type { vec3 } from "#src/util/geom.js";
import type { RPC } from "#src/worker_rpc.js";
export declare class VolumeChunk extends SliceViewChunk {
    source: VolumeChunkSource | null;
    data: ArrayBufferView | null;
    chunkDataSize: Uint32Array | null;
    initializeVolumeChunk(key: string, chunkGridPosition: vec3): void;
    serialize(msg: any, transfers: any[]): void;
    downloadSucceeded(): void;
    freeSystemMemory(): void;
}
interface ChunkWithGridPositionAndDataSize extends Chunk {
    chunkGridPosition: Float32Array;
    chunkDataSize: Uint32Array | null;
}
interface SliceViewChunkSpecWithOffsetAndDatatype extends SliceViewChunkSpecification<Uint32Array> {
    baseVoxelOffset: Float32Array;
    dataType: DataType;
}
interface ChunkSourceForChunkBounds {
    spec: SliceViewChunkSpecWithOffsetAndDatatype;
    tempChunkDataSize: Uint32Array;
    tempChunkPosition: Float32Array;
}
/**
 * Helper function for computing the voxel bounds of a chunk based on its chunkGridPosition.
 *
 * This assumes that the grid of chunk positions starts at this.baseVoxelOffset.  Chunks are
 * clipped to lie within upperVoxelBound, but are not clipped to lie within lowerVoxelBound.  (The
 * frontend code currently cannot handle chunks clipped at their lower corner, and the chunk
 * layout can generally be chosen so that lowerVoxelBound lies on a chunk boundary.)
 *
 * This sets chunk.chunkDataSize to a copy of the returned chunkDataSize if it differs from
 * source.spec.chunkDataSize; otherwise, it is set to source.spec.chunkDataSize.
 *
 * @returns A globally-allocated Vec3 containing the chunk corner position in voxel coordinates.
 * The returned Vec3 will be invalidated by any subsequent call to this method, even on a
 * different VolumeChunkSource instance.
 */
export declare function computeChunkBounds(source: ChunkSourceForChunkBounds, chunk: ChunkWithGridPositionAndDataSize): Float32Array<ArrayBufferLike>;
export declare class VolumeChunkSource extends SliceViewChunkSourceBackend implements VolumeChunkSourceInterface {
    spec: VolumeChunkSpecification;
    tempChunkDataSize: Uint32Array;
    tempChunkPosition: Float32Array;
    constructor(rpc: RPC, options: any);
    computeChunkBounds(chunk: VolumeChunk): Float32Array<ArrayBufferLike>;
}
export {};
