/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { ChunkChannelAccessParameters } from "#src/render_coordinate_transform.js";
import type { DataType, SliceViewChunkSpecification } from "#src/sliceview/base.js";
import { MultiscaleSliceViewChunkSource, SliceViewChunk, SliceViewChunkSource } from "#src/sliceview/frontend.js";
import type { VolumeChunkSource as VolumeChunkSourceInterface, VolumeChunkSpecification, VolumeSourceOptions, VolumeType } from "#src/sliceview/volume/base.js";
import type { Disposable } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export type VolumeChunkKey = string;
export interface ChunkFormat {
    shaderKey: string;
    dataType: DataType;
    /**
     * Called on the ChunkFormat of the first source of a RenderLayer.
     *
     * This should define a fragment shader function:
     *
     *   value_type getDataValueAt(ivec3 position, int channelIndex...);
     *
     * where value_type is `getShaderType(this.dataType)`.
     */
    defineShader: (builder: ShaderBuilder, numChannelDimensions: number, inVertexShader?: boolean) => void;
    /**
     * Called once per RenderLayer when starting to draw chunks, on the ChunkFormat of the first
     * source.  This is not called before each source is drawn.
     */
    beginDrawing: (gl: GL, shader: ShaderProgram) => void;
    /**
     * Called once after all chunks have been drawn, on the ChunkFormat of the first source.
     */
    endDrawing: (gl: GL, shader: ShaderProgram) => void;
    /**
     * Called just before drawing each chunk, on the ChunkFormat .
     */
    bindChunk: (gl: GL, shader: ShaderProgram, chunk: SliceViewChunk, fixedChunkPosition: Uint32Array, displayChunkDimensions: readonly number[], channelDimensions: readonly number[], newSource: boolean) => void;
    /**
     * Called just before drawing chunks for the source.
     */
    beginSource: (gl: GL, shader: ShaderProgram) => void;
}
export declare function defineChunkDataShaderAccess(builder: ShaderBuilder, chunkFormat: ChunkFormat, numChannelDimensions: number, getPositionWithinChunkExpr: string): void;
export interface ChunkFormatHandler extends Disposable {
    chunkFormat: ChunkFormat;
    getChunk(source: SliceViewChunkSource, x: any): SliceViewChunk;
}
export type ChunkFormatHandlerFactory = (gl: GL, spec: VolumeChunkSpecification) => ChunkFormatHandler | null;
export declare function registerChunkFormatHandler(factory: ChunkFormatHandlerFactory): void;
export declare function getChunkFormatHandler(gl: GL, spec: VolumeChunkSpecification): ChunkFormatHandler;
export declare class VolumeChunkSource extends SliceViewChunkSource<VolumeChunkSpecification, VolumeChunk> implements VolumeChunkSourceInterface {
    chunkFormatHandler: ChunkFormatHandler;
    private tempChunkGridPosition;
    private tempPositionWithinChunk;
    constructor(chunkManager: ChunkManager, options: {
        spec: VolumeChunkSpecification;
    });
    static encodeSpec(spec: SliceViewChunkSpecification): {
        dataType: DataType;
        compressedSegmentationBlockSize: number[] | undefined;
        baseVoxelOffset: number[];
        chunkDataSize: number[];
        lowerVoxelBound: number[];
        upperVoxelBound: number[];
    };
    get chunkFormat(): ChunkFormat;
    getValueAt(chunkPosition: Float32Array, channelAccess: ChunkChannelAccessParameters): any;
    getChunk(x: any): VolumeChunk;
}
export declare abstract class VolumeChunk extends SliceViewChunk {
    source: VolumeChunkSource;
    chunkDataSize: Uint32Array;
    CHUNK_FORMAT_TYPE: ChunkFormat;
    get chunkFormat(): this["CHUNK_FORMAT_TYPE"];
    constructor(source: VolumeChunkSource, x: any);
    abstract getValueAt(dataPosition: Uint32Array): any;
}
export declare abstract class MultiscaleVolumeChunkSource extends MultiscaleSliceViewChunkSource<VolumeChunkSource, VolumeSourceOptions> {
    abstract dataType: DataType;
    abstract volumeType: VolumeType;
}
