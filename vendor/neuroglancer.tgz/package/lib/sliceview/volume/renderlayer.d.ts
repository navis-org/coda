/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpace } from "#src/coordinate_transform.js";
import type { ProjectionParameters } from "#src/projection_parameters.js";
import type { SliceView } from "#src/sliceview/frontend.js";
import type { SliceViewRenderContext, SliceViewRenderLayerOptions } from "#src/sliceview/renderlayer.js";
import { SliceViewRenderLayer } from "#src/sliceview/renderlayer.js";
import type { VolumeSourceOptions } from "#src/sliceview/volume/base.js";
import type { ChunkFormat, MultiscaleVolumeChunkSource, VolumeChunkSource } from "#src/sliceview/volume/frontend.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { ParameterizedContextDependentShaderGetter, ParameterizedShaderGetterResult, WatchableShaderError } from "#src/webgl/dynamic_shader.js";
import type { HistogramChannelSpecification } from "#src/webgl/empirical_cdf.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export interface RenderLayerBaseOptions extends SliceViewRenderLayerOptions {
    shaderError?: WatchableShaderError;
    channelCoordinateSpace?: WatchableValueInterface<CoordinateSpace>;
}
export interface RenderLayerOptions<ShaderParameters> extends RenderLayerBaseOptions {
    fallbackShaderParameters?: WatchableValueInterface<ShaderParameters>;
    shaderParameters: WatchableValueInterface<ShaderParameters>;
    encodeShaderParameters?: (parameters: ShaderParameters) => any;
}
interface ShaderContext {
    numChannelDimensions: number;
    dataHistogramChannelSpecifications: HistogramChannelSpecification[];
}
export declare abstract class SliceViewVolumeRenderLayer<ShaderParameters = any> extends SliceViewRenderLayer<VolumeChunkSource, VolumeSourceOptions> {
    multiscaleSource: MultiscaleVolumeChunkSource;
    protected shaderGetter: ParameterizedContextDependentShaderGetter<{
        chunkFormat: ChunkFormat | null;
        dataHistogramsEnabled: boolean;
    }, ShaderParameters, ShaderContext>;
    private tempChunkPosition;
    shaderParameters: WatchableValueInterface<ShaderParameters>;
    highestResolutionLoadedVoxelSize: Float32Array | undefined;
    private vertexIdHelper;
    constructor(multiscaleSource: MultiscaleVolumeChunkSource, options: RenderLayerOptions<ShaderParameters>);
    get dataType(): import("#src/sliceview/base.js").DataType;
    getValueAt(globalPosition: Float32Array): any;
    beginChunkFormat(sliceView: SliceView, chunkFormat: ChunkFormat | null, projectionParameters: ProjectionParameters): ParameterizedShaderGetterResult<ShaderParameters, ShaderContext>;
    abstract initializeShader(sliceView: SliceView, shader: ShaderProgram, parameters: ShaderParameters, fallback: boolean): void;
    abstract defineShader(builder: ShaderBuilder, parameters: ShaderParameters): void;
    endSlice(sliceView: SliceView, shader: ShaderProgram, parameters: ShaderParameters): void;
    draw(renderContext: SliceViewRenderContext): void;
}
export {};
