/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { SingleTextureChunkFormat } from "#src/sliceview/single_texture_chunk_format.js";
import type { TypedArray, TypedNumberArray } from "#src/util/array.js";
import { DataType } from "#src/util/data_type.js";
import type { Disposable } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
export declare function chunkFormatTest<TextureLayout extends Disposable>(dataType: DataType, volumeSize: Uint32Array, getChunkFormatAndTextureLayout: (gl: GL) => [SingleTextureChunkFormat<TextureLayout>, TextureLayout], rawData: TypedArray, encodedData: TypedNumberArray): void;
