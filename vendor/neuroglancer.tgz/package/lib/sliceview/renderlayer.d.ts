/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { CoordinateSpace } from "#src/coordinate_transform.js";
import type { VisibleLayerInfo } from "#src/layer/index.js";
import type { ChunkTransformParameters, RenderLayerTransformOrError } from "#src/render_coordinate_transform.js";
import type { RenderScaleHistogram } from "#src/render_scale_statistics.js";
import type { ThreeDimensionalReadyRenderContext, ThreeDimensionalRenderContext } from "#src/renderlayer.js";
import { RenderLayer, VisibilityTrackedRenderLayer } from "#src/renderlayer.js";
import type { SliceViewBase, SliceViewProjectionParameters, SliceViewSourceOptions, TransformedSource } from "#src/sliceview/base.js";
import type { MultiscaleSliceViewChunkSource, SliceView, SliceViewChunkSource, SliceViewSingleResolutionSource } from "#src/sliceview/frontend.js";
import type { SliceViewPanel } from "#src/sliceview/panel.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { Borrowed } from "#src/util/disposable.js";
import { HistogramSpecifications } from "#src/webgl/empirical_cdf.js";
import type { ShaderModule } from "#src/webgl/shader.js";
import type { RpcId } from "#src/worker_rpc.js";
export interface SliceViewRenderLayerOptions {
    /**
     * Specifies the transform from the "model" coordinate space (specified by the multiscale source)
     * to the "render layer" coordinate space.
     */
    transform: WatchableValueInterface<RenderLayerTransformOrError>;
    renderScaleTarget?: WatchableValueInterface<number>;
    renderScaleHistogram?: RenderScaleHistogram;
    /**
     * Specifies the position within the "local" coordinate space.
     */
    localPosition: WatchableValueInterface<Float32Array>;
    dataHistogramSpecifications?: HistogramSpecifications;
    rpcTransfer?: {
        [index: string]: number | string | null;
    };
}
export interface VisibleSourceInfo<Source extends SliceViewChunkSource> {
    source: Borrowed<Source>;
    refCount: number;
    chunkTransform: ChunkTransformParameters;
}
export interface SliceViewRenderContext {
    sliceView: SliceView;
    projectionParameters: SliceViewProjectionParameters;
    wireFrame: boolean;
}
export declare abstract class SliceViewRenderLayer<Source extends SliceViewChunkSource = SliceViewChunkSource, SourceOptions extends SliceViewSourceOptions = SliceViewSourceOptions> extends RenderLayer {
    chunkManager: ChunkManager;
    multiscaleSource: MultiscaleSliceViewChunkSource<Source, SourceOptions>;
    rpcId: RpcId | null;
    rpcTransfer: {
        [index: string]: number | string | null;
    };
    localPosition: WatchableValueInterface<Float32Array>;
    channelCoordinateSpace: WatchableValueInterface<CoordinateSpace>;
    transform: WatchableValueInterface<RenderLayerTransformOrError>;
    renderScaleTarget: WatchableValueInterface<number>;
    renderScaleHistogram?: RenderScaleHistogram;
    dataHistogramSpecifications: HistogramSpecifications;
    getDataHistogramCount(): number;
    /**
     * Currently visible sources for this render layer.
     */
    private visibleSources;
    /**
     * Cached list of sources in `visibleSources`, ordered by voxel size.
     *
     * Truncated to zero length when `visibleSources` changes to indicate that it is invalid.
     */
    private visibleSourcesList_;
    getSources(options: SliceViewSourceOptions): SliceViewSingleResolutionSource<Source>[][];
    addSource(source: Borrowed<Source>, chunkTransform: ChunkTransformParameters): void;
    removeSource(source: Borrowed<Source>): void;
    get visibleSourcesList(): VisibleSourceInfo<Source>[];
    constructor(chunkManager: ChunkManager, multiscaleSource: MultiscaleSliceViewChunkSource<Source, SourceOptions>, options: SliceViewRenderLayerOptions);
    RPC_TYPE_ID: string;
    initializeCounterpart(): void;
    get gl(): import("../webgl/context").GL;
    setGLBlendMode(gl: WebGL2RenderingContext, renderLayerNum: number): void;
    abstract draw(renderContext: SliceViewRenderContext): void;
    filterVisibleSources(sliceView: SliceViewBase, sources: readonly TransformedSource[]): Iterable<TransformedSource>;
}
export interface SliceViewPanelReadyRenderContext extends ThreeDimensionalReadyRenderContext {
    sliceView: SliceView;
}
export interface SliceViewPanelRenderContext extends SliceViewPanelReadyRenderContext, ThreeDimensionalRenderContext {
    emitter: ShaderModule;
    /**
     * Specifies whether the emitted color value will be used.
     */
    emitColor: boolean;
    /**
     * Specifies whether the emitted pick ID will be used.
     */
    emitPickID: boolean;
}
export declare class SliceViewPanelRenderLayer<AttachmentState = unknown> extends VisibilityTrackedRenderLayer {
    draw(renderContext: SliceViewPanelRenderContext, attachment: VisibleLayerInfo<SliceViewPanel, AttachmentState>): void;
    isReady(renderContext: SliceViewPanelReadyRenderContext, attachment: VisibleLayerInfo<SliceViewPanel, AttachmentState>): boolean;
}
