/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { FrameNumberCounter } from "#src/chunk_manager/frontend.js";
import { TrackableValue } from "#src/trackable_value.js";
import type { Borrowed } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { mat4 } from "#src/util/geom.js";
import { NullarySignal } from "#src/util/signal.js";
import { TrackableScreenshotMode } from "#src/util/trackable_screenshot_mode.js";
import type { WatchableVisibilityPriority } from "#src/visibility_priority/frontend.js";
import type { GL } from "#src/webgl/context.js";
export declare class RenderViewport {
    width: number;
    height: number;
    logicalWidth: number;
    logicalHeight: number;
    visibleLeftFraction: number;
    visibleTopFraction: number;
    visibleWidthFraction: number;
    visibleHeightFraction: number;
}
export declare function applyRenderViewportToProjectionMatrix(viewport: RenderViewport, projectionMatrix: mat4): void;
export declare function renderViewportsEqual(a: RenderViewport, b: RenderViewport): boolean;
export declare abstract class RenderedPanel extends RefCounted {
    context: Borrowed<DisplayContext>;
    element: HTMLElement;
    visibility: WatchableVisibilityPriority;
    gl: GL;
    boundsGeneration: number;
    canvasRelativeClippedLeft: number;
    canvasRelativeClippedTop: number;
    canvasRelativeLogicalLeft: number;
    canvasRelativeLogicalTop: number;
    renderViewport: RenderViewport;
    boundsUpdated: NullarySignal;
    private monitorState;
    constructor(context: Borrowed<DisplayContext>, element: HTMLElement, visibility: WatchableVisibilityPriority);
    scheduleRedraw(): void;
    abstract isReady(): boolean;
    ensureBoundsUpdated(canScaleForScreenshot?: boolean): void;
    setGLClippedViewport(): void;
    setGLLogicalViewport(): void;
    abstract draw(): void;
    disposed(): void;
    get visible(): boolean;
    getDepthArray(): Float32Array | undefined;
    get shouldDraw(): boolean;
    get drawOrder(): number;
}
export declare abstract class IndirectRenderedPanel extends RenderedPanel {
    canvas: HTMLCanvasElement;
    canvasRenderingContext: CanvasRenderingContext2D | null;
    constructor(context: Borrowed<DisplayContext>, element: HTMLElement, visibility: WatchableVisibilityPriority);
    abstract drawIndirect(): void;
    draw(): void;
}
export declare class TrackableWindowedViewport extends TrackableValue<Float64Array> {
    constructor();
    toJSON(): number[] | undefined;
}
interface PanelMonitorState {
    intersectionObserver?: IntersectionObserver;
    intersectionObserverMargin?: string;
    isIntersecting: boolean;
    addedToResizeObserver?: boolean;
}
export declare class DisplayContext extends RefCounted implements FrameNumberCounter {
    container: HTMLElement;
    canvas: HTMLCanvasElement;
    gl: GL;
    updateStarted: NullarySignal;
    updateFinished: NullarySignal;
    continuousCameraMotionStarted: NullarySignal;
    continuousCameraMotionFinished: NullarySignal;
    multiChannelSetupFinished: NullarySignal;
    changed: NullarySignal;
    panels: Set<RenderedPanel>;
    canvasRect: DOMRect | undefined;
    rootRect: DOMRect | undefined;
    resizeGeneration: number;
    boundsGeneration: number;
    screenshotMode: TrackableScreenshotMode;
    force3DHistogramForAutoRange: boolean;
    private framerateMonitor;
    private continuousCameraMotionInProgress;
    private orderedPanels;
    /**
     * Unique number of the next frame.  Incremented once each time a frame is drawn.
     */
    frameNumber: number;
    resizeCallback: () => void;
    ensureMonitorPanel(element: HTMLElement, state: PanelMonitorState, elementClientRect: DOMRect): void;
    unmonitorPanel(element: HTMLElement, state: PanelMonitorState): void;
    private resizeObserver;
    private debouncedEndContinuousCameraMotion;
    flagContinuousCameraMotion(): void;
    get isContinuousCameraMotionInProgress(): boolean;
    constructor(container: HTMLElement);
    applyWindowedViewportToElement(element: HTMLElement, value: Float64Array): void;
    isReady(): boolean;
    /**
     * Returns a child element that overlays the canvas.
     */
    makeCanvasOverlayElement(): HTMLDivElement;
    disposed(): void;
    addPanel(panel: Borrowed<RenderedPanel>): void;
    removePanel(panel: Borrowed<RenderedPanel>): void;
    readonly scheduleRedraw: import("#src/util/animation_frame_debounce.js").DebouncedFunction;
    ensureBoundsUpdated(): void;
    draw(): void;
    getDepthArray(): Float32Array<ArrayBuffer>;
    getLastFrameTimesInMs(numberOfFrames?: number): number[];
}
export {};
