/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare const NUM_ALTERNATIVES = 3;
export declare abstract class HashTableBase {
    hashSeeds: Uint32Array<ArrayBuffer>;
    loadFactor: number;
    size: number;
    table: BigUint64Array;
    tableSize: number;
    empty: bigint;
    maxRehashAttempts: number;
    maxAttempts: number;
    capacity: number;
    /**
     * Number of uint64 elements per entry in hash table.
     */
    entryStride: number;
    generation: number;
    mungedEmptyKey: bigint | undefined;
    constructor(hashSeeds?: Uint32Array<ArrayBuffer>);
    private updateHashFunctions;
    /**
     * Invokes callback with a modified version of the hash table data array.
     *
     * Replaces all slots that appear to be valid entries for `empty`, i.e. slots that
     * contain `empty` and to which `empty` hashes, with `mungedEmptyKey`.
     *
     * mungedEmptyKey is chosen such that it does not to any of the same slots as `empty`.
     *
     * This allows the modified data array to be used for lookups without special casing the empty
     * key.
     */
    tableWithMungedEmptyKey(callback: (table: BigUint64Array) => void): void;
    static generateHashSeeds(numAlternatives?: number): Uint32Array<ArrayBuffer>;
    getHash(hashIndex: number, x: bigint): number;
    /**
     * Iterates over the uint64 keys contained in the hash set.
     */
    keys(): IterableIterator<bigint>;
    /**
     * Returns the offset into the hash table of the specified element, or -1 if the element is not
     * present.
     */
    indexOf(x: bigint): number;
    /**
     * Changes the empty key to a value that is not equal to the current empty key and is not present
     * in the table.
     *
     * This is called when an attempt is made to insert the empty key.
     */
    private chooseAnotherEmptyKey;
    /**
     * Returns true iff the specified element is present.
     */
    has(x: bigint): boolean;
    delete(x: bigint): boolean;
    private clearTable;
    clear(): boolean;
    reserve(x: number): boolean;
    protected swapPending(table: BigUint64Array, offset: number): void;
    protected storePending(table: BigUint64Array, offset: number): void;
    protected backupPending(): void;
    protected restorePending(): void;
    private tryToInsert;
    private allocate;
    private rehash;
    private grow;
    protected insertInternal(): void;
}
export declare class HashSetUint64 extends HashTableBase {
    add(x: bigint): boolean;
    /**
     * Iterates over the keys.
     */
    [Symbol.iterator](): IterableIterator<bigint>;
}
export declare class HashMapUint64 extends HashTableBase {
    set(key: bigint, value: bigint): boolean;
    get(key: bigint): bigint | undefined;
    protected swapPending(table: BigUint64Array, offset: number): void;
    protected storePending(table: BigUint64Array, offset: number): void;
    protected backupPending(): void;
    protected restorePending(): void;
    /**
     * Iterates over entries.
     */
    [Symbol.iterator](): Generator<bigint[], void, unknown>;
    /**
     * Iterates over entries.
     */
    entries(): Generator<bigint[], void, unknown>;
}
