/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { HashTableBase } from "#src/gpu_hash/hash_table.js";
import { RefCounted } from "#src/util/disposable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare const glsl_hashCombine: string[];
export declare class GPUHashTable<HashTable extends HashTableBase> extends RefCounted {
    gl: GL;
    hashTable: HashTable;
    generation: number;
    texture: WebGLTexture | null;
    constructor(gl: GL, hashTable: HashTable);
    copyToGPU(): void;
    disposed(): void;
    static get<HashTable extends HashTableBase>(gl: GL, hashTable: HashTable): GPUHashTable<HashTable>;
}
export declare class HashSetShaderManager {
    prefix: string;
    numAlternatives: number;
    textureUnitSymbol: symbol;
    private accessHelper;
    samplerName: string;
    hashSeedsName: string;
    hashKeyMask: string;
    readTable: string;
    constructor(prefix: string, numAlternatives?: number);
    defineShader(builder: ShaderBuilder): void;
    get hasFunctionName(): string;
    enable<HashTable extends HashTableBase>(gl: GL, shader: ShaderProgram, hashTable: GPUHashTable<HashTable>): void;
    disable(gl: GL, shader: ShaderProgram): void;
}
export declare class HashMapShaderManager extends HashSetShaderManager {
    defineShader(builder: ShaderBuilder): void;
    get getFunctionName(): string;
}
