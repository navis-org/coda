/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { CredentialsProvider } from "#src/credentials_provider/index.js";
import type { DVIDToken } from "#src/datasource/dvid/api.js";
import type { DVIDSourceParameters } from "#src/datasource/dvid/base.js";
import { VolumeChunkEncoding } from "#src/datasource/dvid/base.js";
import type { CompleteUrlOptions, CompletionResult, DataSource, GetDataSourceOptions, DataSourceProvider } from "#src/datasource/index.js";
import type { SliceViewSingleResolutionSource } from "#src/sliceview/frontend.js";
import type { VolumeSourceOptions } from "#src/sliceview/volume/base.js";
import { DataType, VolumeType } from "#src/sliceview/volume/base.js";
import { VolumeChunkSource } from "#src/sliceview/volume/frontend.js";
import { vec3 } from "#src/util/geom.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare class DataInstanceBaseInfo {
    obj: any;
    get typeName(): string;
    get compressionName(): string;
    constructor(obj: any);
}
export declare class DataInstanceInfo {
    obj: any;
    name: string;
    base: DataInstanceBaseInfo;
    lowerVoxelBound: vec3;
    upperVoxelBoundInclusive: vec3;
    voxelSize: vec3;
    blockSize: vec3;
    numLevels: number;
    constructor(obj: any, name: string, base: DataInstanceBaseInfo);
}
export declare class VolumeDataInstanceInfo extends DataInstanceInfo {
    encoding: VolumeChunkEncoding;
    dataType: DataType;
    meshSrc: string;
    skeletonSrc: string;
    constructor(obj: any, name: string, base: DataInstanceBaseInfo, encoding: VolumeChunkEncoding, instanceNames: Array<string>);
    get volumeType(): VolumeType.IMAGE | VolumeType.SEGMENTATION;
    getSources(chunkManager: ChunkManager, parameters: DVIDSourceParameters, volumeSourceOptions: VolumeSourceOptions, credentialsProvider: CredentialsProvider<DVIDToken>): SliceViewSingleResolutionSource<VolumeChunkSource>[][];
}
export declare function parseDataInstance(obj: any, name: string, instanceNames: Array<string>): DataInstanceInfo;
export declare class RepositoryInfo {
    alias: string;
    description: string;
    errors: string[];
    dataInstances: Map<string, DataInstanceInfo>;
    uuid: string;
    vnodes: Set<string>;
    constructor(obj: any);
}
export declare function parseRepositoriesInfo(obj: any): Map<string, RepositoryInfo>;
export declare class ServerInfo {
    repositories: Map<string, RepositoryInfo>;
    constructor(obj: any);
    getNode(nodeKey: string): RepositoryInfo;
}
export declare function getServerInfo(chunkManager: ChunkManager, baseUrl: string, credentialsProvider: CredentialsProvider<DVIDToken>, options: Partial<ProgressOptions>): Promise<ServerInfo>;
export declare function getDataSource(options: GetDataSourceOptions): Promise<DataSource>;
export declare function completeInstanceName(repositoryInfo: RepositoryInfo, prefix: string): CompletionResult;
export declare function completeNodeAndInstance(serverInfo: ServerInfo, prefix: string): CompletionResult;
export declare function completeUrl(options: CompleteUrlOptions): Promise<CompletionResult>;
export declare class DVIDDataSource implements DataSourceProvider {
    get scheme(): string;
    get description(): string;
    get(options: GetDataSourceOptions): Promise<DataSource>;
    completeUrl(options: CompleteUrlOptions): Promise<CompletionResult>;
}
