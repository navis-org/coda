/**
 * @license
 * This work is a derivative of the Google Neuroglancer project,
 * Copyright 2016 Google Inc.
 * The Derivative Work is covered by
 * Copyright 2019 Howard Hughes Medical Institute
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CredentialsProvider } from "#src/credentials_provider/index.js";
export interface DVIDToken {
    token?: string;
}
export declare const credentialsKey = "DVID";
export declare class DVIDInstance {
    baseUrl: string;
    nodeKey: string;
    constructor(baseUrl: string, nodeKey: string);
    getNodeApiUrl(path?: string): string;
    getRepoInfoUrl(): string;
    getKeyValueUrl(dataName: string, key: string): string;
    getKeyValueRangeUrl(dataName: string, startKey: string, endKey: string): string;
    getKeyValuesUrl(dataName: string): string;
}
export declare function appendQueryStringForDvid(url: string, user: string | null | undefined): string;
export declare function fetchWithDVIDCredentials(credentialsProvider: CredentialsProvider<DVIDToken>, input: string, init: RequestInit): Promise<Response>;
