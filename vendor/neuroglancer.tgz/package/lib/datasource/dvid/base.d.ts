/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export declare enum VolumeChunkEncoding {
    JPEG = 0,
    RAW = 1,
    COMPRESSED_SEGMENTATION = 2,
    COMPRESSED_SEGMENTATIONARRAY = 3
}
export declare class DVIDSourceParameters {
    baseUrl: string;
    nodeKey: string;
    dataInstanceKey: string;
    authServer?: string;
    user?: string;
}
export declare class VolumeChunkSourceParameters extends DVIDSourceParameters {
    dataScale: string;
    encoding: VolumeChunkEncoding;
    static RPC_ID: string;
}
export declare class SkeletonSourceParameters extends DVIDSourceParameters {
    static RPC_ID: string;
}
export declare class MeshSourceParameters extends DVIDSourceParameters {
    static RPC_ID: string;
}
