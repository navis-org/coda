/**
 * @license
 * Copyright 2024 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CompletionResult } from "#src/datasource/index.js";
import type { AutoDetectDirectorySpec } from "#src/kvstore/auto_detect.js";
import type { SharedKvStoreContext } from "#src/kvstore/frontend.js";
import type { ProgressListener } from "#src/util/progress_listener.js";
export declare function getKvStoreCompletions(sharedKvStoreContext: SharedKvStoreContext, options: {
    url: string;
    signal?: AbortSignal;
    progressListener?: ProgressListener;
    directoryOnly?: boolean;
    autoDetectDirectory?: () => AutoDetectDirectorySpec;
    singlePipelineComponent?: boolean;
}): Promise<CompletionResult>;
export declare function getKvStorePathCompletions(sharedKvStoreContext: SharedKvStoreContext, options: {
    baseUrl: string;
    path: string;
    signal?: AbortSignal;
    progressListener?: ProgressListener;
    directoryOnly?: boolean;
}): Promise<CompletionResult>;
