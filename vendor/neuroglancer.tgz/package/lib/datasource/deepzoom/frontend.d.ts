/**
 * @license
 * Copyright 2016 Google Inc., 2023 Gergely Csucs
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { DataSource, GetKvStoreBasedDataSourceOptions, KvStoreBasedDataSourceProvider } from "#src/datasource/index.js";
import type { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
export declare class DeepzoomDataSource implements KvStoreBasedDataSourceProvider {
    get scheme(): string;
    get description(): string;
    get(options: GetKvStoreBasedDataSourceOptions): Promise<DataSource>;
}
export declare function registerAutoDetect(registry: AutoDetectRegistry): void;
