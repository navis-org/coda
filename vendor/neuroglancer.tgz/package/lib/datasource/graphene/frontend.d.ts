/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/datasource/graphene/graphene.css";
import { AnnotationLayerState } from "#src/annotation/annotation_layer_state.js";
import type { AnnotationReference } from "#src/annotation/index.js";
import type { DataSourceLookupResult, GetKvStoreBasedDataSourceOptions, KvStoreBasedDataSourceProvider } from "#src/datasource/index.js";
import type { SharedKvStoreContext } from "#src/kvstore/frontend.js";
import { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import { PlaceLineTool } from "#src/ui/annotations.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export declare function getJsonMetadata(sharedKvStoreContext: SharedKvStoreContext, url: string, required: boolean, options: Partial<ProgressOptions>): Promise<any>;
export declare class GrapheneDataSource implements KvStoreBasedDataSourceProvider {
    get scheme(): string;
    get description(): string;
    get(options: GetKvStoreBasedDataSourceOptions): Promise<DataSourceLookupResult>;
}
export interface SegmentSelection {
    segmentId: bigint;
    rootId: bigint;
    position: Float32Array;
    annotationReference?: AnnotationReference;
}
export declare class MergeSegmentsPlaceLineTool extends PlaceLineTool {
    private annotationState;
    getBaseSegment: boolean;
    constructor(layer: SegmentationUserLayer, annotationState: AnnotationLayerState);
    get annotationLayer(): AnnotationLayerState;
    get description(): string;
    toJSON(): string;
}
