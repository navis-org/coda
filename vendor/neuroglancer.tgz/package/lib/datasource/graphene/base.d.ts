/**
 * @license
 * Copyright 2019 The Neuroglancer Authors
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ShardingParameters } from "#src/datasource/precomputed/base.js";
import type { KvStoreContext } from "#src/kvstore/context.js";
import type { ChunkLayoutOptions, SliceViewChunkSource, SliceViewChunkSpecification, SliceViewChunkSpecificationBaseOptions, SliceViewChunkSpecificationOptions, DataType } from "#src/sliceview/base.js";
import type { mat4 } from "#src/util/geom.js";
import type { FetchOk, HttpError } from "#src/util/http_request.js";
export declare const PYCG_APP_VERSION = 1;
export declare const GRAPHENE_MESH_NEW_SEGMENT_RPC_ID = "GrapheneMeshSource:NewSegment";
export declare enum VolumeChunkEncoding {
    RAW = 0,
    JPEG = 1,
    COMPRESSED_SEGMENTATION = 2
}
export declare class VolumeChunkSourceParameters {
    url: string;
    encoding: VolumeChunkEncoding;
    sharding: ShardingParameters | undefined;
    static RPC_ID: string;
}
export declare class ChunkedGraphSourceParameters {
    url: string;
    static RPC_ID: string;
}
export declare class MeshSourceParameters {
    manifestUrl: string;
    fragmentUrl: string;
    lod: number;
    sharding: Array<ShardingParameters> | undefined;
    nBitsForLayerId: number;
    static RPC_ID: string;
}
export declare class MultiscaleMeshMetadata {
    transform: mat4;
    lodScaleMultiplier: number;
    vertexQuantizationBits: number;
    sharding: Array<ShardingParameters> | undefined;
}
export declare function isBaseSegmentId(segmentId: bigint, nBitsForLayerId: number): boolean;
export declare function getGrapheneFragmentKey(fragmentId: string): {
    key: string;
    fragmentId: string;
};
export declare const CHUNKED_GRAPH_LAYER_RPC_ID = "ChunkedGraphLayer";
export declare const CHUNKED_GRAPH_RENDER_LAYER_UPDATE_SOURCES_RPC_ID = "ChunkedGraphLayer:updateSources";
export declare const RENDER_RATIO_LIMIT = 5;
export interface ChunkedGraphChunkSpecificationBaseOptions extends SliceViewChunkSpecificationBaseOptions {
    /**
     * Specifies offset for use by backend.ts:GenericVolumeChunkSource.computeChunkBounds in
     * calculating chunk voxel coordinates.  The calculated chunk coordinates will be equal to the
     * voxel position (in chunkLayout coordinates) plus this value.
     *
     * Defaults to kZeroVec if not specified.
     */
    baseVoxelOffset?: Float32Array;
    dataType: DataType;
}
export interface ChunkedGraphChunkSpecificationOptions extends ChunkedGraphChunkSpecificationBaseOptions, SliceViewChunkSpecificationOptions<Uint32Array> {
}
/**
 * Specifies parameters for ChunkedGraphChunkSpecification.getDefaults.
 */
export interface ChunkedGraphChunkSpecificationGetDefaultsOptions extends ChunkedGraphChunkSpecificationBaseOptions, ChunkLayoutOptions {
}
/**
 * Specifies a chunk layout and voxel size.
 */
export interface ChunkedGraphChunkSpecification extends SliceViewChunkSpecification<Uint32Array> {
    baseVoxelOffset: Float32Array;
    dataType: DataType;
}
export declare function makeChunkedGraphChunkSpecification(options: ChunkedGraphChunkSpecificationOptions): ChunkedGraphChunkSpecification;
export interface ChunkedGraphChunkSource extends SliceViewChunkSource {
    spec: ChunkedGraphChunkSpecification;
}
export declare function parseGrapheneError(e: HttpError): Promise<string | undefined>;
export interface HttpSource {
    fetchOkImpl: FetchOk;
    baseUrl: string;
}
export declare function getHttpSource(kvStoreContext: KvStoreContext, url: string): HttpSource;
