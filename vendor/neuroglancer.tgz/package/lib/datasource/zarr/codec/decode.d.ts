/**
 * @license
 * Copyright 2023 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/backend.js";
import type { CodecArrayInfo, CodecChainSpec } from "#src/datasource/zarr/codec/index.js";
import { CodecKind } from "#src/datasource/zarr/codec/index.js";
import type { KvStoreWithPath, ReadableKvStore } from "#src/kvstore/index.js";
import type { RefCounted } from "#src/util/disposable.js";
export interface Codec {
    name: string;
    kind: CodecKind;
}
export interface ArrayToArrayCodec<Configuration = unknown> extends Codec {
    kind: CodecKind.arrayToArray;
    decode(configuration: Configuration, decodedArrayInfo: CodecArrayInfo, encoded: ArrayBufferView<ArrayBuffer>, signal: AbortSignal): Promise<ArrayBufferView<ArrayBuffer>>;
}
export interface ArrayToBytesCodec<Configuration = unknown> extends Codec {
    kind: CodecKind.arrayToBytes;
    decode(configuration: Configuration, decodedArrayInfo: CodecArrayInfo, encoded: Uint8Array<ArrayBuffer>, signal: AbortSignal): Promise<ArrayBufferView<ArrayBuffer>>;
}
export type ShardingKey<BaseKey> = {
    base: BaseKey;
    subChunk: number[];
};
export interface ShardingCodec<Configuration = unknown> extends Codec {
    kind: CodecKind.arrayToBytes;
    getShardedKvStore<BaseKey>(configuration: Configuration, chunkManager: ChunkManager, base: ReadableKvStore<BaseKey>): ReadableKvStore<ShardingKey<BaseKey>> & RefCounted;
}
export interface BytesToBytesCodec<Configuration = unknown> extends Codec {
    kind: CodecKind.bytesToBytes;
    decode(configuration: Configuration, encoded: Uint8Array<ArrayBuffer>, signal: AbortSignal): Promise<Uint8Array<ArrayBuffer>>;
}
export declare function registerCodec<Configuration>(codec: ArrayToArrayCodec<Configuration> | ArrayToBytesCodec<Configuration> | BytesToBytesCodec<Configuration> | ShardingCodec<Configuration>): void;
export declare function decodeArray(codecs: CodecChainSpec, encoded: Uint8Array<ArrayBuffer>, signal: AbortSignal): Promise<ArrayBufferView<ArrayBuffer>>;
export declare function applySharding(chunkManager: ChunkManager, codecs: CodecChainSpec, baseKvStore: KvStoreWithPath): {
    kvStore: ReadableKvStore<unknown>;
    getChunkKey: (chunkGridPosition: ArrayLike<number>, baseKey: string) => unknown;
    decodeCodecs: CodecChainSpec;
};
