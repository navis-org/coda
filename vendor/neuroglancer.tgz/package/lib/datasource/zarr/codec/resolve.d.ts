/**
 * @license
 * Copyright 2023 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CodecArrayInfo, CodecArrayLayoutInfo, CodecChainSpec, ShardingInfo } from "#src/datasource/zarr/codec/index.js";
import { CodecKind } from "#src/datasource/zarr/codec/index.js";
export interface CodecResolver {
    name: string;
    kind: CodecKind;
}
export interface ArrayToArrayCodecResolver<Configuration> extends CodecResolver {
    kind: CodecKind.arrayToArray;
    resolve(configuration: unknown, decodedArrayInfo: CodecArrayInfo): {
        configuration: Configuration;
        encodedArrayInfo: CodecArrayInfo;
    };
    getDecodedArrayLayoutInfo(configuration: Configuration, decodedArrayInfo: CodecArrayInfo, encodedLayout: CodecArrayLayoutInfo): CodecArrayLayoutInfo;
}
export interface ArrayToBytesCodecResolver<Configuration> extends CodecResolver {
    kind: CodecKind.arrayToBytes;
    resolve(configuration: unknown, decodedArrayInfo: CodecArrayInfo): {
        configuration: Configuration;
        shardingInfo?: ShardingInfo;
        encodedSize?: number;
    };
    getDecodedArrayLayoutInfo(configuration: Configuration, decodedArrayInfo: CodecArrayInfo): CodecArrayLayoutInfo;
}
export interface BytesToBytesCodecResolver<Configuration> extends CodecResolver {
    kind: CodecKind.bytesToBytes;
    resolve(configuration: unknown, decodedSize: number | undefined): {
        configuration: Configuration;
        encodedSize?: number;
    };
}
export declare function registerCodec<Configuration>(resolver: ArrayToArrayCodecResolver<Configuration> | ArrayToBytesCodecResolver<Configuration> | BytesToBytesCodecResolver<Configuration>): void;
export declare function parseCodecChainSpec(obj: unknown, decodedArrayInfo: CodecArrayInfo): CodecChainSpec;
