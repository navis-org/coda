/**
 * @license
 * Copyright 2022 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpace } from "#src/coordinate_transform.js";
import type { ChannelMetadata } from "#src/datasource/index.js";
export interface OmeMultiscaleScale {
    url: string;
    transform: Float64Array;
}
export interface OmeMultiscaleMetadata {
    scales: OmeMultiscaleScale[];
    coordinateSpace: CoordinateSpace;
    baseInfo: {
        baseScales: Float64Array;
        baseTransform: Float64Array;
    };
}
export interface OmeMetadata {
    multiscale: OmeMultiscaleMetadata;
    channels: ChannelMetadata | undefined;
}
export declare function parseOmeMetadata(url: string, attrs: any, zarrVersion: number): OmeMetadata | undefined;
