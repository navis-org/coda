/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import "#src/datasource/zarr/codec/blosc/resolve.js";
import "#src/datasource/zarr/codec/zstd/resolve.js";
import type { CoordinateSpace } from "#src/coordinate_transform.js";
import type { DataSource, GetKvStoreBasedDataSourceOptions, KvStoreBasedDataSourceProvider } from "#src/datasource/index.js";
import "#src/datasource/zarr/codec/bytes/resolve.js";
import "#src/datasource/zarr/codec/crc32c/resolve.js";
import "#src/datasource/zarr/codec/gzip/resolve.js";
import "#src/datasource/zarr/codec/sharding_indexed/resolve.js";
import "#src/datasource/zarr/codec/transpose/resolve.js";
import type { ArrayMetadata } from "#src/datasource/zarr/metadata/index.js";
import type { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
import type { CompletionResult } from "#src/kvstore/context.js";
import type { SharedKvStoreContext } from "#src/kvstore/frontend.js";
import type { SliceViewSingleResolutionSource } from "#src/sliceview/frontend.js";
import type { VolumeSourceOptions } from "#src/sliceview/volume/base.js";
import { DataType, VolumeType } from "#src/sliceview/volume/base.js";
import { MultiscaleVolumeChunkSource as GenericMultiscaleVolumeChunkSource, VolumeChunkSource } from "#src/sliceview/volume/frontend.js";
export declare class MultiscaleVolumeChunkSource extends GenericMultiscaleVolumeChunkSource {
    sharedKvStoreContext: SharedKvStoreContext;
    multiscale: ZarrMultiscaleInfo;
    volumeType: VolumeType;
    get dataType(): DataType;
    get modelSpace(): CoordinateSpace;
    get rank(): number;
    constructor(sharedKvStoreContext: SharedKvStoreContext, multiscale: ZarrMultiscaleInfo);
    getSources(volumeSourceOptions: VolumeSourceOptions): SliceViewSingleResolutionSource<VolumeChunkSource>[][];
}
interface ZarrScaleInfo {
    url: string;
    transform: Float64Array;
    metadata: ArrayMetadata;
}
interface ZarrMultiscaleInfo {
    coordinateSpace: CoordinateSpace;
    dataType: DataType;
    scales: ZarrScaleInfo[];
    baseTransform: Float64Array;
}
export declare class ZarrDataSource implements KvStoreBasedDataSourceProvider {
    zarrVersion: 2 | 3 | undefined;
    constructor(zarrVersion?: 2 | 3 | undefined);
    get scheme(): string;
    get expectsDirectory(): boolean;
    get description(): string;
    get(options: GetKvStoreBasedDataSourceOptions): Promise<DataSource>;
    completeUrl(options: GetKvStoreBasedDataSourceOptions): Promise<CompletionResult>;
}
export declare function registerAutoDetectV2(registry: AutoDetectRegistry): void;
export declare function registerAutoDetectV3(registry: AutoDetectRegistry): void;
export {};
