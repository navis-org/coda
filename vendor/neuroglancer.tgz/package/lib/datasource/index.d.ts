/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { MultiscaleAnnotationSource } from "#src/annotation/frontend_source.js";
import type { AnnotationSource } from "#src/annotation/index.js";
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { CoordinateSpace, CoordinateSpaceTransform, CoordinateTransformSpecification } from "#src/coordinate_transform.js";
import type { SharedCredentialsManager } from "#src/credentials_provider/shared.js";
import type { LocalDataSource } from "#src/datasource/local.js";
import { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
import type { SharedKvStoreContext } from "#src/kvstore/frontend.js";
import type { UrlWithParsedScheme } from "#src/kvstore/url.js";
import type { MeshSource, MultiscaleMeshSource } from "#src/mesh/frontend.js";
import type { SegmentPropertyMap } from "#src/segmentation_display_state/property_map.js";
import type { SegmentationGraphSource } from "#src/segmentation_graph/source.js";
import type { SingleMeshSource } from "#src/single_mesh/frontend.js";
import type { SkeletonSource } from "#src/skeleton/frontend.js";
import type { MultiscaleVolumeChunkSource } from "#src/sliceview/volume/frontend.js";
import type { WatchableValueInterface } from "#src/trackable_value.js";
import type { BasicCompletionResult, CompletionWithDescription } from "#src/util/completion.js";
import { RefCounted } from "#src/util/disposable.js";
import type { vec3 } from "#src/util/geom.js";
import { type ProgressOptions } from "#src/util/progress_listener.js";
import type { Trackable } from "#src/util/trackable.js";
export type CompletionResult = BasicCompletionResult<CompletionWithDescription>;
/**
 * Returns the length of the prefix of path that corresponds to the "group", according to the
 * specified separator.
 *
 * If the separator is not specified, gueses whether it is '/' or ':'.
 */
export declare function findSourceGroupBasedOnSeparator(path: string, separator?: string): number;
/**
 * Returns the last "component" of path, according to the specified separator.
 * If the separator is not specified, gueses whether it is '/' or ':'.
 */
export declare function suggestLayerNameBasedOnSeparator(path: string, separator?: string): string;
export interface GetDataSourceOptionsBase extends Partial<ProgressOptions> {
    url: string;
    transform: CoordinateTransformSpecification | undefined;
    globalCoordinateSpace: WatchableValueInterface<CoordinateSpace>;
    state?: any;
}
export interface GetDataSourceOptions extends GetDataSourceOptionsBase {
    registry: DataSourceRegistry;
    providerUrl: string;
    signal: AbortSignal;
    providerScheme: string;
}
export interface ConvertLegacyUrlOptionsBase {
    url: string;
    type: "mesh" | "skeletons" | "single_mesh";
}
export interface ConvertLegacyUrlOptions extends ConvertLegacyUrlOptionsBase {
    registry: DataSourceRegistry;
    providerUrl: string;
    providerScheme: string;
}
export interface DataSubsource {
    volume?: MultiscaleVolumeChunkSource;
    mesh?: MeshSource | MultiscaleMeshSource | SkeletonSource;
    annotation?: MultiscaleAnnotationSource;
    staticAnnotations?: AnnotationSource;
    local?: LocalDataSource;
    singleMesh?: SingleMeshSource;
    segmentPropertyMap?: SegmentPropertyMap;
    segmentationGraph?: SegmentationGraphSource;
}
export interface CompleteUrlOptionsBase extends Partial<ProgressOptions> {
    url: string;
}
export interface CompleteUrlOptions extends CompleteUrlOptionsBase {
    registry: DataSourceRegistry;
    providerUrl: string;
    signal: AbortSignal;
}
export interface DataSubsourceEntry {
    /**
     * Unique identifier (within the group) for this subsource.  Stored in the JSON state
     * representation to indicate which subsources are enabled.  The empty string `""` should be used
     * for the first/primary subsource.
     */
    id: string;
    subsource: DataSubsource;
    /**
     * Homoegeneous transformation from the subsource to the model subspace corresponding to
     * `modelSubspceDimensionIndices`.  The rank is equal to the length of
     * `modelSubspaceDimensionIndices`.  If this is greater than the subsource rank, the subsource
     * coordinate space is implicitly padded at the end with additional dummy dimensions with a range
     * of `[0, 1]`.  If unspecified, defaults to the identity transform.
     */
    subsourceToModelSubspaceTransform?: Float32Array;
    /**
     * Specifies the model dimensions corresponding to this subsource.  If unspecified, defaults to
     * `[0, ..., modelSpace.rank)`.
     */
    modelSubspaceDimensionIndices?: number[];
    /**
     * Specifies whether this associated data source is enabled by default.
     */
    default: boolean;
}
export interface ChannelMetadata {
    name?: string;
    channels: SingleChannelMetadata[];
}
export interface SingleChannelMetadata {
    color?: vec3;
    label?: string;
    active?: boolean;
    window?: [number, number];
    range?: [number, number];
    coefficient?: number;
}
export interface DataSource {
    subsources: DataSubsourceEntry[];
    modelTransform: CoordinateSpaceTransform;
    canChangeModelSpaceRank?: boolean;
    state?: Trackable;
    canonicalUrl?: string;
    channelMetadata?: ChannelMetadata;
}
export interface DataSourceRedirect {
    canonicalUrl?: string;
    targetUrl: string;
}
export type DataSourceLookupResult = DataSource | DataSourceRedirect;
export interface DataSourceWithRedirectInfo extends DataSource {
    originalCanonicalUrl?: string;
    redirectLog: Set<string>;
}
export interface DataSubsourceSpecification {
    enabled?: boolean;
}
export interface DataSourceSpecification {
    url: string;
    transform: CoordinateTransformSpecification | undefined;
    enableDefaultSubsources: boolean;
    subsources: Map<string, DataSubsourceSpecification>;
    state?: any;
    setManually?: boolean;
}
export declare function makeEmptyDataSourceSpecification(): DataSourceSpecification;
export interface DataSourceProvider {
    scheme: string;
    description?: string;
    hidden?: boolean;
    get(options: GetDataSourceOptions): Promise<DataSourceLookupResult>;
    convertLegacyUrl?: (options: ConvertLegacyUrlOptions) => string;
    completeUrl?: (options: CompleteUrlOptions) => Promise<CompletionResult>;
}
export interface KvStoreBasedDataSourceProvider {
    scheme: string;
    description?: string;
    singleFile?: boolean;
    expectsDirectory?: boolean;
    get(options: GetKvStoreBasedDataSourceOptions): Promise<DataSourceLookupResult>;
    completeUrl?: (options: GetKvStoreBasedDataSourceOptions) => Promise<CompletionResult>;
}
export interface GetKvStoreBasedDataSourceOptions extends Partial<ProgressOptions> {
    registry: DataSourceRegistry;
    kvStoreUrl: string;
    url: UrlWithParsedScheme;
    state?: any;
}
export declare class DataSourceRegistry extends RefCounted {
    sharedKvStoreContext: SharedKvStoreContext;
    get credentialsManager(): SharedCredentialsManager;
    get chunkManager(): ChunkManager;
    constructor(sharedKvStoreContext: SharedKvStoreContext);
    dataSources: Map<string, DataSourceProvider>;
    kvStoreBasedDataSources: Map<string, KvStoreBasedDataSourceProvider>;
    autoDetectRegistry: AutoDetectRegistry;
    register(provider: DataSourceProvider): void;
    registerKvStoreBasedProvider(provider: KvStoreBasedDataSourceProvider): void;
    getProvider(url: string): [DataSourceProvider, string, string];
    private autoDetectFormat;
    private resolveKvStoreBasedDataSource;
    private resolvePipeline;
    get(options: GetDataSourceOptionsBase): Promise<DataSourceWithRedirectInfo>;
    convertLegacyUrl(options: ConvertLegacyUrlOptionsBase): string;
    completeUrl(options: CompleteUrlOptionsBase): Promise<CompletionResult>;
    suggestLayerName(url: string): string | undefined;
}
export declare class KvStoreBasedDataSourceLegacyUrlAdapter implements DataSourceProvider {
    base: KvStoreBasedDataSourceProvider;
    scheme: string;
    constructor(base: KvStoreBasedDataSourceProvider, scheme?: string);
    get hidden(): boolean;
    get description(): string | undefined;
    private parseProviderUrl;
    get(options: GetDataSourceOptions): Promise<DataSourceLookupResult>;
    completeUrl(options: CompleteUrlOptions): Promise<CompletionResult>;
}
