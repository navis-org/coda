/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CredentialsProvider } from "#src/credentials_provider/index.js";
export interface Credentials {
    token: string;
}
export declare class NggraphCredentialsProvider extends CredentialsProvider<Credentials> {
    serverUrl: string;
    constructor(serverUrl: string);
    get: (invalidCredentials?: import("#src/credentials_provider/index.js").CredentialsWithGeneration<Credentials> | undefined, options?: Partial<import("../../util/progress_listener").ProgressOptions>) => Promise<import("#src/credentials_provider/index.js").CredentialsWithGeneration<Credentials>>;
}
