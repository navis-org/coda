/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { CompleteUrlOptions, CompletionResult, DataSource, GetDataSourceOptions, DataSourceProvider } from "#src/datasource/index.js";
import type { SegmentationUserLayer } from "#src/layer/segmentation/index.js";
import type { VisibleSegmentsState } from "#src/segmentation_display_state/base.js";
import type { ComputedSplit } from "#src/segmentation_graph/source.js";
import { SegmentationGraphSource, SegmentationGraphSourceConnection } from "#src/segmentation_graph/source.js";
interface GraphSegmentInfo {
    id: bigint;
    baseSegments: bigint[];
    baseSegmentParents: bigint[];
    name: string;
    tags: string[];
    numVoxels: number;
    bounds: number[];
    lastLogId: bigint | null;
}
type GraphSegmentUpdate = GraphSegmentInfo | "invalid" | "error";
declare class GraphConnection extends SegmentationGraphSourceConnection {
    graph: NggraphSegmentationGraphSource;
    constructor(graph: NggraphSegmentationGraphSource, segmentsState: VisibleSegmentsState);
    computeSplit(include: bigint, exclude: bigint): ComputedSplit | undefined;
    private debouncedVisibleSegmentsChanged;
    private segmentQueries;
    private ignoreVisibleSegmentsChanged;
    private segmentEquivalencesChanged;
    private registerVisibleSegment;
    private handleSegmentUpdate;
    private visibleSegmentsChanged;
}
type GraphSegmentUpdateCallback = (info: GraphSegmentUpdate) => void;
export declare class NggraphSegmentationGraphSource extends SegmentationGraphSource {
    chunkManager: ChunkManager;
    serverUrl: string;
    entityName: string;
    private startingWebsocket;
    private websocket;
    private watchesById;
    private watches;
    private nextWatchId;
    private numOpenFailures;
    constructor(chunkManager: ChunkManager, serverUrl: string, entityName: string);
    get visibleSegmentEquivalencePolicy(): number;
    private startWebsocket;
    connect(layer: SegmentationUserLayer): GraphConnection;
    trackSegment(id: bigint, callback: (id: bigint | null) => void): () => void;
    watchSegment(segment: bigint, callback: GraphSegmentUpdateCallback): () => void;
    merge(a: bigint, b: bigint): Promise<bigint>;
    split(include: bigint, exclude: bigint): Promise<{
        include: bigint;
        exclude: bigint;
    }>;
}
export declare class NggraphDataSource implements DataSourceProvider {
    get scheme(): string;
    get description(): string;
    get(options: GetDataSourceOptions): Promise<DataSource>;
    completeUrl(options: CompleteUrlOptions): Promise<CompletionResult>;
}
export {};
