/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/frontend.js";
import type { CompleteUrlOptions, CompletionResult, DataSource, GetDataSourceOptions, DataSourceProvider } from "#src/datasource/index.js";
import { vec3 } from "#src/util/geom.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
interface OwnerInfo {
    owner: string;
    projects: Map<string, ProjectInfo>;
}
interface ProjectInfo {
    stacks: Map<string, StackInfo>;
}
interface StackInfo {
    lowerVoxelBound: vec3;
    upperVoxelBound: vec3;
    voxelResolution: vec3;
    project: string;
    channels: string[];
}
interface QueryParameterInfo {
    name: string;
    type: string;
    required?: boolean;
}
export declare function computeStackHierarchy(stackInfo: StackInfo, tileSize: number): number;
export declare function getOwnerInfo(chunkManager: ChunkManager, hostname: string, owner: string, options: Partial<ProgressOptions>): Promise<OwnerInfo>;
export declare function getQueryParameterInfo(chunkManager: ChunkManager, hostname: string, options: Partial<ProgressOptions>): Promise<QueryParameterInfo[]>;
export declare function stackAndProjectCompleter(chunkManager: ChunkManager, hostname: string, path: string, options: Partial<ProgressOptions>): Promise<CompletionResult>;
export declare function queryParameterCompleter(chunkManager: ChunkManager, hostname: string, query: string, options: Partial<ProgressOptions>): Promise<CompletionResult>;
export declare function volumeCompleter(url: string, chunkManager: ChunkManager, options: Partial<ProgressOptions>): Promise<CompletionResult>;
export declare class RenderDataSource implements DataSourceProvider {
    get scheme(): string;
    get description(): string;
    get(options: GetDataSourceOptions): Promise<DataSource>;
    completeUrl(options: CompleteUrlOptions): Promise<CompletionResult>;
}
export {};
