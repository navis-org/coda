/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file
 * This implements a CredentialsProvider based on Keycloak.
 */
import { CredentialsProvider } from "#src/credentials_provider/index.js";
export type BossToken = string;
/**
 * Obtain a Keycloak OIDC authentication token.
 * @return A Promise that resolves to an authentication token.
 */
export declare function authenticateKeycloakOIDC(options: {
    realm: string;
    clientId: string;
    authServer: string;
}, signal: AbortSignal): Promise<BossToken>;
export declare class BossCredentialsProvider extends CredentialsProvider<BossToken> {
    authServer: string;
    constructor(authServer: string);
    get: (invalidCredentials?: import("#src/credentials_provider/index.js").CredentialsWithGeneration<string> | undefined, options?: Partial<import("#src/util/progress_listener.js").ProgressOptions>) => Promise<import("#src/credentials_provider/index.js").CredentialsWithGeneration<string>>;
}
