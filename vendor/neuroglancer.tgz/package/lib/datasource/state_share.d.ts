import { RefCounted } from "#src/util/disposable.js";
import type { Viewer } from "#src/viewer.js";
export declare const stateShareEnabled: boolean;
export declare class StateShare extends RefCounted {
    element: HTMLDivElement;
    button: HTMLElement;
    selectStateServerElement?: HTMLSelectElement;
    constructor(viewer: Viewer);
    disposed(): void;
}
