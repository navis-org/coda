/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CoordinateSpace } from "#src/coordinate_transform.js";
import type { DataSource, GetKvStoreBasedDataSourceOptions, KvStoreBasedDataSourceProvider } from "#src/datasource/index.js";
import { VolumeChunkEncoding } from "#src/datasource/n5/base.js";
import type { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
import type { CompletionResult } from "#src/kvstore/context.js";
import type { SharedKvStoreContext } from "#src/kvstore/frontend.js";
import type { SliceViewSingleResolutionSource } from "#src/sliceview/frontend.js";
import type { VolumeSourceOptions } from "#src/sliceview/volume/base.js";
import { DataType, VolumeType } from "#src/sliceview/volume/base.js";
import { MultiscaleVolumeChunkSource as GenericMultiscaleVolumeChunkSource, VolumeChunkSource } from "#src/sliceview/volume/frontend.js";
export declare class MultiscaleVolumeChunkSource extends GenericMultiscaleVolumeChunkSource {
    sharedKvStoreContext: SharedKvStoreContext;
    multiscaleMetadata: MultiscaleMetadata;
    scales: (ScaleMetadata | undefined)[];
    dataType: DataType;
    volumeType: VolumeType;
    baseScaleIndex: number;
    modelSpace: CoordinateSpace;
    get rank(): number;
    constructor(sharedKvStoreContext: SharedKvStoreContext, multiscaleMetadata: MultiscaleMetadata, scales: (ScaleMetadata | undefined)[]);
    getSources(volumeSourceOptions: VolumeSourceOptions): SliceViewSingleResolutionSource<VolumeChunkSource>[][];
}
interface MultiscaleMetadata {
    url: string;
    attributes: any;
    modelSpace: CoordinateSpace;
    scales: ({
        readonly url: string;
        readonly downsamplingFactors?: Float64Array<ArrayBuffer>;
    } | undefined)[];
}
interface ScaleMetadata {
    url: string;
    dataType: DataType;
    encoding: VolumeChunkEncoding;
    size: Float32Array<ArrayBuffer>;
    chunkSize: Uint32Array<ArrayBuffer>;
    downsamplingFactors: Float64Array<ArrayBuffer>;
}
export declare class N5DataSource implements KvStoreBasedDataSourceProvider {
    get scheme(): string;
    get expectsDirectory(): boolean;
    get description(): string;
    get(options: GetKvStoreBasedDataSourceOptions): Promise<DataSource>;
    completeUrl(options: GetKvStoreBasedDataSourceOptions): Promise<CompletionResult>;
}
export declare function registerAutoDetect(registry: AutoDetectRegistry): void;
export {};
