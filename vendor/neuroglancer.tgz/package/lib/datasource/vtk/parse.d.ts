/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface VTKHeader {
    version: string;
    comment: string;
    datasetType: string;
    dataFormat: string;
}
export interface VertexAttribute {
    name: string;
    data: Float32Array<ArrayBuffer>;
    numComponents: number;
    tableName: string;
    dataType: string;
}
export declare class TriangularMesh {
    header: VTKHeader;
    numVertices: number;
    vertexPositions: Float32Array<ArrayBuffer>;
    numTriangles: number;
    indices: Uint32Array<ArrayBuffer>;
    vertexAttributes: VertexAttribute[];
    constructor(header: VTKHeader, numVertices: number, vertexPositions: Float32Array<ArrayBuffer>, numTriangles: number, indices: Uint32Array<ArrayBuffer>, vertexAttributes: VertexAttribute[]);
}
export declare function getTriangularMeshSize(mesh: TriangularMesh): number;
export declare function parseVTK(data: ArrayBufferView): TriangularMesh;
