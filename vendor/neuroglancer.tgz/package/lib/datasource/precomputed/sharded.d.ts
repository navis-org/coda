/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ChunkManager } from "#src/chunk_manager/backend.js";
import { type ShardingParameters } from "#src/datasource/precomputed/base.js";
import type { ByteRange, DriverReadOptions, KvStoreWithPath, ReadableKvStore, ReadResponse, StatOptions, StatResponse } from "#src/kvstore/index.js";
import { RefCounted } from "#src/util/disposable.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
export interface ShardInfo {
    shardPath: string;
    offset: number;
}
export declare class ShardedKvStore extends RefCounted implements ReadableKvStore<bigint> {
    private base;
    private sharding;
    private minishardIndexCache;
    constructor(chunkManager: ChunkManager, base: KvStoreWithPath, sharding: ShardingParameters);
    getUrl(key: bigint): string;
    findKey(key: bigint, progressOptions: Partial<ProgressOptions>): Promise<{
        minishardEntry: ByteRange;
        shardInfo: ShardInfo;
    } | undefined>;
    readWithShardInfo(key: bigint, options: DriverReadOptions): Promise<{
        response: ReadResponse;
        shardInfo: ShardInfo;
    } | undefined>;
    stat(key: bigint, options: StatOptions): Promise<StatResponse | undefined>;
    read(key: bigint, options: DriverReadOptions): Promise<ReadResponse | undefined>;
    get supportsOffsetReads(): boolean;
    get supportsSuffixReads(): boolean;
}
export declare function getShardedKvStoreIfApplicable(chunkSource: RefCounted & {
    chunkManager: ChunkManager;
}, base: KvStoreWithPath, sharding: ShardingParameters | undefined): ShardedKvStore | undefined;
