/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CompleteUrlOptions, DataSource, GetDataSourceOptions, DataSourceProvider } from "#src/datasource/index.js";
export declare const localAnnotationsUrl = "local://annotations";
export declare const localEquivalencesUrl = "local://equivalences";
export declare enum LocalDataSource {
    annotations = 0,
    equivalences = 1
}
export declare class LocalDataSourceProvider implements DataSourceProvider {
    get scheme(): string;
    get description(): string;
    get(options: GetDataSourceOptions): Promise<DataSource>;
    completeUrl(options: CompleteUrlOptions): Promise<{
        offset: number;
        completions: import("#src/util/completion.js").CompletionWithDescription[];
    }>;
}
