/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facility for registering default data sources.
 */
import type { SharedCredentialsManager } from "#src/credentials_provider/shared.js";
import type { DataSourceProvider, KvStoreBasedDataSourceProvider } from "#src/datasource/index.js";
import { DataSourceRegistry } from "#src/datasource/index.js";
import { AutoDetectRegistry } from "#src/kvstore/auto_detect.js";
import type { SharedKvStoreContext } from "#src/kvstore/frontend.js";
export interface ProviderOptions {
    credentialsManager: SharedCredentialsManager;
    kvStoreContext: SharedKvStoreContext;
}
export declare const dataSourceAutoDetectRegistry: AutoDetectRegistry;
export declare function registerProvider(provider: DataSourceProvider): void;
export declare function registerKvStoreBasedDataProvider(provider: KvStoreBasedDataSourceProvider): void;
export declare function getDefaultDataSourceProvider(options: ProviderOptions): DataSourceRegistry;
