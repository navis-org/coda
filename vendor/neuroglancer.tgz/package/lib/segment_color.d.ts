/**
 * @license
 * Copyright 2016 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { HashTableBase } from "#src/gpu_hash/hash_table.js";
import type { GPUHashTable } from "#src/gpu_hash/shader.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import type { GL } from "#src/webgl/context.js";
import type { ShaderBuilder, ShaderProgram } from "#src/webgl/shader.js";
export declare class SegmentColorShaderManager {
    prefix: string;
    seedName: string;
    constructor(prefix: string);
    defineShader(builder: ShaderBuilder): void;
    enable(gl: GL, shader: ShaderProgram, segmentColorHash: number): void;
}
export declare function getCssColor(color: Float32Array): string;
export declare class SegmentColorHash implements Trackable {
    hashSeed: number;
    changed: NullarySignal;
    constructor(hashSeed?: number);
    static getDefault(): SegmentColorHash;
    get value(): number;
    set value(value: number);
    compute(out: Float32Array, x: bigint): Float32Array<ArrayBufferLike>;
    computeCssColor(x: bigint): string;
    randomize(): void;
    toString(): string;
    toJSON(): number | undefined;
    reset(): void;
    restoreState(x: any): void;
}
/**
 * Adds the shader code to get a segment's color if it is present in the map.
 */
export declare class SegmentStatedColorShaderManager {
    prefix: string;
    private hashMapShaderManager;
    constructor(prefix: string);
    defineShader(builder: ShaderBuilder): void;
    get getFunctionName(): string;
    enable<HashTable extends HashTableBase>(gl: GL, shader: ShaderProgram, hashTable: GPUHashTable<HashTable>): void;
    disable(gl: GL, shader: ShaderProgram): void;
}
