/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Permits a CredentialsProvider to be shared with another thread.
 */
import type { CredentialsManager, CredentialsProvider, CredentialsWithGeneration } from "#src/credentials_provider/index.js";
import type { Owned } from "#src/util/disposable.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
import type { RPC } from "#src/worker_rpc.js";
import { SharedObject } from "#src/worker_rpc.js";
export declare class SharedCredentialsProvider<Credentials> extends SharedObject implements CredentialsProvider<Credentials> {
    provider: Owned<CredentialsProvider<Credentials>>;
    constructor(provider: Owned<CredentialsProvider<Credentials>>, rpc: RPC);
    get(invalidCredentials?: CredentialsWithGeneration<Credentials>, options?: Partial<ProgressOptions>): Promise<CredentialsWithGeneration<Credentials>>;
}
export declare class SharedCredentialsManager extends SharedObject implements CredentialsManager {
    base: CredentialsManager;
    constructor(base: CredentialsManager, rpc: RPC);
    getCredentialsProvider<Credentials>(key: string, parameters?: any): CredentialsProvider<Credentials>;
}
