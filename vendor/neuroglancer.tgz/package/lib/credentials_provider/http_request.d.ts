/**
 * @license
 * Copyright 2019 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CredentialsProvider } from "#src/credentials_provider/index.js";
import type { FetchOk } from "#src/util/http_request.js";
import { HttpError } from "#src/util/http_request.js";
import type { ProgressListener } from "#src/util/progress_listener.js";
export declare function fetchOkWithCredentials<Credentials>(credentialsProvider: CredentialsProvider<Credentials>, input: RequestInfo | ((credentials: Credentials) => RequestInfo), init: RequestInit & {
    progressListener?: ProgressListener;
}, applyCredentials: (credentials: Credentials, requestInit: RequestInit & {
    progressListener?: ProgressListener;
}) => RequestInit & {
    progressListener?: ProgressListener;
}, errorHandler: (httpError: HttpError, credentials: Credentials) => "refresh" | Promise<"refresh">): Promise<Response>;
export declare function fetchOkWithCredentialsAdapter<Credentials>(credentialsProvider: CredentialsProvider<Credentials>, applyCredentials: (credentials: Credentials, requestInit: RequestInit & {
    progressListener?: ProgressListener;
}) => RequestInit & {
    progressListener?: ProgressListener;
}, errorHandler: (httpError: HttpError, credentials: Credentials) => "refresh"): FetchOk;
