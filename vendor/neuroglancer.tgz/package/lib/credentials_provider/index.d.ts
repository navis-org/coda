/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Generic facility for providing authentication/authorization credentials.
 */
import type { OAuth2Credentials } from "#src/credentials_provider/oauth2.js";
import type { Owned } from "#src/util/disposable.js";
import { RefCounted } from "#src/util/disposable.js";
import type { HttpError } from "#src/util/http_request.js";
import { StringMemoize } from "#src/util/memoize.js";
import type { ProgressOptions } from "#src/util/progress_listener.js";
/**
 * Wraps an arbitrary JSON credentials object with a generation number.
 *
 * The generation number is used for tracking whether the credentials have been updated/renewed.
 */
export interface CredentialsWithGeneration<T> {
    generation: number;
    credentials: T;
}
export declare abstract class CredentialsProvider<Credentials> extends RefCounted {
    /**
     * Request valid credentials.  If `invalidCredentials` is specified, it indicates that the
     * specified credentials are invalid.
     *
     * This method can be conveniently defined using the `makeCredentialsGetter` function.
     */
    abstract get: (invalidCredentials?: CredentialsWithGeneration<Credentials>, options?: Partial<ProgressOptions>) => Promise<CredentialsWithGeneration<Credentials>>;
    errorHandler?: (error: HttpError, credentials: OAuth2Credentials) => Promise<"refresh">;
}
export declare function makeCachedCredentialsGetter<Credentials>(getUncached: (invalidCredentials: CredentialsWithGeneration<Credentials> | undefined, options: ProgressOptions) => Promise<CredentialsWithGeneration<Credentials>>): (invalidCredentials?: CredentialsWithGeneration<Credentials>, options?: Partial<ProgressOptions>) => Promise<CredentialsWithGeneration<Credentials>>;
export declare function makeCredentialsGetter<Credentials>(getWithoutGeneration: (options: ProgressOptions) => Promise<Credentials>): (invalidCredentials?: CredentialsWithGeneration<Credentials> | undefined, options?: Partial<ProgressOptions>) => Promise<CredentialsWithGeneration<Credentials>>;
/**
 * Interface for obtaining a CredentialsProvider based on a string key.
 */
export interface CredentialsManager {
    getCredentialsProvider<Credentials>(key: string, parameters?: any): Owned<CredentialsProvider<Credentials>>;
}
export type ProviderGetter<Credentials> = (parameters: any, credentialsManager: CredentialsManager) => Owned<CredentialsProvider<Credentials>>;
/**
 * CredentialsManager that supports registration.
 */
export declare class MapBasedCredentialsManager implements CredentialsManager {
    providers: Map<string, ProviderGetter<any>>;
    topLevelManager: CredentialsManager;
    register<Credentials>(key: string, providerGetter: ProviderGetter<Credentials>): void;
    getCredentialsProvider<Credentials>(key: string, parameters?: any): Owned<CredentialsProvider<Credentials>>;
}
/**
 * CredentialsManager that wraps another and caches the CredentialsProvider objects.
 */
export declare class CachingCredentialsManager<Base extends CredentialsManager> extends RefCounted implements CredentialsManager {
    base: Base;
    memoize: StringMemoize;
    constructor(base: Base);
    getCredentialsProvider<Credentials>(key: string, parameters?: any): Owned<CredentialsProvider<Credentials>>;
}
export declare class CachingMapBasedCredentialsManager extends CachingCredentialsManager<MapBasedCredentialsManager> {
    constructor();
    register<Credentials>(key: string, providerGetter: ProviderGetter<Credentials>): void;
}
export type MaybeOptionalCredentialsProvider<T> = T extends undefined ? undefined : CredentialsProvider<Exclude<T, undefined>>;
export declare class AnonymousFirstCredentialsProvider<T> extends CredentialsProvider<T> {
    private baseProvider;
    private anonymousCredentials;
    private anonymous;
    constructor(baseProvider: CredentialsProvider<T>, anonymousCredentials: T);
    get: (invalidCredentials?: CredentialsWithGeneration<T> | undefined, options?: Partial<ProgressOptions>) => Promise<CredentialsWithGeneration<T>>;
}
