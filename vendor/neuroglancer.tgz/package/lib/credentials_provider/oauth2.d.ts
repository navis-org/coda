/**
 * @license
 * Copyright 2020 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { CredentialsProvider } from "#src/credentials_provider/index.js";
import type { FetchOk } from "#src/util/http_request.js";
/**
 * OAuth2 token
 */
export interface OAuth2Credentials {
    tokenType: string;
    accessToken: string;
    email?: string;
}
export declare function fetchOkWithOAuth2Credentials(credentialsProvider: CredentialsProvider<OAuth2Credentials> | undefined, input: RequestInfo, init: RequestInit): Promise<Response>;
export declare function fetchOkWithOAuth2CredentialsAdapter(credentialsProvider: CredentialsProvider<OAuth2Credentials> | undefined): FetchOk;
