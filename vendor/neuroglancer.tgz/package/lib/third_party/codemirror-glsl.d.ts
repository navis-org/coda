import type CodeMirrorModule from "codemirror";
export default function (CodeMirror: typeof CodeMirrorModule): void;
