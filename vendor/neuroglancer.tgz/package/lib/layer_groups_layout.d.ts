/**
 * @license
 * Copyright 2017 Google Inc.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Facilities for laying out multiple LayerGroupViewer instances.
 */
import "#src/layer_groups_layout.css";
import { LayerGroupViewer } from "#src/layer_group_viewer.js";
import { TrackableValue } from "#src/trackable_value.js";
import { RefCounted } from "#src/util/disposable.js";
import { NullarySignal } from "#src/util/signal.js";
import type { Trackable } from "#src/util/trackable.js";
import type { Viewer } from "#src/viewer.js";
interface LayoutComponent extends RefCounted {
    element: HTMLElement;
    changed: NullarySignal;
    toJSON(): any;
}
/**
 * Container for a LayoutComponent.  The contained LayoutComponent may change.
 */
export declare class LayoutComponentContainer extends RefCounted {
    viewer: Viewer;
    parent: StackLayoutComponent | undefined;
    changed: NullarySignal;
    private componentValue;
    private unsetComponent;
    get component(): LayoutComponent;
    flex: TrackableValue<number>;
    private setComponent;
    element: HTMLDivElement;
    constructor(viewer: Viewer, spec: any, parent: StackLayoutComponent | undefined);
    toJSON(): any;
    setSpecification(spec: any): void;
    static getFromElement(element: Element): LayoutComponentContainer;
    disposed(): void;
    split(side: "left" | "top" | "bottom" | "right"): {
        newContainer: LayoutComponentContainer;
        existingContainer: LayoutComponentContainer;
    };
}
export declare class SingletonLayerGroupViewer extends RefCounted implements LayoutComponent {
    element: HTMLElement;
    layerGroupViewer: LayerGroupViewer;
    constructor(element: HTMLElement, layout: any, viewer: Viewer);
    toJSON(): string | {
        type: string;
        crossSections: {
            [key: string]: any;
        } | undefined;
        orthographicProjection: boolean | undefined;
    };
    get changed(): NullarySignal;
}
export declare class StackLayoutComponent extends RefCounted implements LayoutComponent {
    element: HTMLElement;
    direction: "row" | "column";
    container: LayoutComponentContainer;
    changed: NullarySignal;
    get length(): number;
    private makeDropPlaceholder;
    get viewer(): Viewer;
    constructor(element: HTMLElement, direction: "row" | "column", children: any[], container: LayoutComponentContainer);
    get(index: number): LayoutComponentContainer;
    insertChild(spec: any, before?: LayoutComponentContainer): LayoutComponentContainer;
    disposed(): void;
    clear(): void;
    [Symbol.iterator](): Generator<LayoutComponentContainer, void, unknown>;
    toJSON(): {
        type: "row" | "column";
        children: any[];
    };
}
export declare class RootLayoutContainer extends RefCounted implements Trackable {
    viewer: Viewer;
    defaultSpecification: any;
    container: LayoutComponentContainer;
    get changed(): NullarySignal;
    get element(): HTMLDivElement;
    constructor(viewer: Viewer, defaultSpecification: any);
    reset(): void;
    restoreState(obj: any): void;
    disposed(): void;
    toJSON(): any;
}
export {};
